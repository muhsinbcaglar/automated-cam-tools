using Microsoft.VisualBasic.ApplicationServices;
using System.IO;
using System.Text;
using System.Windows.Forms;
namespace NXOWI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private void LoadDataFromFile()
        {

            string filePath = textBox5.Text;  // Path to your text file
            filePath = filePath.Replace("\"","");
            string path = @"S:\CAD_Office\Muhsin\NXOPEN\NX_Step_File_Creator\NX_Step_File_Creator_App\STEPFILEDATA\STEPFILEPATH.txt";
            if (File.Exists(filePath))
            {
                try
                {
                filePath = filePath.Replace("\\","\\\\");
                File.WriteAllLines(path, new[] { filePath });
                System.Windows.Forms.Application.Exit();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error reading the file: " + ex.Message);
                    this.Activate();
                }
            }
            else
            {
                MessageBox.Show("File not found: " + filePath);
               
                string aUserCancel = "USER CANCELLED";
                File.WriteAllLines(path, new[] { aUserCancel });
                this.Activate();
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            LoadDataFromFile(); 
        }




        private void button2_Click(object sender, EventArgs e)


        {
            string path = @"S:\CAD_Office\Muhsin\NXOPEN\NX_Step_File_Creator\NX_Step_File_Creator_App\STEPFILEDATA\STEPFILEPATH.txt";
            string aUserCancel = "USER CANCELLED";
            File.WriteAllLines(path, new[] { aUserCancel });


            if (MessageBox.Show("This will close down the whole application. Confirm?", "Retrac - Work Instructions", MessageBoxButtons.OKCancel) == DialogResult.OK)
            {
                System.Windows.Forms.Application.Exit();
            }
            else
            {
                this.Activate();
            }
        }



    }
}
