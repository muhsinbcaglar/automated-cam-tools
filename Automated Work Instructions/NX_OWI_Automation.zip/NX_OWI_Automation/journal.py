﻿# NX 2312
# Journal created by muhsin.caglar on Mon Sep  9 15:19:10 2024 GMT Summer Time
#
import math
import NXOpen
def main() : 

    theSession  = NXOpen.Session.GetSession() #type: NXOpen.Session
    workPart = theSession.Parts.Work
    displayPart = theSession.Parts.Display
    # ----------------------------------------------
    #   Menu: Rotate
    # ----------------------------------------------
    rotMatrix1 = NXOpen.Matrix3x3()
    
    rotMatrix1.Xx = 0.29492739926323419
    rotMatrix1.Xy = 0.955430260786435
    rotMatrix1.Xz = 0.013070804771999667
    rotMatrix1.Yx = -0.31837074232832152
    rotMatrix1.Yy = 0.085360399185709465
    rotMatrix1.Yz = 0.94411528569352521
    rotMatrix1.Zx = 0.90092058450960766
    rotMatrix1.Zy = -0.28260682763234751
    rotMatrix1.Zz = 0.32935616190143241
    translation1 = NXOpen.Point3d(-1.7452362256026017, -1.1153204413558697, -35.371268058696671)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix1, translation1, 0.4956070027253236)
    
    # ----------------------------------------------
    #   Menu: Tools->Automation->Journal->Stop Recording
    # ----------------------------------------------
    
if __name__ == '__main__':
    main()