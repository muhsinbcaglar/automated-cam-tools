using Microsoft.VisualBasic.ApplicationServices;
using System.IO;
using System.Text;
using System.Windows.Forms;
namespace NXOWI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            this.AutoScaleMode = AutoScaleMode.Dpi;
        }
        private void LoadDataFromFile()
        {
            string filePath = @"S:\CAD_Office\Muhsin\NXOPEN\NX_OWI_Automation\WI_DATA\WorkInstructionsData_" + textBox5.Text + ".txt";  // Path to your text file

            if (File.Exists(filePath))
            {
                try
                {
                    // Read all lines from the file
                    string[] lines = File.ReadAllLines(filePath);

                    // Variables to hold the current field being processed
                    string currentField = null;
                    StringBuilder ProjectBuilder = new StringBuilder();
                    StringBuilder RevBuilder = new StringBuilder();
                    StringBuilder CostBuilder = new StringBuilder();
                    StringBuilder MachineBuilder = new StringBuilder();
                    StringBuilder InstructionsBuilder = new StringBuilder();
                    StringBuilder DatumBuilder = new StringBuilder();
                    StringBuilder WHBuilder = new StringBuilder();
                    StringBuilder NotesBuilder = new StringBuilder();
                    StringBuilder AsOppBuilder = new StringBuilder();
                    StringBuilder JobNote1Builder = new StringBuilder();
                    StringBuilder JobNote2Builder = new StringBuilder();
                    StringBuilder JobNote3Builder = new StringBuilder();
                    StringBuilder JobNote4Builder = new StringBuilder();
                    StringBuilder JobNote5Builder = new StringBuilder();
                    StringBuilder JobNote6Builder = new StringBuilder();
                    StringBuilder JobNote7Builder = new StringBuilder();
                    StringBuilder JobNote8Builder = new StringBuilder();
                    StringBuilder JobNote9Builder = new StringBuilder();
                    StringBuilder JobNote10Builder = new StringBuilder();
                    StringBuilder JobNoteReqBuilder = new StringBuilder();

                    StringBuilder JobNote1DRefBuilder = new StringBuilder();
                    StringBuilder JobNote2DRefBuilder = new StringBuilder();
                    StringBuilder JobNote3DRefBuilder = new StringBuilder();
                    StringBuilder JobNote4DRefBuilder = new StringBuilder();
                    StringBuilder JobNote5DRefBuilder = new StringBuilder();
                    StringBuilder JobNote6DRefBuilder = new StringBuilder();
                    StringBuilder JobNote7DRefBuilder = new StringBuilder();
                    StringBuilder JobNote8DRefBuilder = new StringBuilder();
                    StringBuilder JobNote9DRefBuilder = new StringBuilder();
                    StringBuilder JobNote10DRefBuilder = new StringBuilder();
                    StringBuilder JobNotePageReqBuilder = new StringBuilder();
                    StringBuilder JBPartNameBuilder = new StringBuilder();

                    // Iterate through each line
                    foreach (var line in lines)
                    {
                        if (line.StartsWith("Project:"))
                        {
                            currentField = "Project";
                            ProjectBuilder.AppendLine(line);
                        }
                        else if (line.StartsWith("ProgramFolder:"))
                        {
                            currentField = "ProgramFolder";
                        }
                        else if (line.StartsWith("Revision:"))
                        {
                            currentField = "Revision";
                            RevBuilder.AppendLine(line);
                        }
                        else if (line.StartsWith("Costumer:"))
                        {
                            currentField = "Costumer";
                            CostBuilder.AppendLine(line);
                        }
                        else if (line.StartsWith("Machine:"))
                        {
                            currentField = "Machine";
                            MachineBuilder.AppendLine(line);
                        }
                        else if (line.StartsWith("Instructions:"))
                        {
                            currentField = "Instructions";
                            InstructionsBuilder.AppendLine(line);
                        }

                        else if (line.StartsWith("Datum:"))
                        {
                            currentField = "Datum";
                            DatumBuilder.AppendLine(line);
                        }
                        else if (line.StartsWith("WorkHold:"))
                        {
                            currentField = "WorkHold";
                            WHBuilder.AppendLine(line);
                        }
                        else if (line.StartsWith("AsOpp:"))
                        {
                            currentField = "AsOpp";
                            AsOppBuilder.AppendLine(line);
                        }
                        else if (line.StartsWith("Notes:"))
                        {
                            currentField = "Notes";
                            NotesBuilder.AppendLine(line);
                        }




                        else if (line.StartsWith("JobNote1:"))
                        {
                            currentField = "JobNote1";
                            JobNote1Builder.AppendLine(line);
                        }
                        else if (line.StartsWith("JobNote2:"))
                        {
                            currentField = "JobNote2";
                            JobNote2Builder.AppendLine(line);
                        }
                        else if (line.StartsWith("JobNote3:"))
                        {
                            currentField = "JobNote3";
                            JobNote3Builder.AppendLine(line);
                        }
                        else if (line.StartsWith("JobNote4:"))
                        {
                            currentField = "JobNote4";
                            JobNote4Builder.AppendLine(line);
                        }
                        else if (line.StartsWith("JobNote5:"))
                        {
                            currentField = "JobNote5";
                            JobNote5Builder.AppendLine(line);
                        }
                        else if (line.StartsWith("JobNote6:"))
                        {
                            currentField = "JobNote6";
                            JobNote6Builder.AppendLine(line);
                        }
                        else if (line.StartsWith("JobNote7:"))
                        {
                            currentField = "JobNote7";
                            JobNote7Builder.AppendLine(line);
                        }
                        else if (line.StartsWith("JobNote8:"))
                        {
                            currentField = "JobNote8";
                            JobNote8Builder.AppendLine(line);
                        }
                        else if (line.StartsWith("JobNote9:"))
                        {
                            currentField = "JobNote9";
                            JobNote9Builder.AppendLine(line);
                        }
                        else if (line.StartsWith("JobNote10:"))
                        {
                            currentField = "JobNote10";
                            JobNote10Builder.AppendLine(line);
                        }
                        else if (line.StartsWith("JobNote1_D_Ref:"))
                        {
                            currentField = "JobNote1_D_Ref";
                            JobNote1DRefBuilder.AppendLine(line);
                        }
                        else if (line.StartsWith("JobNote2_D_Ref:"))
                        {
                            currentField = "JobNote2_D_Ref";
                            JobNote2DRefBuilder.AppendLine(line);
                        }
                        else if (line.StartsWith("JobNote3_D_Ref:"))
                        {
                            currentField = "JobNote3_D_Ref";
                            JobNote3DRefBuilder.AppendLine(line);
                        }
                        else if (line.StartsWith("JobNote4_D_Ref:"))
                        {
                            currentField = "JobNote4_D_Ref";
                            JobNote4DRefBuilder.AppendLine(line);
                        }
                        else if (line.StartsWith("JobNote5_D_Ref:"))
                        {
                            currentField = "JobNote5_D_Ref";
                            JobNote5DRefBuilder.AppendLine(line);
                        }
                        else if (line.StartsWith("JobNote6_D_Ref:"))
                        {
                            currentField = "JobNote6_D_Ref";
                            JobNote6DRefBuilder.AppendLine(line);
                        }
                        else if (line.StartsWith("JobNote7_D_Ref:"))
                        {
                            currentField = "JobNote7_D_Ref";
                            JobNote7DRefBuilder.AppendLine(line);
                        }
                        else if (line.StartsWith("JobNote8_D_Ref:"))
                        {
                            currentField = "JobNote8_D_Ref";
                            JobNote8DRefBuilder.AppendLine(line);
                        }
                        else if (line.StartsWith("JobNote9_D_Ref:"))
                        {
                            currentField = "JobNote9_D_Ref";
                            JobNote9DRefBuilder.AppendLine(line);
                        }
                        else if (line.StartsWith("JobNote10_D_Ref:"))
                        {
                            currentField = "JobNote10_D_Ref";
                            JobNote10DRefBuilder.AppendLine(line);
                        }

                        else if (line.StartsWith("JobNote10_D_Ref:"))
                        {
                            currentField = "JobNote10_D_Ref";
                            JobNote10DRefBuilder.AppendLine(line);
                        }

                        else if (line.StartsWith("JobNoteReq:"))
                        {
                            currentField = "JobNoteReq";
                            JobNotePageReqBuilder.AppendLine(line);
                        }

                        else if (line.StartsWith("JBPartName:"))
                        {
                            currentField = "JBPartName";
                            JBPartNameBuilder.AppendLine(line);
                        }

                        else
                        {
                            // Accumulate lines based on the current field
                            if (currentField == "Project")
                            {
                                ProjectBuilder.AppendLine(line);
                            }
                            else if (currentField == "Revision")
                            {
                                RevBuilder.AppendLine(line);
                            }
                            else if (currentField == "Costumer")
                            {
                                CostBuilder.AppendLine(line);
                            }
                            else if (currentField == "Machine")
                            {
                                MachineBuilder.AppendLine(line);
                            }
                            else if (currentField == "Instructions")
                            {
                                InstructionsBuilder.AppendLine(line);
                            }
                            else if (currentField == "Datum")
                            {
                                DatumBuilder.AppendLine(line);
                            }
                            else if (currentField == "WorkHold")
                            {
                                WHBuilder.AppendLine(line);
                            }
                            else if (currentField == "AsOpp")
                            {
                                AsOppBuilder.AppendLine(line);
                            }
                            else if (currentField == "Notes")
                            {
                                NotesBuilder.AppendLine(line);
                            }

                            else if (currentField == "JobNote1")
                            {
                                JobNote1Builder.AppendLine(line);
                            }
                            else if (currentField == "JobNote2")
                            {
                                JobNote2Builder.AppendLine(line);
                            }
                            else if (currentField == "JobNote3")
                            {
                                JobNote3Builder.AppendLine(line);
                            }
                            else if (currentField == "JobNote4")
                            {
                                JobNote4Builder.AppendLine(line);
                            }
                            else if (currentField == "JobNote5")
                            {
                                JobNote5Builder.AppendLine(line);
                            }
                            else if (currentField == "JobNote6")
                            {
                                JobNote6Builder.AppendLine(line);
                            }
                            else if (currentField == "JobNote7")
                            {
                                JobNote7Builder.AppendLine(line);
                            }
                            else if (currentField == "JobNote8")
                            {
                                JobNote8Builder.AppendLine(line);
                            }
                            else if (currentField == "JobNote9")
                            {
                                JobNote9Builder.AppendLine(line);
                            }
                            else if (currentField == "JobNote10")
                            {
                                JobNote10Builder.AppendLine(line);
                            }
                            else if (currentField == "JobNote1_D_Ref")
                            {
                                JobNote1DRefBuilder.AppendLine(line);
                            }
                            else if (currentField == "JobNote2_D_Ref")
                            {
                                JobNote2DRefBuilder.AppendLine(line);
                            }
                            else if (currentField == "JobNote3_D_Ref")
                            {
                                JobNote3DRefBuilder.AppendLine(line);
                            }
                            else if (currentField == "JobNote4_D_Ref")
                            {
                                JobNote4DRefBuilder.AppendLine(line);
                            }
                            else if (currentField == "JobNote5_D_Ref")
                            {
                                JobNote5DRefBuilder.AppendLine(line);
                            }
                            else if (currentField == "JobNote6_D_Ref")
                            {
                                JobNote6DRefBuilder.AppendLine(line);
                            }
                            else if (currentField == "JobNote7_D_Ref")
                            {
                                JobNote7DRefBuilder.AppendLine(line);
                            }
                            else if (currentField == "JobNote8_D_Ref")
                            {
                                JobNote8DRefBuilder.AppendLine(line);
                            }
                            else if (currentField == "JobNote9_D_Ref")
                            {
                                JobNote9DRefBuilder.AppendLine(line);
                            }
                            else if (currentField == "JobNote10_D_Ref")
                            {
                                JobNote10DRefBuilder.AppendLine(line);
                            }
                            else if (currentField == "JobNoteReq")
                            {
                                JobNotePageReqBuilder.AppendLine(line);
                            }
                            else if (currentField == "JBPartName")
                            {
                                JBPartNameBuilder.AppendLine(line);
                            }

                        }
                    }

                    // Populate textboxes with accumulated data
                    string ProjectOld = ProjectBuilder.ToString().Trim();
                    string RevOld = RevBuilder.ToString().Trim();
                    string CostOld = CostBuilder.ToString().Trim();
                    string MachineOld = MachineBuilder.ToString().Trim();
                    string InstructionsOld = InstructionsBuilder.ToString().Trim();
                    string DatumOld = DatumBuilder.ToString().Trim();
                    string WHOld = WHBuilder.ToString().Trim();
                    string NotesOld = NotesBuilder.ToString().Trim();
                    string AsOppOld = AsOppBuilder.ToString().Trim();
                    string JobNote1Old = JobNote1Builder.ToString().Trim();
                    string JobNote2Old = JobNote2Builder.ToString().Trim();
                    string JobNote3Old = JobNote3Builder.ToString().Trim();
                    string JobNote4Old = JobNote4Builder.ToString().Trim();
                    string JobNote5Old = JobNote5Builder.ToString().Trim();
                    string JobNote6Old = JobNote6Builder.ToString().Trim();
                    string JobNote7Old = JobNote7Builder.ToString().Trim();
                    string JobNote8Old = JobNote8Builder.ToString().Trim();
                    string JobNote9Old = JobNote9Builder.ToString().Trim();
                    string JobNote10Old = JobNote10Builder.ToString().Trim();
                    string JobNoteDWGRef1Old = JobNote1DRefBuilder.ToString().Trim();
                    string JobNoteDWGRef2Old = JobNote2DRefBuilder.ToString().Trim();
                    string JobNoteDWGRef3Old = JobNote3DRefBuilder.ToString().Trim();
                    string JobNoteDWGRef4Old = JobNote4DRefBuilder.ToString().Trim();
                    string JobNoteDWGRef5Old = JobNote5DRefBuilder.ToString().Trim();
                    string JobNoteDWGRef6Old = JobNote6DRefBuilder.ToString().Trim();
                    string JobNoteDWGRef7Old = JobNote7DRefBuilder.ToString().Trim();
                    string JobNoteDWGRef8Old = JobNote8DRefBuilder.ToString().Trim();
                    string JobNoteDWGRef9Old = JobNote9DRefBuilder.ToString().Trim();
                    string JobNoteDWGRef10Old = JobNote10DRefBuilder.ToString().Trim();
                    string JobNotePageReqOld = JobNotePageReqBuilder.ToString().Trim();
                    string JBPartNameOld = JBPartNameBuilder.ToString().Trim();








                    ProjectOld = ProjectOld.Replace("Project:", "");
                    RevOld = RevOld.Replace("Revision:", "");
                    CostOld = CostOld.Replace("Costumer:", "");
                    MachineOld = MachineOld.Replace("Machine:", "");



                    InstructionsOld = InstructionsOld.Replace("Instructions:", "");
                    InstructionsOld = InstructionsOld.Replace("##", ",");
                    InstructionsOld = InstructionsOld.Replace("</br>", "");

                    DatumOld = DatumOld.Replace("Datum:", "");
                    DatumOld = DatumOld.Replace("##", ",");
                    DatumOld = DatumOld.Replace("</br>", "");

                    WHOld = WHOld.Replace("WorkHold:", "");
                    WHOld = WHOld.Replace("##", ",");
                    WHOld = WHOld.Replace("</br>", "");

                    NotesOld = NotesOld.Replace("Notes:", "");
                    NotesOld = NotesOld.Replace("##", ",");
                    NotesOld = NotesOld.Replace("</br>", "");

                    AsOppOld = AsOppOld.Replace("AsOpp:", "");

                    JobNote1Old = JobNote1Old.Replace("JobNote1:", "");
                    JobNote1Old = JobNote1Old.Replace("##", ",");
                    JobNote1Old = JobNote1Old.Replace("</br>", "");

                    JobNote2Old = JobNote2Old.Replace("JobNote2:", "");
                    JobNote2Old = JobNote2Old.Replace("##", ",");
                    JobNote2Old = JobNote2Old.Replace("</br>", "");

                    JobNote3Old = JobNote3Old.Replace("JobNote3:", "");
                    JobNote3Old = JobNote3Old.Replace("##", ",");
                    JobNote3Old = JobNote3Old.Replace("</br>", "");

                    JobNote4Old = JobNote4Old.Replace("JobNote4:", "");
                    JobNote4Old = JobNote4Old.Replace("##", ",");
                    JobNote4Old = JobNote4Old.Replace("</br>", "");

                    JobNote5Old = JobNote5Old.Replace("JobNote5:", "");
                    JobNote5Old = JobNote5Old.Replace("##", ",");
                    JobNote5Old = JobNote5Old.Replace("</br>", "");

                    JobNote6Old = JobNote6Old.Replace("JobNote6:", "");
                    JobNote6Old = JobNote6Old.Replace("##", ",");
                    JobNote6Old = JobNote6Old.Replace("</br>", "");

                    JobNote7Old = JobNote7Old.Replace("JobNote7:", "");
                    JobNote7Old = JobNote7Old.Replace("##", ",");
                    JobNote7Old = JobNote7Old.Replace("</br>", "");

                    JobNote8Old = JobNote8Old.Replace("JobNote8:", "");
                    JobNote8Old = JobNote8Old.Replace("##", ",");
                    JobNote8Old = JobNote8Old.Replace("</br>", "");

                    JobNote9Old = JobNote9Old.Replace("JobNote9:", "");
                    JobNote9Old = JobNote9Old.Replace("##", ",");
                    JobNote9Old = JobNote9Old.Replace("</br>", "");

                    JobNote10Old = JobNote10Old.Replace("JobNote10:", "");
                    JobNote10Old = JobNote10Old.Replace("##", ",");
                    JobNote10Old = JobNote10Old.Replace("</br>", "");


                    JobNoteDWGRef1Old = JobNoteDWGRef1Old.Replace("JobNote1_D_Ref:", "");
                    JobNoteDWGRef1Old = JobNoteDWGRef1Old.Replace("##", ",");
                    JobNoteDWGRef1Old = JobNoteDWGRef1Old.Replace("</br>", "");

                    JobNoteDWGRef2Old = JobNoteDWGRef2Old.Replace("JobNote2_D_Ref:", "");
                    JobNoteDWGRef2Old = JobNoteDWGRef2Old.Replace("##", ",");
                    JobNoteDWGRef2Old = JobNoteDWGRef2Old.Replace("</br>", "");

                    JobNoteDWGRef3Old = JobNoteDWGRef3Old.Replace("JobNote3_D_Ref:", "");
                    JobNoteDWGRef3Old = JobNoteDWGRef3Old.Replace("##", ",");
                    JobNoteDWGRef3Old = JobNoteDWGRef3Old.Replace("</br>", "");

                    JobNoteDWGRef4Old = JobNoteDWGRef4Old.Replace("JobNote4_D_Ref:", "");
                    JobNoteDWGRef4Old = JobNoteDWGRef4Old.Replace("##", ",");
                    JobNoteDWGRef4Old = JobNoteDWGRef4Old.Replace("</br>", "");

                    JobNoteDWGRef5Old = JobNoteDWGRef5Old.Replace("JobNote5_D_Ref:", "");
                    JobNoteDWGRef5Old = JobNoteDWGRef5Old.Replace("##", ",");
                    JobNoteDWGRef5Old = JobNoteDWGRef5Old.Replace("</br>", "");

                    JobNoteDWGRef6Old = JobNoteDWGRef6Old.Replace("JobNote6_D_Ref:", "");
                    JobNoteDWGRef6Old = JobNoteDWGRef6Old.Replace("##", ",");
                    JobNoteDWGRef6Old = JobNoteDWGRef6Old.Replace("</br>", "");

                    JobNoteDWGRef7Old = JobNoteDWGRef7Old.Replace("JobNote7_D_Ref:", "");
                    JobNoteDWGRef7Old = JobNoteDWGRef7Old.Replace("##", ",");
                    JobNoteDWGRef7Old = JobNoteDWGRef7Old.Replace("</br>", "");

                    JobNoteDWGRef8Old = JobNoteDWGRef8Old.Replace("JobNote8_D_Ref:", "");
                    JobNoteDWGRef8Old = JobNoteDWGRef8Old.Replace("##", ",");
                    JobNoteDWGRef8Old = JobNoteDWGRef8Old.Replace("</br>", "");

                    JobNoteDWGRef9Old = JobNoteDWGRef9Old.Replace("JobNote9_D_Ref:", "");
                    JobNoteDWGRef9Old = JobNoteDWGRef9Old.Replace("##", ",");
                    JobNoteDWGRef9Old = JobNoteDWGRef9Old.Replace("</br>", "");

                    JobNoteDWGRef10Old = JobNoteDWGRef10Old.Replace("JobNote10_D_Ref:", "");
                    JobNoteDWGRef10Old = JobNoteDWGRef10Old.Replace("##", ",");
                    JobNoteDWGRef10Old = JobNoteDWGRef10Old.Replace("</br>", "");

                    JBPartNameOld = JBPartNameOld.Replace("JBPartName:", "");
                    JBPartNameOld = JBPartNameOld.Replace("##", ",");
                    JBPartNameOld = JBPartNameOld.Replace("</br>", "");

                    if (JobNotePageReqOld == "JobNoteReq:YES")
                    {
                        checkBox2.Checked = true;
                    }
                    else
                    {
                        checkBox2.Checked = false;

                    }

                    textBox1.Text = ProjectOld;
                    comboBox2.Text = RevOld;
                    comboBox5.Text = CostOld;
                    comboBox1.Text = MachineOld;
                    textBox2.Text = InstructionsOld;
                    textBox3.Text = DatumOld;
                    comboBox6.Text = WHOld;
                    comboBox3.Text = AsOppOld;
                    textBox4.Text = NotesOld;

                    textBox26.Text = JBPartNameOld;
                    textBox6.Text = JobNote1Old;
                    textBox9.Text = JobNote2Old;
                    textBox11.Text = JobNote3Old;
                    textBox13.Text = JobNote4Old;
                    textBox15.Text = JobNote5Old;
                    textBox17.Text = JobNote6Old;
                    textBox19.Text = JobNote7Old;
                    textBox21.Text = JobNote8Old;
                    textBox23.Text = JobNote9Old;
                    textBox25.Text = JobNote10Old;
                    textBox7.Text = JobNoteDWGRef1Old;
                    textBox8.Text = JobNoteDWGRef2Old;
                    textBox10.Text = JobNoteDWGRef3Old;
                    textBox12.Text = JobNoteDWGRef4Old;
                    textBox14.Text = JobNoteDWGRef5Old;
                    textBox16.Text = JobNoteDWGRef6Old;
                    textBox18.Text = JobNoteDWGRef7Old;
                    textBox20.Text = JobNoteDWGRef8Old;
                    textBox22.Text = JobNoteDWGRef9Old;
                    textBox24.Text = JobNoteDWGRef10Old;


                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error reading the file: " + ex.Message);
                }
            }
            else
            {
                MessageBox.Show("File not found: " + filePath);
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox5.Text != "")
            {
                string aToolPathDisplayed;
                if (checkBox1.Checked)
                {
                    aToolPathDisplayed = "Tool Path Display Required";
                }
                else
                {
                    aToolPathDisplayed = "Tool Path Display Not Required";
                }
                string aProgFolder = textBox5.Text;
                string aProject = textBox1.Text;
                string aRevision = comboBox2.Text;
                string aCostumer = comboBox5.Text;
                string aMachine = comboBox1.Text;

                string aInstructions = textBox2.Text;
                aInstructions = aInstructions.Replace("\n", "</br>");
                aInstructions = aInstructions.Replace(",", "##");

                string aDatum = textBox3.Text;
                aDatum = aDatum.Replace("\n", "</br>");
                aDatum = aDatum.Replace(",", "##");

                string aWorkHolding = comboBox6.Text;
                aWorkHolding = aWorkHolding.Replace("\n", "</br>");
                aWorkHolding = aWorkHolding.Replace(",", "##");

                string aAsOpp = comboBox3.Text;

                string aNotes = textBox4.Text;
                aNotes = aNotes.Replace("\n", "</br>");
                aNotes = aNotes.Replace(",", "##");


                // JOB NOTES
                // 


                // PART NAME

                string jB_PartName = textBox26.Text;


                // Note 1
                string jobNote1 = textBox6.Text;
                jobNote1 = jobNote1.Replace("\n", "</br>");
                jobNote1 = jobNote1.Replace(",", "##");

                string jobNote1_D_Ref = textBox7.Text;


                // Note 2
                string jobNote2 = textBox9.Text;
                jobNote2 = jobNote2.Replace("\n", "</br>");
                jobNote2 = jobNote2.Replace(",", "##");

                string jobNote2_D_Ref = textBox8.Text;
                // Note 3
                string jobNote3 = textBox11.Text;
                jobNote3 = jobNote3.Replace("\n", "</br>");
                jobNote3 = jobNote3.Replace(",", "##");

                string jobNote3_D_Ref = textBox10.Text;
                // Note 4
                string jobNote4 = textBox13.Text;
                jobNote4 = jobNote4.Replace("\n", "</br>");
                jobNote4 = jobNote4.Replace(",", "##");

                string jobNote4_D_Ref = textBox12.Text;


                // Note 5
                string jobNote5 = textBox15.Text;
                jobNote5 = jobNote5.Replace("\n", "</br>");
                jobNote5 = jobNote5.Replace(",", "##");

                string jobNote5_D_Ref = textBox14.Text;

                // Note 6
                string jobNote6 = textBox17.Text;
                jobNote6 = jobNote6.Replace("\n", "</br>");
                jobNote6 = jobNote6.Replace(",", "##");

                string jobNote6_D_Ref = textBox16.Text;

                // Note 7
                string jobNote7 = textBox19.Text;
                jobNote7 = jobNote7.Replace("\n", "</br>");
                jobNote7 = jobNote7.Replace(",", "##");

                string jobNote7_D_Ref = textBox18.Text;

                // Note 8
                string jobNote8 = textBox21.Text;
                jobNote8 = jobNote8.Replace("\n", "</br>");
                jobNote8 = jobNote8.Replace(",", "##");

                string jobNote8_D_Ref = textBox20.Text;

                // Note 9
                string jobNote9 = textBox23.Text;
                jobNote9 = jobNote9.Replace("\n", "</br>");
                jobNote9 = jobNote9.Replace(",", "##");

                string jobNote9_D_Ref = textBox22.Text;

                // Note 10
                string jobNote10 = textBox25.Text;
                jobNote10 = jobNote10.Replace("\n", "</br>");
                jobNote10 = jobNote10.Replace(",", "##");

                string jobNote10_D_Ref = textBox24.Text;



                string username = Environment.UserName;
                username = username.Replace(".", "");
                string path = @"S:\CAD_Office\Muhsin\NXOPEN\NX_OWI_Automation\WI_DATA\WorkInstructionsData-" + username + ".txt";
                string path1 = @"S:\CAD_Office\Muhsin\NXOPEN\NX_OWI_Automation\WI_DATA\WorkInstructionsData_" + textBox5.Text + ".txt";
                File.WriteAllLines(path, new[] { "-1- " + aProject + " -1-" });
                File.AppendAllLines(path, new[] { "-2- " + aProgFolder + " -2-" });
                File.AppendAllLines(path, new[] { "-3- " + aRevision + " -3-" });
                File.AppendAllLines(path, new[] { "-4- " + aCostumer + " -4-" });
                File.AppendAllLines(path, new[] { "-5- " + aMachine + " -5-" });
                File.AppendAllLines(path, new[] { "-6- " + aInstructions + " -6-" });
                File.AppendAllLines(path, new[] { "-7- " + aDatum + " -7-" });
                File.AppendAllLines(path, new[] { "-8- " + aWorkHolding + " -8-" });
                File.AppendAllLines(path, new[] { "-9- " + aAsOpp + " -9-" });
                File.AppendAllLines(path, new[] { "-10- " + aNotes + " -10-" });
                File.AppendAllLines(path, new[] { "-11- " + aToolPathDisplayed + " -11-" });
                File.AppendAllLines(path, new[] { "-12- " + jobNote1 + " -12-" });
                File.AppendAllLines(path, new[] { "-13- " + jobNote2 + " -13-" });
                File.AppendAllLines(path, new[] { "-14- " + jobNote3 + " -14-" });
                File.AppendAllLines(path, new[] { "-15- " + jobNote4 + " -15-" });
                File.AppendAllLines(path, new[] { "-16- " + jobNote5 + " -16-" });
                File.AppendAllLines(path, new[] { "-17- " + jobNote6 + " -17-" });
                File.AppendAllLines(path, new[] { "-18- " + jobNote7 + " -18-" });
                File.AppendAllLines(path, new[] { "-19- " + jobNote8 + " -19-" });
                File.AppendAllLines(path, new[] { "-20- " + jobNote9 + " -20-" });
                File.AppendAllLines(path, new[] { "-21- " + jobNote10 + " -21-" });
                File.AppendAllLines(path, new[] { "-22- " + jobNote1_D_Ref + " -22-" });
                File.AppendAllLines(path, new[] { "-23- " + jobNote2_D_Ref + " -23-" });
                File.AppendAllLines(path, new[] { "-24- " + jobNote3_D_Ref + " -24-" });
                File.AppendAllLines(path, new[] { "-25- " + jobNote4_D_Ref + " -25-" });
                File.AppendAllLines(path, new[] { "-26- " + jobNote5_D_Ref + " -26-" });
                File.AppendAllLines(path, new[] { "-27- " + jobNote6_D_Ref + " -27-" });
                File.AppendAllLines(path, new[] { "-28- " + jobNote7_D_Ref + " -28-" });
                File.AppendAllLines(path, new[] { "-29- " + jobNote8_D_Ref + " -29-" });
                File.AppendAllLines(path, new[] { "-30- " + jobNote9_D_Ref + " -30-" });
                File.AppendAllLines(path, new[] { "-31- " + jobNote10_D_Ref + " -31-" });
                File.AppendAllLines(path, new[] { "-33- " + jB_PartName + " -33-" });




                File.WriteAllLines(path1, new[] { "Project:" + aProject });
                File.AppendAllLines(path1, new[] { "ProgramFolder:" + aProgFolder });
                File.AppendAllLines(path1, new[] { "Revision:" + aRevision });
                File.AppendAllLines(path1, new[] { "Costumer:" + aCostumer });
                File.AppendAllLines(path1, new[] { "Machine:" + aMachine });
                File.AppendAllLines(path1, new[] { "Instructions:" + aInstructions });
                File.AppendAllLines(path1, new[] { "Datum:" + aDatum });
                File.AppendAllLines(path1, new[] { "WorkHold:" + aWorkHolding });
                File.AppendAllLines(path1, new[] { "AsOpp:" + aAsOpp });
                File.AppendAllLines(path1, new[] { "Notes:" + aNotes });
                File.AppendAllLines(path1, new[] { "JobNote1:" + jobNote1 });
                File.AppendAllLines(path1, new[] { "JobNote2:" + jobNote2 });
                File.AppendAllLines(path1, new[] { "JobNote3:" + jobNote3 });
                File.AppendAllLines(path1, new[] { "JobNote4:" + jobNote4 });
                File.AppendAllLines(path1, new[] { "JobNote5:" + jobNote5 });
                File.AppendAllLines(path1, new[] { "JobNote6:" + jobNote6 });
                File.AppendAllLines(path1, new[] { "JobNote7:" + jobNote7 });
                File.AppendAllLines(path1, new[] { "JobNote8:" + jobNote8 });
                File.AppendAllLines(path1, new[] { "JobNote9:" + jobNote9 });
                File.AppendAllLines(path1, new[] { "JobNote10:" + jobNote10 });
                File.AppendAllLines(path1, new[] { "JobNote1_D_Ref:" + jobNote1_D_Ref });
                File.AppendAllLines(path1, new[] { "JobNote2_D_Ref:" + jobNote2_D_Ref });
                File.AppendAllLines(path1, new[] { "JobNote3_D_Ref:" + jobNote3_D_Ref });
                File.AppendAllLines(path1, new[] { "JobNote4_D_Ref:" + jobNote4_D_Ref });
                File.AppendAllLines(path1, new[] { "JobNote5_D_Ref:" + jobNote5_D_Ref });
                File.AppendAllLines(path1, new[] { "JobNote6_D_Ref:" + jobNote6_D_Ref });
                File.AppendAllLines(path1, new[] { "JobNote7_D_Ref:" + jobNote7_D_Ref });
                File.AppendAllLines(path1, new[] { "JobNote8_D_Ref:" + jobNote8_D_Ref });
                File.AppendAllLines(path1, new[] { "JobNote9_D_Ref:" + jobNote9_D_Ref });
                File.AppendAllLines(path1, new[] { "JobNote10_D_Ref:" + jobNote10_D_Ref });
                File.AppendAllLines(path1, new[] { "JBPartName:" + jB_PartName });

                if (checkBox2.Checked)
                {

                    File.AppendAllLines(path, new[] { "-32- YES -32-" });
                    File.AppendAllLines(path1, new[] { "JobNoteReq:YES" });
                }
                else
                {
                    File.AppendAllLines(path, new[] { "-32- NO -32-" });
                    File.AppendAllLines(path1, new[] { "JobNoteReq:NO" });
                }




                MessageBox.Show("Required data captured.", "Evtec Superlight - Work Instructions", MessageBoxButtons.OK);
                System.Windows.Forms.Application.Exit();
            }
            else
            {
                if (MessageBox.Show("Program Folder parameter required.", "Evtec Superlight - Work Instructions", MessageBoxButtons.OK) == DialogResult.OK)
                {
                    this.Activate();
                }
            }

        }








        private void button2_Click(object sender, EventArgs e)


        {
            string username = Environment.UserName;
            username = username.Replace(".", "");
            string path = @"S:\CAD_Office\Muhsin\NXOPEN\NX_OWI_Automation\WI_DATA\WorkInstructionsData-" + username + ".txt";
            string aUserCancel = "USER CANCELLED";
            File.WriteAllLines(path, new[] { aUserCancel });





            if (MessageBox.Show("This will close down the whole application. Confirm?", "Evtec Superlight - Work Instructions", MessageBoxButtons.OKCancel) == DialogResult.OK)
            {
                System.Windows.Forms.Application.Exit();
            }
            else
            {
                this.Activate();
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            LoadDataFromFile();
        }

        private void openFileDialog1_FileOk(object sender, System.ComponentModel.CancelEventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            // Create a new instance of the OpenFileDialog
            OpenFileDialog openFileDialog = new OpenFileDialog();

            // Set some properties
            openFileDialog.Title = "Select a file";
            openFileDialog.InitialDirectory = @"C:\";  // Starting directory
            openFileDialog.Multiselect = true;

            // Show the dialog and check if the user clicks OK
            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                // Get the selected file path
                string filePath = openFileDialog.FileName;

                // Display the file path (you can replace this with any action you'd like)
                MessageBox.Show("Selected file: " + filePath);
            }
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {
            panel1.Visible = checkBox2.Checked;


            if (checkBox2.Checked)
            {

                this.Size = new Size(1163, 863);
            }
            else
            {
                // Revert back to the original size when unchecked
                this.Size = new Size(607, 863); // Adjust the original size as per your requirement
            }
        }

        private void button4_Click_1(object sender, EventArgs e)
        {


            string username = Environment.UserName;
            username = username.Replace(".", "");
            string path = @"S:\CAD_Office\Muhsin\NXOPEN\NX_OWI_Automation\WI_DATA\WorkInstructionsData-" + username + ".txt";
            string aUserCancel = "USER CANCELLED";
            File.WriteAllLines(path, new[] { aUserCancel });


            if (MessageBox.Show("This will save your data and close the application. Confirm?", "Evtec Superlight - Work Instructions", MessageBoxButtons.OKCancel) == DialogResult.OK)
            {
                if (textBox5.Text != "")
                {
                    string aToolPathDisplayed;
                    if (checkBox1.Checked)
                    {
                        aToolPathDisplayed = "Tool Path Display Required";
                    }
                    else
                    {
                        aToolPathDisplayed = "Tool Path Display Not Required";
                    }
                    string aProgFolder = textBox5.Text;
                    string aProject = textBox1.Text;
                    string aRevision = comboBox2.Text;
                    string aCostumer = comboBox5.Text;
                    string aMachine = comboBox1.Text;

                    string aInstructions = textBox2.Text;
                    aInstructions = aInstructions.Replace("\n", "</br>");
                    aInstructions = aInstructions.Replace(",", "##");

                    string aDatum = textBox3.Text;
                    aDatum = aDatum.Replace("\n", "</br>");
                    aDatum = aDatum.Replace(",", "##");

                    string aWorkHolding = comboBox6.Text;
                    aWorkHolding = aWorkHolding.Replace("\n", "</br>");
                    aWorkHolding = aWorkHolding.Replace(",", "##");

                    string aAsOpp = comboBox3.Text;

                    string aNotes = textBox4.Text;
                    aNotes = aNotes.Replace("\n", "</br>");
                    aNotes = aNotes.Replace(",", "##");


                    // JOB NOTES
                    // 


                    // PART NAME

                    string jB_PartName = textBox26.Text;


                    // Note 1
                    string jobNote1 = textBox6.Text;
                    jobNote1 = jobNote1.Replace("\n", "</br>");
                    jobNote1 = jobNote1.Replace(",", "##");

                    string jobNote1_D_Ref = textBox7.Text;


                    // Note 2
                    string jobNote2 = textBox9.Text;
                    jobNote2 = jobNote2.Replace("\n", "</br>");
                    jobNote2 = jobNote2.Replace(",", "##");

                    string jobNote2_D_Ref = textBox8.Text;
                    // Note 3
                    string jobNote3 = textBox11.Text;
                    jobNote3 = jobNote3.Replace("\n", "</br>");
                    jobNote3 = jobNote3.Replace(",", "##");

                    string jobNote3_D_Ref = textBox10.Text;
                    // Note 4
                    string jobNote4 = textBox13.Text;
                    jobNote4 = jobNote4.Replace("\n", "</br>");
                    jobNote4 = jobNote4.Replace(",", "##");

                    string jobNote4_D_Ref = textBox12.Text;


                    // Note 5
                    string jobNote5 = textBox15.Text;
                    jobNote5 = jobNote5.Replace("\n", "</br>");
                    jobNote5 = jobNote5.Replace(",", "##");

                    string jobNote5_D_Ref = textBox14.Text;

                    // Note 6
                    string jobNote6 = textBox17.Text;
                    jobNote6 = jobNote6.Replace("\n", "</br>");
                    jobNote6 = jobNote6.Replace(",", "##");

                    string jobNote6_D_Ref = textBox16.Text;

                    // Note 7
                    string jobNote7 = textBox19.Text;
                    jobNote7 = jobNote7.Replace("\n", "</br>");
                    jobNote7 = jobNote7.Replace(",", "##");

                    string jobNote7_D_Ref = textBox18.Text;

                    // Note 8
                    string jobNote8 = textBox21.Text;
                    jobNote8 = jobNote8.Replace("\n", "</br>");
                    jobNote8 = jobNote8.Replace(",", "##");

                    string jobNote8_D_Ref = textBox20.Text;

                    // Note 9
                    string jobNote9 = textBox23.Text;
                    jobNote9 = jobNote9.Replace("\n", "</br>");
                    jobNote9 = jobNote9.Replace(",", "##");

                    string jobNote9_D_Ref = textBox22.Text;

                    // Note 10
                    string jobNote10 = textBox25.Text;
                    jobNote10 = jobNote10.Replace("\n", "</br>");
                    jobNote10 = jobNote10.Replace(",", "##");

                    string jobNote10_D_Ref = textBox24.Text;





                    string path1 = @"S:\CAD_Office\Muhsin\NXOPEN\NX_OWI_Automation\WI_DATA\WorkInstructionsData_" + textBox5.Text + ".txt";

                    File.WriteAllLines(path1, new[] { "Project:" + aProject });
                    File.AppendAllLines(path1, new[] { "ProgramFolder:" + aProgFolder });
                    File.AppendAllLines(path1, new[] { "Revision:" + aRevision });
                    File.AppendAllLines(path1, new[] { "Costumer:" + aCostumer });
                    File.AppendAllLines(path1, new[] { "Machine:" + aMachine });
                    File.AppendAllLines(path1, new[] { "Instructions:" + aInstructions });
                    File.AppendAllLines(path1, new[] { "Datum:" + aDatum });
                    File.AppendAllLines(path1, new[] { "WorkHold:" + aWorkHolding });
                    File.AppendAllLines(path1, new[] { "AsOpp:" + aAsOpp });
                    File.AppendAllLines(path1, new[] { "Notes:" + aNotes });
                    File.AppendAllLines(path1, new[] { "JobNote1:" + jobNote1 });
                    File.AppendAllLines(path1, new[] { "JobNote2:" + jobNote2 });
                    File.AppendAllLines(path1, new[] { "JobNote3:" + jobNote3 });
                    File.AppendAllLines(path1, new[] { "JobNote4:" + jobNote4 });
                    File.AppendAllLines(path1, new[] { "JobNote5:" + jobNote5 });
                    File.AppendAllLines(path1, new[] { "JobNote6:" + jobNote6 });
                    File.AppendAllLines(path1, new[] { "JobNote7:" + jobNote7 });
                    File.AppendAllLines(path1, new[] { "JobNote8:" + jobNote8 });
                    File.AppendAllLines(path1, new[] { "JobNote9:" + jobNote9 });
                    File.AppendAllLines(path1, new[] { "JobNote10:" + jobNote10 });
                    File.AppendAllLines(path1, new[] { "JobNote1_D_Ref:" + jobNote1_D_Ref });
                    File.AppendAllLines(path1, new[] { "JobNote2_D_Ref:" + jobNote2_D_Ref });
                    File.AppendAllLines(path1, new[] { "JobNote3_D_Ref:" + jobNote3_D_Ref });
                    File.AppendAllLines(path1, new[] { "JobNote4_D_Ref:" + jobNote4_D_Ref });
                    File.AppendAllLines(path1, new[] { "JobNote5_D_Ref:" + jobNote5_D_Ref });
                    File.AppendAllLines(path1, new[] { "JobNote6_D_Ref:" + jobNote6_D_Ref });
                    File.AppendAllLines(path1, new[] { "JobNote7_D_Ref:" + jobNote7_D_Ref });
                    File.AppendAllLines(path1, new[] { "JobNote8_D_Ref:" + jobNote8_D_Ref });
                    File.AppendAllLines(path1, new[] { "JobNote9_D_Ref:" + jobNote9_D_Ref });
                    File.AppendAllLines(path1, new[] { "JobNote10_D_Ref:" + jobNote10_D_Ref });
                    File.AppendAllLines(path1, new[] { "JBPartName:" + jB_PartName });

                    if (checkBox2.Checked)
                    {


                        File.AppendAllLines(path1, new[] { "JobNoteReq:YES" });
                    }
                    else
                    {

                        File.AppendAllLines(path1, new[] { "JobNoteReq:NO" });
                    }




                    MessageBox.Show("Data captured and saved.", "Evtec Superlight - Work Instructions", MessageBoxButtons.OK);
                    System.Windows.Forms.Application.Exit();
                }
                else
                {
                    if (MessageBox.Show("Program Folder parameter required.", "Evtec Superlight - Work Instructions", MessageBoxButtons.OK) == DialogResult.OK)
                    {
                        this.Activate();
                    }
                }

                
            }
            else
            {
                this.Activate();
            }
        }
    }
}
