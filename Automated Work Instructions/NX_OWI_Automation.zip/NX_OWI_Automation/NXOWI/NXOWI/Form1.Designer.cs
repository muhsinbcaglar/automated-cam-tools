﻿namespace NXOWI
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            pictureBox1 = new PictureBox();
            comboBox1 = new ComboBox();
            comboBox2 = new ComboBox();
            comboBox5 = new ComboBox();
            textBox1 = new TextBox();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            label6 = new Label();
            label7 = new Label();
            comboBox6 = new ComboBox();
            label8 = new Label();
            label9 = new Label();
            textBox2 = new TextBox();
            textBox3 = new TextBox();
            textBox4 = new TextBox();
            comboBox3 = new ComboBox();
            button1 = new Button();
            button2 = new Button();
            textBox5 = new TextBox();
            label10 = new Label();
            label11 = new Label();
            button3 = new Button();
            label12 = new Label();
            checkBox1 = new CheckBox();
            toolTip1 = new ToolTip(components);
            button4 = new Button();
            panel1 = new Panel();
            label26 = new Label();
            label25 = new Label();
            label24 = new Label();
            label23 = new Label();
            label22 = new Label();
            label21 = new Label();
            label20 = new Label();
            label19 = new Label();
            label18 = new Label();
            label17 = new Label();
            label16 = new Label();
            label15 = new Label();
            textBox26 = new TextBox();
            textBox24 = new TextBox();
            textBox25 = new TextBox();
            textBox22 = new TextBox();
            textBox23 = new TextBox();
            textBox20 = new TextBox();
            textBox21 = new TextBox();
            textBox18 = new TextBox();
            textBox19 = new TextBox();
            textBox16 = new TextBox();
            textBox17 = new TextBox();
            textBox14 = new TextBox();
            textBox15 = new TextBox();
            textBox12 = new TextBox();
            textBox13 = new TextBox();
            textBox10 = new TextBox();
            textBox11 = new TextBox();
            textBox8 = new TextBox();
            textBox9 = new TextBox();
            textBox7 = new TextBox();
            label14 = new Label();
            label13 = new Label();
            textBox6 = new TextBox();
            checkBox2 = new CheckBox();
            label27 = new Label();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            panel1.SuspendLayout();
            SuspendLayout();
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(414, 2);
            pictureBox1.Margin = new Padding(4);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(170, 92);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 0;
            pictureBox1.TabStop = false;
            // 
            // comboBox1
            // 
            comboBox1.FormattingEnabled = true;
            comboBox1.Items.AddRange(new object[] { "Butler", "CMS Antares", "CMS Cronus", "DMU-60", "DMU-70", "DMU-80", "XR", "XYZ" });
            comboBox1.Location = new Point(152, 269);
            comboBox1.Margin = new Padding(4);
            comboBox1.Name = "comboBox1";
            comboBox1.Size = new Size(433, 27);
            comboBox1.TabIndex = 5;
            // 
            // comboBox2
            // 
            comboBox2.AutoCompleteMode = AutoCompleteMode.Suggest;
            comboBox2.FormattingEnabled = true;
            comboBox2.Items.AddRange(new object[] { "01", "02", "03", "04", "05", "A", "B", "C" });
            comboBox2.Location = new Point(152, 184);
            comboBox2.Margin = new Padding(4);
            comboBox2.Name = "comboBox2";
            comboBox2.Size = new Size(433, 27);
            comboBox2.TabIndex = 3;
            // 
            // comboBox5
            // 
            comboBox5.FormattingEnabled = true;
            comboBox5.Items.AddRange(new object[] { "2XL", "Airbus", "Alpha Tauri", "Alpine F1", "Aston Martin", "Cobham", "GE Aviation", "GKN", "HAAS", "Hamble", "Ineos", "KWSP", "Mclaren Automotive", "Mclaren F1", "Meggitt", "Mercedes F1", "Mercedes FE", "Mercedes HPP", "Multimatic", "Nio", "Oxford Space", "Plyable", "Renault", "Rolls Royce", "TWR", "Volta", "WAE", "Williams F1", "Zonda" });
            comboBox5.Location = new Point(152, 226);
            comboBox5.Margin = new Padding(4);
            comboBox5.Name = "comboBox5";
            comboBox5.Size = new Size(433, 27);
            comboBox5.TabIndex = 4;
            // 
            // textBox1
            // 
            textBox1.Location = new Point(152, 142);
            textBox1.Margin = new Padding(4);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(433, 27);
            textBox1.TabIndex = 2;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(16, 146);
            label1.Margin = new Padding(4, 0, 4, 0);
            label1.Name = "label1";
            label1.Size = new Size(57, 20);
            label1.TabIndex = 7;
            label1.Text = "Project";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(16, 188);
            label2.Margin = new Padding(4, 0, 4, 0);
            label2.Name = "label2";
            label2.Size = new Size(66, 20);
            label2.TabIndex = 8;
            label2.Text = "Revision";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(16, 395);
            label3.Margin = new Padding(4, 0, 4, 0);
            label3.Name = "label3";
            label3.Size = new Size(55, 20);
            label3.TabIndex = 9;
            label3.Text = "Datum";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(16, 470);
            label4.Margin = new Padding(4, 0, 4, 0);
            label4.Name = "label4";
            label4.Size = new Size(105, 20);
            label4.TabIndex = 10;
            label4.Text = "Work Holding";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(16, 272);
            label5.Margin = new Padding(4, 0, 4, 0);
            label5.Name = "label5";
            label5.Size = new Size(68, 20);
            label5.TabIndex = 11;
            label5.Text = "Machine";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(16, 320);
            label6.Margin = new Padding(4, 0, 4, 0);
            label6.Name = "label6";
            label6.Size = new Size(88, 20);
            label6.TabIndex = 12;
            label6.Text = "Instructions";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(16, 230);
            label7.Margin = new Padding(4, 0, 4, 0);
            label7.Name = "label7";
            label7.Size = new Size(74, 20);
            label7.TabIndex = 13;
            label7.Text = "Customer";
            // 
            // comboBox6
            // 
            comboBox6.FormattingEnabled = true;
            comboBox6.Items.AddRange(new object[] { "77MM LANG VICE", "125mm LANG VICE" });
            comboBox6.Location = new Point(152, 466);
            comboBox6.Margin = new Padding(4);
            comboBox6.Name = "comboBox6";
            comboBox6.Size = new Size(433, 27);
            comboBox6.TabIndex = 8;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(16, 512);
            label8.Margin = new Padding(4, 0, 4, 0);
            label8.Name = "label8";
            label8.Size = new Size(99, 20);
            label8.TabIndex = 15;
            label8.Text = "AS/OPP Req?";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(16, 555);
            label9.Margin = new Padding(4, 0, 4, 0);
            label9.Name = "label9";
            label9.Size = new Size(49, 20);
            label9.TabIndex = 16;
            label9.Text = "Notes";
            // 
            // textBox2
            // 
            textBox2.Location = new Point(152, 316);
            textBox2.Margin = new Padding(4);
            textBox2.Multiline = true;
            textBox2.Name = "textBox2";
            textBox2.ScrollBars = ScrollBars.Vertical;
            textBox2.Size = new Size(433, 66);
            textBox2.TabIndex = 6;
            // 
            // textBox3
            // 
            textBox3.Location = new Point(152, 391);
            textBox3.Margin = new Padding(4);
            textBox3.Multiline = true;
            textBox3.Name = "textBox3";
            textBox3.ScrollBars = ScrollBars.Vertical;
            textBox3.Size = new Size(433, 66);
            textBox3.TabIndex = 7;
            // 
            // textBox4
            // 
            textBox4.Location = new Point(152, 551);
            textBox4.Margin = new Padding(4);
            textBox4.Multiline = true;
            textBox4.Name = "textBox4";
            textBox4.ScrollBars = ScrollBars.Vertical;
            textBox4.Size = new Size(433, 66);
            textBox4.TabIndex = 10;
            // 
            // comboBox3
            // 
            comboBox3.FormattingEnabled = true;
            comboBox3.Items.AddRange(new object[] { "YES - Symmetrically Opposite", "NO" });
            comboBox3.Location = new Point(152, 509);
            comboBox3.Margin = new Padding(4);
            comboBox3.Name = "comboBox3";
            comboBox3.Size = new Size(433, 27);
            comboBox3.TabIndex = 9;
            // 
            // button1
            // 
            button1.Location = new Point(468, 776);
            button1.Margin = new Padding(4);
            button1.Name = "button1";
            button1.Size = new Size(118, 36);
            button1.TabIndex = 12;
            button1.Text = "Create";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // button2
            // 
            button2.Location = new Point(216, 776);
            button2.Margin = new Padding(4);
            button2.Name = "button2";
            button2.Size = new Size(118, 36);
            button2.TabIndex = 11;
            button2.Text = "Cancel";
            toolTip1.SetToolTip(button2, "test");
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // textBox5
            // 
            textBox5.AccessibleName = "";
            textBox5.Location = new Point(152, 102);
            textBox5.Margin = new Padding(4);
            textBox5.Name = "textBox5";
            textBox5.Size = new Size(383, 27);
            textBox5.TabIndex = 1;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Location = new Point(16, 105);
            label10.Margin = new Padding(4, 0, 4, 0);
            label10.Name = "label10";
            label10.Size = new Size(94, 20);
            label10.TabIndex = 24;
            label10.Text = "Prog. Folder";
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.ForeColor = Color.DarkSlateGray;
            label11.Location = new Point(116, 691);
            label11.Margin = new Padding(4, 0, 4, 0);
            label11.Name = "label11";
            label11.Size = new Size(470, 80);
            label11.TabIndex = 25;
            label11.Text = "Please ensure that the Prog. Folder parameter entered matches the \r\nprogram folder name on NX.\r\nClick CREATE to begin work instruction builder.\r\nClick CANCEL to exit the program.";
            label11.TextAlign = ContentAlignment.TopRight;
            // 
            // button3
            // 
            button3.Image = (Image)resources.GetObject("button3.Image");
            button3.Location = new Point(542, 98);
            button3.Margin = new Padding(4);
            button3.Name = "button3";
            button3.Size = new Size(42, 38);
            button3.TabIndex = 26;
            button3.TextImageRelation = TextImageRelation.ImageBeforeText;
            button3.UseMnemonic = false;
            button3.UseVisualStyleBackColor = true;
            button3.Click += button3_Click;
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Location = new Point(342, 652);
            label12.Name = "label12";
            label12.Size = new Size(223, 20);
            label12.TabIndex = 27;
            label12.Text = "Create Tool Path Display Sheets";
            // 
            // checkBox1
            // 
            checkBox1.AutoSize = true;
            checkBox1.Location = new Point(571, 655);
            checkBox1.Name = "checkBox1";
            checkBox1.Size = new Size(15, 14);
            checkBox1.TabIndex = 28;
            checkBox1.UseVisualStyleBackColor = true;
            checkBox1.CheckedChanged += checkBox1_CheckedChanged;
            // 
            // button4
            // 
            button4.Location = new Point(342, 776);
            button4.Margin = new Padding(4);
            button4.Name = "button4";
            button4.Size = new Size(118, 36);
            button4.TabIndex = 32;
            button4.Text = "Save && Exit";
            toolTip1.SetToolTip(button4, "test");
            button4.UseVisualStyleBackColor = true;
            button4.Click += button4_Click_1;
            // 
            // panel1
            // 
            panel1.Controls.Add(label26);
            panel1.Controls.Add(label25);
            panel1.Controls.Add(label24);
            panel1.Controls.Add(label23);
            panel1.Controls.Add(label22);
            panel1.Controls.Add(label21);
            panel1.Controls.Add(label20);
            panel1.Controls.Add(label19);
            panel1.Controls.Add(label18);
            panel1.Controls.Add(label17);
            panel1.Controls.Add(label16);
            panel1.Controls.Add(label15);
            panel1.Controls.Add(textBox26);
            panel1.Controls.Add(textBox24);
            panel1.Controls.Add(textBox25);
            panel1.Controls.Add(textBox22);
            panel1.Controls.Add(textBox23);
            panel1.Controls.Add(textBox20);
            panel1.Controls.Add(textBox21);
            panel1.Controls.Add(textBox18);
            panel1.Controls.Add(textBox19);
            panel1.Controls.Add(textBox16);
            panel1.Controls.Add(textBox17);
            panel1.Controls.Add(textBox14);
            panel1.Controls.Add(textBox15);
            panel1.Controls.Add(textBox12);
            panel1.Controls.Add(textBox13);
            panel1.Controls.Add(textBox10);
            panel1.Controls.Add(textBox11);
            panel1.Controls.Add(textBox8);
            panel1.Controls.Add(textBox9);
            panel1.Controls.Add(textBox7);
            panel1.Controls.Add(label14);
            panel1.Controls.Add(label13);
            panel1.Controls.Add(textBox6);
            panel1.Location = new Point(592, 98);
            panel1.Name = "panel1";
            panel1.Size = new Size(545, 714);
            panel1.TabIndex = 29;
            panel1.Visible = false;
            // 
            // label26
            // 
            label26.AutoSize = true;
            label26.Location = new Point(8, 644);
            label26.Margin = new Padding(4, 0, 4, 0);
            label26.Name = "label26";
            label26.Size = new Size(23, 20);
            label26.TabIndex = 59;
            label26.Text = "10";
            // 
            // label25
            // 
            label25.AutoSize = true;
            label25.Location = new Point(8, 582);
            label25.Margin = new Padding(4, 0, 4, 0);
            label25.Name = "label25";
            label25.Size = new Size(17, 20);
            label25.TabIndex = 58;
            label25.Text = "9";
            // 
            // label24
            // 
            label24.AutoSize = true;
            label24.Location = new Point(8, 520);
            label24.Margin = new Padding(4, 0, 4, 0);
            label24.Name = "label24";
            label24.Size = new Size(17, 20);
            label24.TabIndex = 57;
            label24.Text = "8";
            // 
            // label23
            // 
            label23.AutoSize = true;
            label23.Location = new Point(8, 458);
            label23.Margin = new Padding(4, 0, 4, 0);
            label23.Name = "label23";
            label23.Size = new Size(17, 20);
            label23.TabIndex = 56;
            label23.Text = "7";
            // 
            // label22
            // 
            label22.AutoSize = true;
            label22.Location = new Point(8, 396);
            label22.Margin = new Padding(4, 0, 4, 0);
            label22.Name = "label22";
            label22.Size = new Size(17, 20);
            label22.TabIndex = 55;
            label22.Text = "6";
            // 
            // label21
            // 
            label21.AutoSize = true;
            label21.Location = new Point(8, 334);
            label21.Margin = new Padding(4, 0, 4, 0);
            label21.Name = "label21";
            label21.Size = new Size(17, 20);
            label21.TabIndex = 54;
            label21.Text = "5";
            // 
            // label20
            // 
            label20.AutoSize = true;
            label20.Location = new Point(8, 272);
            label20.Margin = new Padding(4, 0, 4, 0);
            label20.Name = "label20";
            label20.Size = new Size(18, 20);
            label20.TabIndex = 53;
            label20.Text = "4";
            // 
            // label19
            // 
            label19.AutoSize = true;
            label19.Location = new Point(8, 210);
            label19.Margin = new Padding(4, 0, 4, 0);
            label19.Name = "label19";
            label19.Size = new Size(17, 20);
            label19.TabIndex = 52;
            label19.Text = "3";
            // 
            // label18
            // 
            label18.AutoSize = true;
            label18.Location = new Point(8, 148);
            label18.Margin = new Padding(4, 0, 4, 0);
            label18.Name = "label18";
            label18.Size = new Size(17, 20);
            label18.TabIndex = 51;
            label18.Text = "2";
            // 
            // label17
            // 
            label17.AutoSize = true;
            label17.Location = new Point(430, 61);
            label17.Margin = new Padding(4, 0, 4, 0);
            label17.Name = "label17";
            label17.Size = new Size(103, 20);
            label17.TabIndex = 50;
            label17.Text = "DWG Grid Ref";
            // 
            // label16
            // 
            label16.AutoSize = true;
            label16.Location = new Point(31, 61);
            label16.Margin = new Padding(4, 0, 4, 0);
            label16.Name = "label16";
            label16.Size = new Size(43, 20);
            label16.TabIndex = 49;
            label16.Text = "Note";
            // 
            // label15
            // 
            label15.AutoSize = true;
            label15.Location = new Point(31, 33);
            label15.Margin = new Padding(4, 0, 4, 0);
            label15.Name = "label15";
            label15.Size = new Size(82, 20);
            label15.TabIndex = 48;
            label15.Text = "Part Name";
            // 
            // textBox26
            // 
            textBox26.Location = new Point(116, 30);
            textBox26.Margin = new Padding(4);
            textBox26.Name = "textBox26";
            textBox26.Size = new Size(421, 27);
            textBox26.TabIndex = 47;
            // 
            // textBox24
            // 
            textBox24.Location = new Point(430, 644);
            textBox24.Margin = new Padding(4);
            textBox24.Multiline = true;
            textBox24.Name = "textBox24";
            textBox24.ScrollBars = ScrollBars.Vertical;
            textBox24.Size = new Size(107, 27);
            textBox24.TabIndex = 46;
            // 
            // textBox25
            // 
            textBox25.Location = new Point(31, 644);
            textBox25.Margin = new Padding(4);
            textBox25.Multiline = true;
            textBox25.Name = "textBox25";
            textBox25.ScrollBars = ScrollBars.Vertical;
            textBox25.Size = new Size(391, 54);
            textBox25.TabIndex = 45;
            // 
            // textBox22
            // 
            textBox22.Location = new Point(430, 582);
            textBox22.Margin = new Padding(4);
            textBox22.Multiline = true;
            textBox22.Name = "textBox22";
            textBox22.ScrollBars = ScrollBars.Vertical;
            textBox22.Size = new Size(107, 27);
            textBox22.TabIndex = 44;
            // 
            // textBox23
            // 
            textBox23.Location = new Point(31, 582);
            textBox23.Margin = new Padding(4);
            textBox23.Multiline = true;
            textBox23.Name = "textBox23";
            textBox23.ScrollBars = ScrollBars.Vertical;
            textBox23.Size = new Size(391, 54);
            textBox23.TabIndex = 43;
            // 
            // textBox20
            // 
            textBox20.Location = new Point(430, 520);
            textBox20.Margin = new Padding(4);
            textBox20.Multiline = true;
            textBox20.Name = "textBox20";
            textBox20.ScrollBars = ScrollBars.Vertical;
            textBox20.Size = new Size(107, 27);
            textBox20.TabIndex = 42;
            // 
            // textBox21
            // 
            textBox21.Location = new Point(31, 520);
            textBox21.Margin = new Padding(4);
            textBox21.Multiline = true;
            textBox21.Name = "textBox21";
            textBox21.ScrollBars = ScrollBars.Vertical;
            textBox21.Size = new Size(391, 54);
            textBox21.TabIndex = 41;
            // 
            // textBox18
            // 
            textBox18.Location = new Point(430, 458);
            textBox18.Margin = new Padding(4);
            textBox18.Multiline = true;
            textBox18.Name = "textBox18";
            textBox18.ScrollBars = ScrollBars.Vertical;
            textBox18.Size = new Size(107, 27);
            textBox18.TabIndex = 40;
            // 
            // textBox19
            // 
            textBox19.Location = new Point(31, 458);
            textBox19.Margin = new Padding(4);
            textBox19.Multiline = true;
            textBox19.Name = "textBox19";
            textBox19.ScrollBars = ScrollBars.Vertical;
            textBox19.Size = new Size(391, 54);
            textBox19.TabIndex = 39;
            // 
            // textBox16
            // 
            textBox16.Location = new Point(430, 396);
            textBox16.Margin = new Padding(4);
            textBox16.Multiline = true;
            textBox16.Name = "textBox16";
            textBox16.ScrollBars = ScrollBars.Vertical;
            textBox16.Size = new Size(107, 27);
            textBox16.TabIndex = 38;
            // 
            // textBox17
            // 
            textBox17.Location = new Point(31, 396);
            textBox17.Margin = new Padding(4);
            textBox17.Multiline = true;
            textBox17.Name = "textBox17";
            textBox17.ScrollBars = ScrollBars.Vertical;
            textBox17.Size = new Size(391, 54);
            textBox17.TabIndex = 37;
            // 
            // textBox14
            // 
            textBox14.Location = new Point(430, 334);
            textBox14.Margin = new Padding(4);
            textBox14.Multiline = true;
            textBox14.Name = "textBox14";
            textBox14.ScrollBars = ScrollBars.Vertical;
            textBox14.Size = new Size(107, 27);
            textBox14.TabIndex = 36;
            // 
            // textBox15
            // 
            textBox15.Location = new Point(31, 334);
            textBox15.Margin = new Padding(4);
            textBox15.Multiline = true;
            textBox15.Name = "textBox15";
            textBox15.ScrollBars = ScrollBars.Vertical;
            textBox15.Size = new Size(391, 54);
            textBox15.TabIndex = 35;
            // 
            // textBox12
            // 
            textBox12.Location = new Point(430, 272);
            textBox12.Margin = new Padding(4);
            textBox12.Multiline = true;
            textBox12.Name = "textBox12";
            textBox12.ScrollBars = ScrollBars.Vertical;
            textBox12.Size = new Size(107, 27);
            textBox12.TabIndex = 34;
            // 
            // textBox13
            // 
            textBox13.Location = new Point(31, 272);
            textBox13.Margin = new Padding(4);
            textBox13.Multiline = true;
            textBox13.Name = "textBox13";
            textBox13.ScrollBars = ScrollBars.Vertical;
            textBox13.Size = new Size(391, 54);
            textBox13.TabIndex = 33;
            // 
            // textBox10
            // 
            textBox10.Location = new Point(430, 210);
            textBox10.Margin = new Padding(4);
            textBox10.Multiline = true;
            textBox10.Name = "textBox10";
            textBox10.ScrollBars = ScrollBars.Vertical;
            textBox10.Size = new Size(107, 27);
            textBox10.TabIndex = 32;
            // 
            // textBox11
            // 
            textBox11.Location = new Point(31, 210);
            textBox11.Margin = new Padding(4);
            textBox11.Multiline = true;
            textBox11.Name = "textBox11";
            textBox11.ScrollBars = ScrollBars.Vertical;
            textBox11.Size = new Size(391, 54);
            textBox11.TabIndex = 31;
            // 
            // textBox8
            // 
            textBox8.Location = new Point(430, 148);
            textBox8.Margin = new Padding(4);
            textBox8.Multiline = true;
            textBox8.Name = "textBox8";
            textBox8.ScrollBars = ScrollBars.Vertical;
            textBox8.Size = new Size(107, 27);
            textBox8.TabIndex = 30;
            // 
            // textBox9
            // 
            textBox9.Location = new Point(31, 148);
            textBox9.Margin = new Padding(4);
            textBox9.Multiline = true;
            textBox9.Name = "textBox9";
            textBox9.ScrollBars = ScrollBars.Vertical;
            textBox9.Size = new Size(391, 54);
            textBox9.TabIndex = 29;
            // 
            // textBox7
            // 
            textBox7.Location = new Point(430, 86);
            textBox7.Margin = new Padding(4);
            textBox7.Multiline = true;
            textBox7.Name = "textBox7";
            textBox7.ScrollBars = ScrollBars.Vertical;
            textBox7.Size = new Size(107, 27);
            textBox7.TabIndex = 28;
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.Location = new Point(8, 86);
            label14.Margin = new Padding(4, 0, 4, 0);
            label14.Name = "label14";
            label14.Size = new Size(15, 20);
            label14.TabIndex = 27;
            label14.Text = "1";
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Location = new Point(8, 7);
            label13.Margin = new Padding(4, 0, 4, 0);
            label13.Name = "label13";
            label13.Size = new Size(77, 20);
            label13.TabIndex = 26;
            label13.Text = "Job Notes";
            // 
            // textBox6
            // 
            textBox6.Location = new Point(31, 86);
            textBox6.Margin = new Padding(4);
            textBox6.Multiline = true;
            textBox6.Name = "textBox6";
            textBox6.ScrollBars = ScrollBars.Vertical;
            textBox6.Size = new Size(391, 54);
            textBox6.TabIndex = 7;
            // 
            // checkBox2
            // 
            checkBox2.AutoSize = true;
            checkBox2.Location = new Point(571, 628);
            checkBox2.Name = "checkBox2";
            checkBox2.Size = new Size(15, 14);
            checkBox2.TabIndex = 31;
            checkBox2.UseVisualStyleBackColor = true;
            checkBox2.CheckedChanged += checkBox2_CheckedChanged;
            // 
            // label27
            // 
            label27.AutoSize = true;
            label27.Location = new Point(414, 625);
            label27.Name = "label27";
            label27.Size = new Size(151, 20);
            label27.TabIndex = 30;
            label27.Text = "Add Job Notes Sheet";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 19F);
            AutoScaleMode = AutoScaleMode.Font;
            AutoSizeMode = AutoSizeMode.GrowAndShrink;
            BackColor = Color.FloralWhite;
            ClientSize = new Size(591, 824);
            ControlBox = false;
            Controls.Add(button4);
            Controls.Add(checkBox2);
            Controls.Add(label27);
            Controls.Add(panel1);
            Controls.Add(checkBox1);
            Controls.Add(label12);
            Controls.Add(button3);
            Controls.Add(label11);
            Controls.Add(label10);
            Controls.Add(textBox5);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(comboBox3);
            Controls.Add(textBox4);
            Controls.Add(textBox3);
            Controls.Add(textBox2);
            Controls.Add(label9);
            Controls.Add(label8);
            Controls.Add(comboBox6);
            Controls.Add(label7);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(textBox1);
            Controls.Add(comboBox5);
            Controls.Add(comboBox2);
            Controls.Add(comboBox1);
            Controls.Add(pictureBox1);
            Font = new Font("Segoe UI Semibold", 10.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            FormBorderStyle = FormBorderStyle.Fixed3D;
            Icon = (Icon)resources.GetObject("$this.Icon");
            Margin = new Padding(4);
            Name = "Form1";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "EVTEC Superlaggera - Work Instructions";
            Load += Form1_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private PictureBox pictureBox1;
        private ComboBox comboBox1;
        private ComboBox comboBox2;
        private ComboBox comboBox5;
        private TextBox textBox1;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label label6;
        private Label label7;
        private ComboBox comboBox6;
        private Label label8;
        private Label label9;
        private TextBox textBox2;
        private TextBox textBox3;
        private TextBox textBox4;
        private ComboBox comboBox3;
        private Button button2;
        private TextBox textBox5;
        private Label label10;
        private Label label11;
        public Button button1;
        public Button button3;
        private Label label12;
        private CheckBox checkBox1;
        private ToolTip toolTip1;
        private Panel panel1;
        private TextBox textBox6;
        private TextBox textBox24;
        private TextBox textBox25;
        private TextBox textBox22;
        private TextBox textBox23;
        private TextBox textBox20;
        private TextBox textBox21;
        private TextBox textBox18;
        private TextBox textBox19;
        private TextBox textBox16;
        private TextBox textBox17;
        private TextBox textBox14;
        private TextBox textBox15;
        private TextBox textBox12;
        private TextBox textBox13;
        private TextBox textBox10;
        private TextBox textBox11;
        private TextBox textBox8;
        private TextBox textBox9;
        private TextBox textBox7;
        private Label label14;
        private Label label13;
        private Label label26;
        private Label label25;
        private Label label24;
        private Label label23;
        private Label label22;
        private Label label21;
        private Label label20;
        private Label label19;
        private Label label18;
        private Label label17;
        private Label label16;
        private Label label15;
        private TextBox textBox26;
        private CheckBox checkBox2;
        private Label label27;
        private Button button4;
    }
}
