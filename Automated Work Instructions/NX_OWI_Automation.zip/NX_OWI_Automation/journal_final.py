﻿




# NX 2312
# Journal created by muhsin.caglar on Thu Aug  1 14:27:33 2024 GMT Summer Time
#
import math
import NXOpen
import NXOpen.CAM
import NXOpen.Display
import subprocess
import NXOpen.Layer
import os
import time
import shutil


### FUNCTION TO TURN PMI'S OFF
def NX_Turn_PMIs_Off():    
    theSession  = NXOpen.Session.GetSession() #type: NXOpen.Session
    workPart = theSession.Parts.Work
    displayPart = theSession.Parts.Display
    objects1 = [NXOpen.CAM.CAMObject.Null] * 1 
    theUI = NXOpen.UI.GetUI() #type: NXOpen.UI 
    ###
    lw = theSession.ListingWindow
    lw.Open()
    ###
    theParts = theSession.Parts
    theWorkPart = theParts.Work
    allPMIObjects = theWorkPart.PmiManager.Pmis
    i = 0
    for p in allPMIObjects:

        Index = p.GetDisplayInstances()[0]
        i = i + 1
        #lw.WriteLine(str(Index))
    #lw.WriteLine(str(i))
    objectArray1 = [NXOpen.DisplayableObject.Null] * i
    
    ii=0
    for p in allPMIObjects:
        Index1 = p.GetDisplayInstances()[0]
        objectArray1[ii] = Index1
        ii = ii + 1
    workPart.Layers.MoveDisplayableObjects(69, objectArray1)
    
    
    
    
    ###
    for p in allPMIObjects:

        Index = p.GetDisplayInstances()[0]
        Index2 = Index.Layer
        #lw.WriteLine(str(Index2))
    ####

    
    
    
    
    ## HIDE ALL PMI'S THAT MOVE TO LAYER 69
    markId1 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    theSession.SetUndoMarkName(markId1, "Layer Settings Dialog")
    
    stateArray1 = [None] * 1 
    stateArray1[0] = NXOpen.Layer.StateInfo()
    stateArray1[0] = NXOpen.Layer.StateInfo(69, NXOpen.Layer.State.Hidden)
    workPart.Layers.ChangeStates(stateArray1, False)
    
    theSession.SetUndoMarkName(markId1, "Layer Settings")
    
    theSession.DeleteUndoMark(markId1, None)
    lw.WriteLine("TURNING PMI'S OFF FOR TOOL PATH DISPLAY SHEETS TO BE PUBLISHED")
    lw.WriteLine("CREATING TOOL PATH DISPLAY SHEETS")
    lw.Close()
    return
    
#FUNCTION TO TURN PMI'S ON  
def NX_Turn_PMIs_On():       
    theSession  = NXOpen.Session.GetSession() #type: NXOpen.Session
    workPart = theSession.Parts.Work
    displayPart = theSession.Parts.Display
    objects1 = [NXOpen.CAM.CAMObject.Null] * 1 
    theUI = NXOpen.UI.GetUI() #type: NXOpen.UI 
    ###
    lw = theSession.ListingWindow
    lw.Open()
    ###
    theParts = theSession.Parts
    theWorkPart = theParts.Work
    allPMIObjects = theWorkPart.PmiManager.Pmis
    i = 0
    for p in allPMIObjects:

        Index = p.GetDisplayInstances()[0]
        i = i + 1
        #lw.WriteLine(str(Index))
    #lw.WriteLine(str(i))
    objectArray1 = [NXOpen.DisplayableObject.Null] * i
    
    ii=0
    for p in allPMIObjects:
        Index1 = p.GetDisplayInstances()[0]
        objectArray1[ii] = Index1
        ii = ii + 1
    workPart.Layers.MoveDisplayableObjects(69, objectArray1)
    
    
    
    
    ###
    for p in allPMIObjects:

        Index = p.GetDisplayInstances()[0]
        Index2 = Index.Layer
        #lw.WriteLine(str(Index2))
    ####
    
    
    
    
    
    ## SHOW ALL PMI'S THAT MOVE TO LAYER 69
    markId1 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    theSession.SetUndoMarkName(markId1, "Layer Settings Dialog")
    
    stateArray1 = [None] * 1 
    stateArray1[0] = NXOpen.Layer.StateInfo()
    stateArray1[0] = NXOpen.Layer.StateInfo(69, NXOpen.Layer.State.Selectable)
    workPart.Layers.ChangeStates(stateArray1, False)
    
    theSession.SetUndoMarkName(markId1, "Layer Settings")
    
    theSession.DeleteUndoMark(markId1, None)
    lw.WriteLine("TOOL PATH DISPLAY SHEETS COMPLETED")
    lw.WriteLine("TURNING ON PMI'S TO CONTINUE PUBLISHING WORK INSTRUCTIONS")
    lw.Close()
    return 

###MAIN FUNCTION
def main() : 
    exe_path = "S:\\CAD_Office\\Muhsin\\NXOPEN\\NX_OWI_Automation\\NXOWI\\NXOWI\\bin\\Release\\net8.0-windows\\NXOWI.exe"
    subprocess.run([exe_path], capture_output=True, text=True, check=True)

    theSession = NXOpen.Session.GetSession()
    theSession.Parts.LoadOptions.UsePartialLoading = False

    displayPart = theSession.Parts.Display
    workPart = theSession.Parts.Work
    FilePath = str(theSession.Parts.Work.FullPath)
    camSession = theSession.CreateCamSession()
    start_point = workPart.CAMSetup.CAMOperationCollection.FindObject("NC_PROGRAM")
    objects_at_start = NXOpen.CAM.NCGroup.GetMembers(start_point)

    lw = theSession.ListingWindow
    lw.Open()


    with open("S:\\CAD_Office\\Muhsin\\NXOPEN\\NX_OWI_Automation\\WI_DATA\\WorkInstructionsData.txt") as file:
        lines = [line.rstrip() for line in file]
        if 'USER CANCELLED' in lines:
            return
    WI_DATA = str(lines)
    
    WI_DATA = WI_DATA.replace("'","")
    WI_DATA = WI_DATA.replace("[","")   
    WI_DATA = WI_DATA.replace("]","")
    ##text_file1.write(WI_DATA)
    start_index = WI_DATA.rindex("-1- ")
    end_index = WI_DATA.rindex(" -1-")
    Project_Name = WI_DATA[start_index + 4: end_index]
    
    start_index = WI_DATA.rindex("-2- ")
    end_index = WI_DATA.rindex(" -2-")
    Program_Folder = WI_DATA[start_index + 4: end_index]
    
    start_index = WI_DATA.rindex("-3- ")
    end_index = WI_DATA.rindex(" -3-")
    Rev_No = WI_DATA[start_index + 4: end_index]
    
    start_index = WI_DATA.rindex("-4- ")
    end_index = WI_DATA.rindex(" -4-")
    Costumer_Name = WI_DATA[start_index + 4: end_index]

    start_index = WI_DATA.rindex("-5- ")
    end_index = WI_DATA.rindex(" -5-")
    Machine_Name = WI_DATA[start_index + 4: end_index]
    
    start_index = WI_DATA.rindex("-6- ")
    end_index = WI_DATA.rindex(" -6-")
    Instructions_Text = WI_DATA[start_index + 4: end_index]
    ##text_file1.write(Instructions_Text)
    
    Instructions_Text = Instructions_Text.replace(",","")
    Instructions_Text = Instructions_Text.replace("##",",")
    
    
    
    ##text_file.write(Instructions_Text)
    start_index = WI_DATA.rindex("-7- ")
    end_index = WI_DATA.rindex(" -7-")
    Datum_Info = WI_DATA[start_index + 4: end_index]
    Datum_Info = Datum_Info.replace(",","")
    Datum_Info = Datum_Info.replace("##",",")    
    
    
    start_index = WI_DATA.rindex("-8- ")
    end_index = WI_DATA.rindex(" -8-")
    WorkHold_Info = WI_DATA[start_index + 4: end_index]
    WorkHold_Info = WorkHold_Info.replace(",","")
    WorkHold_Info = WorkHold_Info.replace("##",",")    
    
    
    
    
    start_index = WI_DATA.rindex("-9- ")
    end_index = WI_DATA.rindex(" -9-")
    AsOpp_Info = WI_DATA[start_index + 4: end_index]
    
    start_index = WI_DATA.rindex("-10- ")
    end_index = WI_DATA.rindex(" -10-")
    Notes_Text = WI_DATA[start_index + 4: end_index]
    Notes_Text = Notes_Text.replace(",","")
    Notes_Text = Notes_Text.replace("##",",")

    start_index = WI_DATA.rindex("-11- ")
    end_index = WI_DATA.rindex(" -11-")
    TPDSheetsReq = WI_DATA[start_index + 4: end_index]


    
    
    fp_index = FilePath.rindex("\\")
    
    FilePath1 = FilePath[:fp_index+1]
    FilePath = FilePath.replace("\\","\\\\")
    
 
    pdfdirectory = str(FilePath1 + "Work Instructions\\")
    pdfdirectory2 = str(pdfdirectory + "Tool Path Display Sheets\\")
    pdfpath = str(pdfdirectory + Program_Folder + " - Work Instructions.pdf")
    
    

    if not os.path.exists(pdfdirectory):
        os.makedirs(pdfdirectory)
    if not os.path.exists(pdfdirectory2):
        os.makedirs(pdfdirectory2)    
    
    
    
    

    #text_file.close()
    
    
    
    

    group_list = []
    checked_list = []
    operation_list = []
    def get_group_objects(group_name,workPart):
        find_it = workPart.CAMSetup.CAMOperationCollection.FindObject(group_name)
        new_objects = NXOpen.CAM.NCGroup.GetMembers(find_it)
        return new_objects
    def _get_op_data(obj):
        op_data = {}
        op_data['Operation name'] = obj.Name
        program_name = obj.GetParent(NXOpen.CAM.CAMSetup.View.ProgramOrder)
        op_data['Program Name'] =  program_name.Name
        obj.Print()
        return op_data
    
    op_data_list = []
    for each_object in objects_at_start:
        if workPart.CAMSetup.IsGroup(each_object) == True:
            group_list.append(each_object.Name)
        elif workPart.CAMSetup.IsOperation(each_object) == True:
            op_data = _get_op_data(each_object)
            op_data_list.append(op_data)
 
    while group_list != checked_list:
        for each_object in group_list:
            if each_object not in checked_list:
                temp_objects = get_group_objects(each_object,workPart)
                for sub_object in temp_objects:
                    if workPart.CAMSetup.IsGroup(sub_object) == True:
                        group_list.append(sub_object.Name)
                    elif workPart.CAMSetup.IsOperation(sub_object) == True:
                        op_data = _get_op_data(sub_object)
                        op_data_list.append(op_data)
                checked_list.append(each_object)
    text_file = open("S:\\CAD_Office\\Muhsin\\NXOPEN\\NX_OWI_Automation\\WI_DATA\\Output.txt", "w")
    text_file1 = open("S:\\CAD_Office\\Muhsin\\NXOPEN\\NX_OWI_Automation\\WI_DATA\\Output1.txt", "w")
    text_file3 = open("S:\\CAD_Office\\Muhsin\\NXOPEN\\NX_OWI_Automation\\WI_DATA\\Output3.txt", "w")
    op_data_list_programs = [str(item) for item in op_data_list]
    text_file3.write(str(TPDSheetsReq))
    ##op_data_list1 = [item for item in op_data_list if "Operation name" not in item]
    op_data_list1 = [str(item) for item in op_data_list]
    op_data_list1 = [item.replace('}', '') for item in op_data_list1]
    op_data_list1 = [item.replace('{', '') for item in op_data_list1]
    op_data_list1 = [item.replace(',', '') for item in op_data_list1]
    substring1 = "Program Name': "
    op_data_list1 = [item[item.find(substring1) + len(substring1):] if substring1 in item else item for item in op_data_list1]
    op_data_list1 = [item.replace(str("'"), '') for item in op_data_list1]
    op_data_list2 = []
    for item in op_data_list1:
        if item not in op_data_list2:
            op_data_list2.append(item)
    op_data_list2 = [item for item in op_data_list2 if len(item) <= 10]
    op_data_list2 = [item for item in op_data_list2 if Program_Folder in item]
    op_data_list2 = [item for item in op_data_list2 if item != 'NONE']
    
    ##s1 = str(op_data_list2[0])
    s = str(op_data_list)
    text_file3.write(pdfdirectory2)
    #text_file1.write(s1)
    op_data_list_programs = [item for item in op_data_list_programs if Program_Folder in item]
    op_data_list_programs = [item.replace(',', '') for item in op_data_list_programs]
    op_data_list_programs = [item.replace('}', '') for item in op_data_list_programs]
    op_data_list_programs = [item.replace('{', '') for item in op_data_list_programs]
    op_data_list_programs = [item.replace(str("'"), '') for item in op_data_list_programs]
    op_data_list_programs = [item.split('Operation name: ')[1].split(' Program Name:')[0] for item in op_data_list_programs]
    text_file3.write(str(op_data_list_programs))


    s = s.replace("[","")
    s = s.replace("{","")
    s = s.replace("}","")
    s = s.replace("]","")
    s = s.replace(",","\n")
    s_index1 = s.rindex("'Operation name':")
    s = s[s_index1:]
    s_index2 = s.rindex("'Program Name':")
    s = s[:s_index2]
    s = s.replace("'Operation name': '","")
    s = s.replace("'","")
    s= s.strip()
    Selected_Op = s

    
    


    #######################################################  
    ### TOOL PATH DISPLAY SHEET LOOP
    if TPDSheetsReq == " Tool Path Display Required":


        shutil.rmtree(pdfdirectory2)
        os.makedirs(pdfdirectory2)

        NX_Turn_PMIs_Off()
        no_of_ops = len(op_data_list_programs)
    
        for ix in range(len(op_data_list_programs)):    
            theSession.CAMSession.PathDisplay.DisplayToolPath = True
            cavityMilling1 = workPart.CAMSetup.CAMOperationCollection.FindObject(str(op_data_list_programs[ix]))
            theSession.CAMSession.PathDisplay.ShowToolPath(cavityMilling1)
    
            inTaskEnv1 = theSession.IsBatch
    
            theSession.CAMSession.PathDisplay.StepDisplay(True)
    
            objects1 = [NXOpen.CAM.CAMObject.Null] * 1 
            objects1[0] = cavityMilling1
            workPart.CAMSetup.DeleteWorkInstructions(objects1)
    
            objectWorkInstructionBuilder1 = workPart.CAMSetup.CreateObjectWorkInstructionBuilder(cavityMilling1)
        
            markId1 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
        
            theSession.SetUndoMarkName(markId1, "Author Work Instructions Dialog")
        
            objectWorkInstructionBuilder1.Work.SheetNumber = 1
        
            sheettitle1 = objectWorkInstructionBuilder1.Work.SheetTitle
                                                                    
            objectWorkInstructionBuilder1.Work.SheetTitle = str("RETRAC GROUP - " + Program_Folder +" - "+ op_data_list_programs[ix] + " - Tool Path Display Sheet")
        
            sheetnum1 = objectWorkInstructionBuilder1.Work.AddSheet()
        
            sheettitle2 = objectWorkInstructionBuilder1.Work.SheetTitle
        
            objectWorkInstructionBuilder1.Work.TemplateName = "Tool Path Display Sheet [Trial 1]"
        
            objectWorkInstructionBuilder1.Work.CommitMaster()
        
            itemnames1 = [None] * 7 
            itemnames1[0] = "OWI_TEXT_1"
            itemnames1[1] = "OWI_TEXT_2"
            itemnames1[2] = "OWI_PATH_VIEW_2"
            itemnames1[3] = "OWI_PATH_VIEW_1"
            itemnames1[4] = "OWI_PATH_VIEW_3"
            itemnames1[5] = "OWI_PATH_VIEW_4"
            itemnames1[6] = "OWI_TEXT_3"
            objectWorkInstructionBuilder1.Work.UpdateItemsInCurrentSheet(itemnames1)
    
            objectWorkInstructionBuilder1.Work.ItemName = "OWI_PATH_VIEW_1"
        
            layout1 = workPart.Layouts.FindObject("L1")
            camera1 = workPart.Cameras.FindObject("NXOWI_CACHE_CURRENT_VIEW")
            cameraBuilder1 = workPart.Cameras.CreateCameraBuilder(workPart.ModelingViews.WorkView, layout1, camera1)
    
            nXObject1 = cameraBuilder1.Commit()
        
            cameraBuilder1.Destroy()
        
            sheettitle3 = objectWorkInstructionBuilder1.Work.SheetTitle
        
            objectWorkInstructionBuilder1.Work.ViewTool = True
        
            objectWorkInstructionBuilder1.Work.CameraName = "Isometric"
        
            objectWorkInstructionBuilder1.Work.CommitItem()
        
            objectWorkInstructionBuilder1.Work.ItemName = "OWI_PATH_VIEW_2"
        
            camera2 = nXObject1
            cameraBuilder2 = workPart.Cameras.CreateCameraBuilder(workPart.ModelingViews.WorkView, layout1, camera2)
    
            nXObject2 = cameraBuilder2.Commit()
    
            cameraBuilder2.Destroy()
    
            sheettitle4 = objectWorkInstructionBuilder1.Work.SheetTitle
        
            objectWorkInstructionBuilder1.Work.ViewTool = True
            
            objectWorkInstructionBuilder1.Work.CameraName = "Top"
            
            objectWorkInstructionBuilder1.Work.CommitItem()
            
            objectWorkInstructionBuilder1.Work.ItemName = "OWI_PATH_VIEW_3"
            
            camera3 = nXObject2
            cameraBuilder3 = workPart.Cameras.CreateCameraBuilder(workPart.ModelingViews.WorkView, layout1, camera3)
            
            nXObject3 = cameraBuilder3.Commit()
            
            cameraBuilder3.Destroy()
            
            sheettitle4 = objectWorkInstructionBuilder1.Work.SheetTitle
        
            objectWorkInstructionBuilder1.Work.ViewTool = True
            
            objectWorkInstructionBuilder1.Work.CameraName = "Back"
            
            objectWorkInstructionBuilder1.Work.CommitItem()
            
            objectWorkInstructionBuilder1.Work.ItemName = "OWI_PATH_VIEW_4"
            
            camera3 = nXObject2
            cameraBuilder3 = workPart.Cameras.CreateCameraBuilder(workPart.ModelingViews.WorkView, layout1, camera3)
            
            nXObject3 = cameraBuilder3.Commit()
            
            cameraBuilder3.Destroy()
        
            sheettitle5 = objectWorkInstructionBuilder1.Work.SheetTitle
        
            objectWorkInstructionBuilder1.Work.ViewTool = True
        
            objectWorkInstructionBuilder1.Work.CameraName = "Front"
        
            objectWorkInstructionBuilder1.Work.CommitItem()
        
            objectWorkInstructionBuilder1.Work.ItemName = "OWI_TEXT_3"
    
            multilinetext1 = []
            objectWorkInstructionBuilder1.Work.SetRichText(multilinetext1)
    
            sheettitle6 = objectWorkInstructionBuilder1.Work.SheetTitle
    
            multilinetext2 = [None] * 1 
            multilinetext2[0] = "Notes"
            objectWorkInstructionBuilder1.Work.SetRichText(multilinetext2)
        
            objectWorkInstructionBuilder1.Work.CommitItem()
    
            objectWorkInstructionBuilder1.Work.FontSize = 10
    
            objectWorkInstructionBuilder1.Work.CommitItem()
    
            objectWorkInstructionBuilder1.Work.FontFace = "Calibri"
    
            objectWorkInstructionBuilder1.Work.CommitItem()
    
            multilinetext3 = [None] * 1 
            multilinetext3[0] = ""
            objectWorkInstructionBuilder1.Work.SetRichText(multilinetext3)
    
            objectWorkInstructionBuilder1.Work.CommitItem()
    
            objectWorkInstructionBuilder1.Work.ItemName = "OWI_TEXT_1"
    
            multilinetext4 = []
            objectWorkInstructionBuilder1.Work.SetRichText(multilinetext4)
        
            sheettitle7 = objectWorkInstructionBuilder1.Work.SheetTitle
    
            multilinetext5 = [None] * 1 
            multilinetext5[0] = Project_Name
            objectWorkInstructionBuilder1.Work.SetRichText(multilinetext5)
        
            objectWorkInstructionBuilder1.Work.CommitItem()
        
            objectWorkInstructionBuilder1.Work.FontSize = 16
        
            objectWorkInstructionBuilder1.Work.CommitItem()
    
            objectWorkInstructionBuilder1.Work.FontFace = "Calibri"
    
            objectWorkInstructionBuilder1.Work.CommitItem()
    
            objectWorkInstructionBuilder1.Work.ItemName = "OWI_TEXT_2"
    
            multilinetext6 = []
            objectWorkInstructionBuilder1.Work.SetRichText(multilinetext6)
        
            sheettitle8 = objectWorkInstructionBuilder1.Work.SheetTitle
    
            markId2 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Author Work Instructions")
    
            multilinetext7 = [None] * 1 
            multilinetext7[0] = Machine_Name
            objectWorkInstructionBuilder1.Work.SetRichText(multilinetext7)
    
            objectWorkInstructionBuilder1.Work.CommitItem()
        
            objectWorkInstructionBuilder1.Work.FontSize = 16
    
            objectWorkInstructionBuilder1.Work.CommitItem()
    
            objectWorkInstructionBuilder1.Work.FontFace = "Calibri"
        
            objectWorkInstructionBuilder1.Work.CommitItem()
    
            theSession.DeleteUndoMark(markId2, None)
        
            markId3 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Author Work Instructions")
    
            theSession.DeleteUndoMark(markId3, None)
    
            theSession.SetUndoMarkName(markId1, "Author Work Instructions")
        
            theSession.DeleteUndoMark(markId1, None)
    
            nXObject4 = objectWorkInstructionBuilder1.Commit()
    
            objectWorkInstructionBuilder1.Destroy()
    
            markId4 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
            workInstructionOutputBuilder1 = workPart.CAMSetup.CreateWorkInstructionOutputBuilder()
    
            workInstructionOutputBuilder1.PageSize = NXOpen.CAM.WorkInstructionOutputBuilder.PageSizeType.Letter
    
            workInstructionOutputBuilder1.ScaleFactor = 1.0
        
            workInstructionOutputBuilder1.OutputFormat = NXOpen.CAM.WorkInstructionOutputBuilder.OutputFormatType.Pdf
                
            workInstructionOutputBuilder1.OutputFile = str(pdfdirectory2 + str(ix + 1) +"- "+ str(op_data_list_programs[ix]) + " - Tool Path Display Sheet.pdf")
    
            theSession.SetUndoMarkName(markId4, "Publish Work Instructi29ons Dialog")
    
    # ----------------------------------------------
    #   Dialog Begin Publish Work Instructions
    # ----------------------------------------------
            markId5 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Publish Work Instructions")
                        
            workInstructionOutputBuilder1.OutputFile = str(pdfdirectory2 + str(ix + 1) +"- "+ str(op_data_list_programs[ix]) + " - Tool Path Display Sheet.pdf")
    
            theSession.DeleteUndoMark(markId5, None)
    
            markId6 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Publish Work Instructions")
        
            camera4 = nXObject3
            cameraBuilder4 = workPart.Cameras.CreateCameraBuilder(workPart.ModelingViews.WorkView, layout1, camera4)
            
            nXObject5 = cameraBuilder4.Commit()
    
            cameraBuilder4.Destroy()
    
            objects2 = [NXOpen.CAM.CAMObject.Null] * 1 
            objects2[0] = cavityMilling1
            workPart.ModelingViews.WorkView.Orient(NXOpen.View.Canned.Top, NXOpen.View.ScaleAdjustment.Fit)
        
            workPart.ModelingViews.WorkView.Orient(NXOpen.View.Canned.Isometric, NXOpen.View.ScaleAdjustment.Fit)
    
            workPart.ModelingViews.WorkView.Orient(NXOpen.View.Canned.Front, NXOpen.View.ScaleAdjustment.Fit)
        
            workInstructionOutputBuilder1.Publish(objects2, cavityMilling1, 0)
    
            camera5 = nXObject5
            camera5.ApplyToView(workPart.ModelingViews.WorkView)
    
            theSession.DeleteUndoMark(markId6, None)
        
            theSession.SetUndoMarkName(markId4, "Publish Work Instructions")
    
            workInstructionOutputBuilder1.Destroy()
        
        
        NX_Turn_PMIs_On()
    #######################################################        








    theSession  = NXOpen.Session.GetSession() #type: NXOpen.Session
    workPart = theSession.Parts.Work
    displayPart = theSession.Parts.Display
    theUI = NXOpen.UI.GetUI() #type: NXOpen.UI
    theSession.CAMSession.PathDisplay.DisplayToolPath = False
    
    surfaceContour1 = workPart.CAMSetup.CAMOperationCollection.FindObject(Selected_Op)

    objects2 = [NXOpen.CAM.CAMObject.Null] * 1 
    objects2[0] = surfaceContour1
    
    workPart.CAMSetup.DeleteWorkInstructions(objects2)
    theSession.CAMSession.PathDisplay.HideToolPath(surfaceContour1)
    if theUI.SelectionManager.GetSelectedTaggedObject(0) != None:
        theSession.CAMSession.PathDisplay.HideToolPath(theUI.SelectionManager.GetSelectedTaggedObject(0))
    theSession.CAMSession.PathDisplay.SetToolDisplayType(NXOpen.CAM.PathDisplay.ToolDisplayType.Point)
    holeDrilling1 = workPart.CAMSetup.CAMOperationCollection.FindObject(Selected_Op)
    objectWorkInstructionBuilder1 = workPart.CAMSetup.CreateObjectWorkInstructionBuilder(holeDrilling1)




    
    #objectWorkInstructionBuilder1 = workPart.CAMSetup.CreateObjectWorkInstructionBuilder(theUI.SelectionManager.GetSelectedTaggedObject(0))
    
    markId1 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    theSession.SetUndoMarkName(markId1, "Author Work Instructions Dialog")
    
    objectWorkInstructionBuilder1.Work.SheetNumber = 1
    
    sheettitle1 = objectWorkInstructionBuilder1.Work.SheetTitle
    
    objectWorkInstructionBuilder1.Work.SheetTitle =  str("RETRAC GROUP - " + Program_Folder + " - Job Information Sheet")
    
    sheetnum1 = objectWorkInstructionBuilder1.Work.AddSheet()
    
    sheettitle2 = objectWorkInstructionBuilder1.Work.SheetTitle
    
    objectWorkInstructionBuilder1.Work.TemplateName = "Job Information Sheet [Trial 1]"
    
    objectWorkInstructionBuilder1.Work.CommitMaster()
    
    itemnames1 = [None] * 11 
    itemnames1[0] = "OWI_TEXT_1"
    itemnames1[1] = "OWI_TEXT_4"
    itemnames1[2] = "OWI_TEXT_5"
    itemnames1[3] = "OWI_TEXT_6"
    itemnames1[4] = "OWI_TEXT_3"
    itemnames1[5] = "OWI_TEXT_2"
    itemnames1[6] = "OWI_PROD_VIEW_1"
    itemnames1[7] = "OWI_TEXT_7"
    itemnames1[8] = "OWI_TEXT_8"
    itemnames1[9] = "OWI_TEXT_9"
    itemnames1[10] = "OWI_TEXT_10"
    objectWorkInstructionBuilder1.Work.UpdateItemsInCurrentSheet(itemnames1)
    
    layout1 = workPart.Layouts.FindObject("L1")
    camera1 = workPart.Cameras.FindObject("NXOWI_CACHE_CURRENT_VIEW")
    cameraBuilder1 = workPart.Cameras.CreateCameraBuilder(workPart.ModelingViews.WorkView, layout1, camera1)
    
    nXObject1 = cameraBuilder1.Commit()
    
    cameraBuilder1.Destroy()
    
    sheetnum2 = objectWorkInstructionBuilder1.Work.AddSheet()
    
    sheettitle3 = objectWorkInstructionBuilder1.Work.SheetTitle
    
    objectWorkInstructionBuilder1.Work.SheetNumber = 2
    
    sheettitle4 = objectWorkInstructionBuilder1.Work.SheetTitle
    
    objectWorkInstructionBuilder1.Work.SheetTitle = str("RETRAC GROUP - " + Program_Folder + " - Tool List")
    
    objectWorkInstructionBuilder1.Work.TemplateName = "Tool Sheet [Trial 1]"
    
    objectWorkInstructionBuilder1.Work.CommitMaster()
    
    itemnames2 = [None] * 2 
    itemnames2[0] = "OWI_PROD_VIEW_2"
    itemnames2[1] = "OWI_TOOL_LIST_1"
    objectWorkInstructionBuilder1.Work.UpdateItemsInCurrentSheet(itemnames2)
    
    camera2 = nXObject1
    cameraBuilder2 = workPart.Cameras.CreateCameraBuilder(workPart.ModelingViews.WorkView, layout1, camera2)
    
    nXObject2 = cameraBuilder2.Commit()
    
    cameraBuilder2.Destroy()
    
    sheetnum3 = objectWorkInstructionBuilder1.Work.AddSheet()
    
    sheettitle5 = objectWorkInstructionBuilder1.Work.SheetTitle
    
    objectWorkInstructionBuilder1.Work.SheetNumber = 3
    
    sheettitle6 = objectWorkInstructionBuilder1.Work.SheetTitle
    
    objectWorkInstructionBuilder1.Work.SheetTitle = str("RETRAC GROUP - " + Program_Folder + "- Job Views")
    
    objectWorkInstructionBuilder1.Work.TemplateName = "Job View [Trial 1]"
    
    objectWorkInstructionBuilder1.Work.CommitMaster()
    
    itemnames3 = [None] * 5 
    itemnames3[0] = "OWI_PROD_VIEW_5"
    itemnames3[1] = "OWI_PROD_VIEW_1"
    itemnames3[2] = "OWI_PROD_VIEW_2"
    itemnames3[3] = "OWI_PROD_VIEW_3"
    itemnames3[4] = "OWI_IMAGE_1"
    objectWorkInstructionBuilder1.Work.UpdateItemsInCurrentSheet(itemnames3)
    
    camera3 = nXObject2
    cameraBuilder3 = workPart.Cameras.CreateCameraBuilder(workPart.ModelingViews.WorkView, layout1, camera3)
    
    nXObject3 = cameraBuilder3.Commit()
    
    cameraBuilder3.Destroy()
    
    
    
    
    
    
    
    # Add Path Summary Sheets Loop
    no_of_programs = len(op_data_list2)
    
    for i in range(len(op_data_list2)):
        sheetnum4 = objectWorkInstructionBuilder1.Work.AddSheet()
    
        sheettitle7 = objectWorkInstructionBuilder1.Work.SheetTitle
    
        objectWorkInstructionBuilder1.Work.SheetNumber = 4 + i
    
        sheettitle8 = objectWorkInstructionBuilder1.Work.SheetTitle
    
        objectWorkInstructionBuilder1.Work.SheetTitle = str("RETRAC GROUP - " + Program_Folder + " - Tool Path Summary - " + str(op_data_list2[i]))
    
        objectWorkInstructionBuilder1.Work.TemplateName = "Tool Path Summary [Trial 1]"
    
        objectWorkInstructionBuilder1.Work.CommitMaster()
    
        itemnames4 = [None] * 2 
        itemnames4[0] = "OWI_PROD_VIEW_2"
        itemnames4[1] = "OWI_OPER_LIST_1"
        objectWorkInstructionBuilder1.Work.UpdateItemsInCurrentSheet(itemnames4)
        
        camera4 = nXObject3
        cameraBuilder4 = workPart.Cameras.CreateCameraBuilder(workPart.ModelingViews.WorkView, layout1, camera4) 
        nXObject4 = cameraBuilder4.Commit()
    
        cameraBuilder4.Destroy()
        
    
    
    
    #### Add Path Summary Sheets Loop End
    
    
    
    ### EDIT SHEET ONE - JOB INFORMATION SHEET
    objectWorkInstructionBuilder1.Work.SheetNumber = 1
    
    itemnames5 = [None] * 11 
    itemnames5[0] = "OWI_TEXT_1"
    itemnames5[1] = "OWI_TEXT_4"
    itemnames5[2] = "OWI_TEXT_5"
    itemnames5[3] = "OWI_TEXT_6"
    itemnames5[4] = "OWI_TEXT_3"
    itemnames5[5] = "OWI_TEXT_2"
    itemnames5[6] = "OWI_PROD_VIEW_1"
    itemnames5[7] = "OWI_TEXT_7"
    itemnames5[8] = "OWI_TEXT_8"
    itemnames5[9] = "OWI_TEXT_9"
    itemnames5[10] = "OWI_TEXT_10"
    objectWorkInstructionBuilder1.Work.UpdateItemsInCurrentSheet(itemnames5)
    
    camera5 = nXObject4
    cameraBuilder5 = workPart.Cameras.CreateCameraBuilder(workPart.ModelingViews.WorkView, layout1, camera5)
    
    nXObject5 = cameraBuilder5.Commit()
    
    cameraBuilder5.Destroy()
    
    sheettitle9 = objectWorkInstructionBuilder1.Work.SheetTitle
    
    objectWorkInstructionBuilder1.Work.SheetTitle = sheettitle2
    
    objectWorkInstructionBuilder1.Work.ItemName = "OWI_TEXT_1"
    
    multilinetext1 = []
    objectWorkInstructionBuilder1.Work.SetRichText(multilinetext1)
    
    sheettitle10 = objectWorkInstructionBuilder1.Work.SheetTitle
    
    multilinetext2 = [None] * 1 
    multilinetext2[0] = Rev_No
    objectWorkInstructionBuilder1.Work.SetRichText(multilinetext2)
    
    objectWorkInstructionBuilder1.Work.CommitItem()
   
    objectWorkInstructionBuilder1.Work.FontSize = 16
    
    objectWorkInstructionBuilder1.Work.CommitItem()
    
    objectWorkInstructionBuilder1.Work.FontFace = "Calibri"
    
    objectWorkInstructionBuilder1.Work.CommitItem()
    
    objectWorkInstructionBuilder1.Work.ItemName = "OWI_TEXT_4"
    
    multilinetext3 = []
    objectWorkInstructionBuilder1.Work.SetRichText(multilinetext3)
    
    camera6 = nXObject5
    cameraBuilder6 = workPart.Cameras.CreateCameraBuilder(workPart.ModelingViews.WorkView, layout1, camera6)
    
    nXObject6 = cameraBuilder6.Commit()
    
    cameraBuilder6.Destroy()
    
    sheettitle11 = objectWorkInstructionBuilder1.Work.SheetTitle
    
    multilinetext4 = [None] * 1 
    multilinetext4[0] = Costumer_Name
    objectWorkInstructionBuilder1.Work.SetRichText(multilinetext4)
    
    objectWorkInstructionBuilder1.Work.CommitItem()
    
    objectWorkInstructionBuilder1.Work.FontSize = 16
    
    objectWorkInstructionBuilder1.Work.CommitItem()
    
    objectWorkInstructionBuilder1.Work.FontFace = "Calibri"
    
    objectWorkInstructionBuilder1.Work.CommitItem()
    
    objectWorkInstructionBuilder1.Work.ItemName = "OWI_TEXT_5"
    
    multilinetext5 = []
    objectWorkInstructionBuilder1.Work.SetRichText(multilinetext5)
    
    camera7 = nXObject6
    cameraBuilder7 = workPart.Cameras.CreateCameraBuilder(workPart.ModelingViews.WorkView, layout1, camera7)
    
    nXObject7 = cameraBuilder7.Commit()
    
    cameraBuilder7.Destroy()
    
    sheettitle12 = objectWorkInstructionBuilder1.Work.SheetTitle
    
    multilinetext6 = [None] * 1 
    multilinetext6[0] = Project_Name
    objectWorkInstructionBuilder1.Work.SetRichText(multilinetext6)
    
    objectWorkInstructionBuilder1.Work.CommitItem()

    objectWorkInstructionBuilder1.Work.FontSize = 16
    
    objectWorkInstructionBuilder1.Work.CommitItem()
    
    objectWorkInstructionBuilder1.Work.FontFace = "Calibri"
    
    objectWorkInstructionBuilder1.Work.CommitItem()
    
    objectWorkInstructionBuilder1.Work.ItemName = "OWI_TEXT_6"
    
    multilinetext7 = []
    objectWorkInstructionBuilder1.Work.SetRichText(multilinetext7)
    
    camera8 = nXObject7
    cameraBuilder8 = workPart.Cameras.CreateCameraBuilder(workPart.ModelingViews.WorkView, layout1, camera8)
    
    nXObject8 = cameraBuilder8.Commit()
    
    cameraBuilder8.Destroy()
    
    sheettitle13 = objectWorkInstructionBuilder1.Work.SheetTitle
    
    multilinetext8 = [None] * 1 
    multilinetext8[0] = Machine_Name
    objectWorkInstructionBuilder1.Work.SetRichText(multilinetext8)
    
    objectWorkInstructionBuilder1.Work.CommitItem()
    
    objectWorkInstructionBuilder1.Work.FontSize = 16
    
    objectWorkInstructionBuilder1.Work.CommitItem()
    
    objectWorkInstructionBuilder1.Work.FontFace = "Calibri"
    
    objectWorkInstructionBuilder1.Work.CommitItem()
    
    objectWorkInstructionBuilder1.Work.ItemName = "OWI_TEXT_3"
    
    multilinetext9 = []
    objectWorkInstructionBuilder1.Work.SetRichText(multilinetext9)
    
    camera9 = nXObject8
    cameraBuilder9 = workPart.Cameras.CreateCameraBuilder(workPart.ModelingViews.WorkView, layout1, camera9)
    
    nXObject9 = cameraBuilder9.Commit()
    
    cameraBuilder9.Destroy()
    
    sheettitle14 = objectWorkInstructionBuilder1.Work.SheetTitle
    
    multilinetext10 = [None] * 1 
    multilinetext10[0] = Program_Folder
    objectWorkInstructionBuilder1.Work.SetRichText(multilinetext10)
    
    objectWorkInstructionBuilder1.Work.CommitItem()
    
    objectWorkInstructionBuilder1.Work.FontSize = 18
    
    objectWorkInstructionBuilder1.Work.CommitItem()
    
    textcolor2 = [None] * 3 
    textcolor2[0] = 0.50196078431372548
    textcolor2[1] = 0.38823529411764707
    textcolor2[2] = 0.0
    
    objectWorkInstructionBuilder1.Work.SetTextColor(textcolor2)
    
    objectWorkInstructionBuilder1.Work.CommitItem()
    
    objectWorkInstructionBuilder1.Work.FontFace = "Calibri"
    
    objectWorkInstructionBuilder1.Work.CommitItem()
    
    objectWorkInstructionBuilder1.Work.ItemName = "OWI_TEXT_2"
    
    multilinetext11 = []
    objectWorkInstructionBuilder1.Work.SetRichText(multilinetext11)
    
    camera10 = nXObject9
    cameraBuilder10 = workPart.Cameras.CreateCameraBuilder(workPart.ModelingViews.WorkView, layout1, camera10)
    
    nXObject10 = cameraBuilder10.Commit()
    
    cameraBuilder10.Destroy()
    
    sheettitle15 = objectWorkInstructionBuilder1.Work.SheetTitle
    
    multilinetext12 = [None] * 1 
    multilinetext12[0] = Instructions_Text
    objectWorkInstructionBuilder1.Work.SetRichText(multilinetext12)
    
    objectWorkInstructionBuilder1.Work.CommitItem()
    
    objectWorkInstructionBuilder1.Work.FontSize = 12
    
    objectWorkInstructionBuilder1.Work.CommitItem()
    
    objectWorkInstructionBuilder1.Work.FontFace = "Calibri"
    
    objectWorkInstructionBuilder1.Work.CommitItem()
    
    objectWorkInstructionBuilder1.Work.ItemName = "OWI_PROD_VIEW_1"
    
    camera11 = nXObject10
    cameraBuilder11 = workPart.Cameras.CreateCameraBuilder(workPart.ModelingViews.WorkView, layout1, camera11)
    
    nXObject11 = cameraBuilder11.Commit()
    
    cameraBuilder11.Destroy()
    
    camera12 = nXObject11
    cameraBuilder12 = workPart.Cameras.CreateCameraBuilder(workPart.ModelingViews.WorkView, layout1, camera12)
    
    nXObject12 = cameraBuilder12.Commit()
    
    cameraBuilder12.Destroy()
    
    sheettitle16 = objectWorkInstructionBuilder1.Work.SheetTitle
    
    part1 = theSession.Parts.Display
    
    view1 = workPart.Views.WorkView
    
    modelingView1 = view1
    modelingView1.Fit()
    
    # ----------------------------------------------
    #   Menu: Orient View->Isometric
    # ----------------------------------------------
    modelingView1.Orient(NXOpen.View.Canned.Isometric, NXOpen.View.ScaleAdjustment.Fit)
    
    multilinetext13 = [None] * 1 
    multilinetext13[0] = Instructions_Text
    objectWorkInstructionBuilder1.Work.SetRichText(multilinetext13)
    
    objectWorkInstructionBuilder1.Work.CommitItem()
    
    cameraBuilder13 = workPart.Cameras.CreateCameraBuilder(modelingView1, layout1, NXOpen.Display.Camera.Null)
    
    nXObject13 = cameraBuilder13.Commit()
    
    cameraBuilder13.Destroy()
    
    objectWorkInstructionBuilder1.Work.CaptureCurrentView()
    
    objectWorkInstructionBuilder1.Work.CameraName = "Isometric"
    
    objectWorkInstructionBuilder1.Work.CommitItem()
    
    camera13 = nXObject12
    cameraBuilder14 = workPart.Cameras.CreateCameraBuilder(modelingView1, layout1, camera13)
    
    nXObject14 = cameraBuilder14.Commit()
    
    cameraBuilder14.Destroy()
    
    layout1.ReplaceView(modelingView1, modelingView1, False)
    
    objectWorkInstructionBuilder1.Work.ItemName = "OWI_TEXT_7"
    
    multilinetext14 = []
    objectWorkInstructionBuilder1.Work.SetRichText(multilinetext14)
    
    sheettitle17 = objectWorkInstructionBuilder1.Work.SheetTitle
    
    multilinetext15 = [None] * 1 
    multilinetext15[0] = Datum_Info
    objectWorkInstructionBuilder1.Work.SetRichText(multilinetext15)
    
    objectWorkInstructionBuilder1.Work.CommitItem()
    
    objectWorkInstructionBuilder1.Work.FontSize = 12
    
    objectWorkInstructionBuilder1.Work.CommitItem()
    
    objectWorkInstructionBuilder1.Work.FontFace = "Calibri"
    
    objectWorkInstructionBuilder1.Work.CommitItem()
    
    objectWorkInstructionBuilder1.Work.ItemName = "OWI_TEXT_8"
    
    multilinetext16 = []
    objectWorkInstructionBuilder1.Work.SetRichText(multilinetext16)
    
    camera14 = nXObject14
    cameraBuilder15 = workPart.Cameras.CreateCameraBuilder(modelingView1, layout1, camera14)
    
    nXObject15 = cameraBuilder15.Commit()
    
    cameraBuilder15.Destroy()
    
    layout1.ReplaceView(modelingView1, modelingView1, False)
    
    sheettitle18 = objectWorkInstructionBuilder1.Work.SheetTitle
    
    multilinetext17 = [None] * 1 
    multilinetext17[0] = WorkHold_Info
    objectWorkInstructionBuilder1.Work.SetRichText(multilinetext17)
    
    objectWorkInstructionBuilder1.Work.CommitItem()
    
    objectWorkInstructionBuilder1.Work.FontSize = 12
    
    objectWorkInstructionBuilder1.Work.CommitItem()
    
    objectWorkInstructionBuilder1.Work.FontFace = "Calibri"
    
    objectWorkInstructionBuilder1.Work.CommitItem()
    
    objectWorkInstructionBuilder1.Work.ItemName = "OWI_TEXT_9"
    
    multilinetext18 = []
    objectWorkInstructionBuilder1.Work.SetRichText(multilinetext18)
    
    camera15 = nXObject15
    cameraBuilder16 = workPart.Cameras.CreateCameraBuilder(modelingView1, layout1, camera15)
    
    nXObject16 = cameraBuilder16.Commit()
    
    cameraBuilder16.Destroy()
    
    layout1.ReplaceView(modelingView1, modelingView1, False)
    
    sheettitle19 = objectWorkInstructionBuilder1.Work.SheetTitle
    
    multilinetext19 = [None] * 1 
    multilinetext19[0] = AsOpp_Info
    objectWorkInstructionBuilder1.Work.SetRichText(multilinetext19)
    
    objectWorkInstructionBuilder1.Work.CommitItem()
    
    objectWorkInstructionBuilder1.Work.FontSize = 12
    
    objectWorkInstructionBuilder1.Work.CommitItem()
    
    objectWorkInstructionBuilder1.Work.FontFace = "Calibri"
    
    objectWorkInstructionBuilder1.Work.CommitItem()
    
    objectWorkInstructionBuilder1.Work.ItemName = "OWI_TEXT_10"
    
    multilinetext20 = []
    objectWorkInstructionBuilder1.Work.SetRichText(multilinetext20)
    
    camera16 = nXObject16
    cameraBuilder17 = workPart.Cameras.CreateCameraBuilder(modelingView1, layout1, camera16)
    
    nXObject17 = cameraBuilder17.Commit()
    
    cameraBuilder17.Destroy()
    
    layout1.ReplaceView(modelingView1, modelingView1, False)
    
    sheettitle20 = objectWorkInstructionBuilder1.Work.SheetTitle
    
    multilinetext21 = [None] * 1 
    multilinetext21[0] = Notes_Text
    objectWorkInstructionBuilder1.Work.SetRichText(multilinetext21)
    
    objectWorkInstructionBuilder1.Work.CommitItem()
    
    objectWorkInstructionBuilder1.Work.FontSize = 10
    
    objectWorkInstructionBuilder1.Work.CommitItem()
    
    objectWorkInstructionBuilder1.Work.FontFace = "Calibri"
    
    objectWorkInstructionBuilder1.Work.CommitItem()
    
    
    
    
    
    ### EDIT TOOL LIST 
    objectWorkInstructionBuilder1.Work.SheetNumber = 2
    
    itemnames6 = [None] * 2 
    itemnames6[0] = "OWI_PROD_VIEW_2"
    itemnames6[1] = "OWI_TOOL_LIST_1"
    objectWorkInstructionBuilder1.Work.UpdateItemsInCurrentSheet(itemnames6)
    
    camera17 = nXObject17
    cameraBuilder18 = workPart.Cameras.CreateCameraBuilder(modelingView1, layout1, camera17)
    
    nXObject18 = cameraBuilder18.Commit()
    
    cameraBuilder18.Destroy()
    
    objectWorkInstructionBuilder1.Work.ItemName = "OWI_PROD_VIEW_2"
    
    camera18 = nXObject18
    cameraBuilder19 = workPart.Cameras.CreateCameraBuilder(modelingView1, layout1, camera18)
    
    nXObject19 = cameraBuilder19.Commit()
    
    cameraBuilder19.Destroy()
    
    camera19 = nXObject19
    cameraBuilder20 = workPart.Cameras.CreateCameraBuilder(modelingView1, layout1, camera19)
    
    nXObject20 = cameraBuilder20.Commit()
    
    cameraBuilder20.Destroy()
    
    sheettitle21 = objectWorkInstructionBuilder1.Work.SheetTitle
    
    objectWorkInstructionBuilder1.Work.SheetTitle = sheettitle5
    
    multilinetext22 = [None] * 1 
    multilinetext22[0] = Notes_Text
    objectWorkInstructionBuilder1.Work.SetRichText(multilinetext22)
    
    objectWorkInstructionBuilder1.Work.CommitItem()
    
    cameraBuilder21 = workPart.Cameras.CreateCameraBuilder(modelingView1, layout1, NXOpen.Display.Camera.Null)
    
    nXObject21 = cameraBuilder21.Commit()
    
    cameraBuilder21.Destroy()
    
    objectWorkInstructionBuilder1.Work.CaptureCurrentView()
    
    objectWorkInstructionBuilder1.Work.CameraName = "Isometric"
    
    objectWorkInstructionBuilder1.Work.CommitItem()
    
    camera20 = nXObject20
    cameraBuilder22 = workPart.Cameras.CreateCameraBuilder(modelingView1, layout1, camera20)
    
    nXObject22 = cameraBuilder22.Commit()
    
    cameraBuilder22.Destroy()
    
    layout1.ReplaceView(modelingView1, modelingView1, False)
    
    objectWorkInstructionBuilder1.Work.ItemName = "OWI_TOOL_LIST_1"
    
    sheettitle22 = objectWorkInstructionBuilder1.Work.SheetTitle
    
    objectWorkInstructionBuilder1.Work.ToolListProgramGroup = Program_Folder
    
    objectWorkInstructionBuilder1.Work.ToolListProgramGroup = Program_Folder
    
    objectWorkInstructionBuilder1.Work.CommitItem()
    
    camera21 = nXObject22
    cameraBuilder23 = workPart.Cameras.CreateCameraBuilder(modelingView1, layout1, camera21)
    
    nXObject23 = cameraBuilder23.Commit()
    
    cameraBuilder23.Destroy()
    
    layout1.ReplaceView(modelingView1, modelingView1, False)
    
    #### EDIT JOB VIEWS SHEET
    
    objectWorkInstructionBuilder1.Work.SheetNumber = 3
    
    itemnames7 = [None] * 5 
    itemnames7[0] = "OWI_PROD_VIEW_5"
    itemnames7[1] = "OWI_PROD_VIEW_1"
    itemnames7[2] = "OWI_PROD_VIEW_2"
    itemnames7[3] = "OWI_PROD_VIEW_3"
    itemnames7[4] = "OWI_IMAGE_1"
    objectWorkInstructionBuilder1.Work.UpdateItemsInCurrentSheet(itemnames7)
    
    camera22 = nXObject23
    cameraBuilder24 = workPart.Cameras.CreateCameraBuilder(modelingView1, layout1, camera22)
    
    nXObject24 = cameraBuilder24.Commit()
    
    cameraBuilder24.Destroy()
    
    objectWorkInstructionBuilder1.Work.ItemName = "OWI_PROD_VIEW_5"
    
    camera23 = nXObject24
    cameraBuilder25 = workPart.Cameras.CreateCameraBuilder(modelingView1, layout1, camera23)
    
    nXObject25 = cameraBuilder25.Commit()
    
    cameraBuilder25.Destroy()
    
    sheettitle23 = objectWorkInstructionBuilder1.Work.SheetTitle
    
    objectWorkInstructionBuilder1.Work.SheetTitle = sheettitle7
    
    cameraBuilder26 = workPart.Cameras.CreateCameraBuilder(modelingView1, layout1, NXOpen.Display.Camera.Null)
    
    nXObject26 = cameraBuilder26.Commit()
    
    cameraBuilder26.Destroy()
    
    objectWorkInstructionBuilder1.Work.CaptureCurrentView()
    
    objectWorkInstructionBuilder1.Work.CameraName = "Isometric"
    
    objectWorkInstructionBuilder1.Work.CommitItem()
    
    camera24 = nXObject25
    cameraBuilder27 = workPart.Cameras.CreateCameraBuilder(modelingView1, layout1, camera24)
    
    nXObject27 = cameraBuilder27.Commit()
    
    cameraBuilder27.Destroy()
    
    layout1.ReplaceView(modelingView1, modelingView1, False)
    
    objectWorkInstructionBuilder1.Work.ItemName = "OWI_PROD_VIEW_1"
    
    camera25 = nXObject27
    cameraBuilder28 = workPart.Cameras.CreateCameraBuilder(modelingView1, layout1, camera25)
    
    nXObject28 = cameraBuilder28.Commit()
    
    cameraBuilder28.Destroy()
    
    sheettitle24 = objectWorkInstructionBuilder1.Work.SheetTitle
    
    cameraBuilder29 = workPart.Cameras.CreateCameraBuilder(modelingView1, layout1, NXOpen.Display.Camera.Null)
    
    nXObject29 = cameraBuilder29.Commit()
    
    cameraBuilder29.Destroy()
    
    objectWorkInstructionBuilder1.Work.CaptureCurrentView()
    
    objectWorkInstructionBuilder1.Work.CameraName = "Isometric"
    
    objectWorkInstructionBuilder1.Work.CommitItem()
    
    camera26 = nXObject28
    cameraBuilder30 = workPart.Cameras.CreateCameraBuilder(modelingView1, layout1, camera26)
    
    nXObject30 = cameraBuilder30.Commit()
    
    cameraBuilder30.Destroy()
    
    layout1.ReplaceView(modelingView1, modelingView1, False)
    
    layout1.ReplaceView(modelingView1, modelingView1, False)
    
    objectWorkInstructionBuilder1.Work.ItemName = "OWI_PROD_VIEW_2"
    
    camera27 = nXObject30
    cameraBuilder31 = workPart.Cameras.CreateCameraBuilder(modelingView1, layout1, camera27)
    
    nXObject31 = cameraBuilder31.Commit()
    
    cameraBuilder31.Destroy()
    
    sheettitle25 = objectWorkInstructionBuilder1.Work.SheetTitle
    
    objectWorkInstructionBuilder1.Work.CameraName = "Top"
    
    objectWorkInstructionBuilder1.Work.CommitItem()
    
    camera28 = nXObject31
    cameraBuilder32 = workPart.Cameras.CreateCameraBuilder(modelingView1, layout1, camera28)
    
    nXObject32 = cameraBuilder32.Commit()
    
    cameraBuilder32.Destroy()
    
    layout1.ReplaceView(modelingView1, modelingView1, False)
    
    layout1.ReplaceView(modelingView1, modelingView1, False)
    
    modelingView1.Orient(NXOpen.View.Canned.Top, NXOpen.View.ScaleAdjustment.Fit)
    
    objectWorkInstructionBuilder1.Work.ItemName = "OWI_PROD_VIEW_3"
    
    camera29 = nXObject32
    cameraBuilder33 = workPart.Cameras.CreateCameraBuilder(modelingView1, layout1, camera29)
    
    nXObject33 = cameraBuilder33.Commit()
    
    cameraBuilder33.Destroy()
    
    sheettitle26 = objectWorkInstructionBuilder1.Work.SheetTitle
    
    objectWorkInstructionBuilder1.Work.CameraName = "Front"
    
    objectWorkInstructionBuilder1.Work.CommitItem()
    
    camera30 = nXObject33
    cameraBuilder34 = workPart.Cameras.CreateCameraBuilder(modelingView1, layout1, camera30)
    
    nXObject34 = cameraBuilder34.Commit()
    
    cameraBuilder34.Destroy()
    
    layout1.ReplaceView(modelingView1, modelingView1, False)
    
    layout1.ReplaceView(modelingView1, modelingView1, False)
    
    modelingView1.Orient(NXOpen.View.Canned.Top, NXOpen.View.ScaleAdjustment.Fit)
    
    modelingView1.Orient(NXOpen.View.Canned.Front, NXOpen.View.ScaleAdjustment.Fit)
    
    
    #### Edit Path Summary Sheets Loop
    
    for ix in range(len(op_data_list2)):
        ##text_file1.write(str(ix))
        objectWorkInstructionBuilder1.Work.SheetNumber = 4 + ix
    
        itemnames8 = [None] * 2 
        itemnames8[0] = "OWI_PROD_VIEW_2"
        itemnames8[1] = "OWI_OPER_LIST_1"
        objectWorkInstructionBuilder1.Work.UpdateItemsInCurrentSheet(itemnames8)
        
        camera31 = nXObject34
        cameraBuilder35 = workPart.Cameras.CreateCameraBuilder(modelingView1, layout1, camera31)
    
        nXObject35 = cameraBuilder35.Commit()
    
        cameraBuilder35.Destroy()
    
        sheettitle27 = objectWorkInstructionBuilder1.Work.SheetTitle
    
        objectWorkInstructionBuilder1.Work.SheetTitle = str(Program_Folder + "- Sheet " + str(op_data_list2[ix]))
    
        objectWorkInstructionBuilder1.Work.ItemName = "OWI_PROD_VIEW_2"
    
        camera32 = nXObject35
        cameraBuilder36 = workPart.Cameras.CreateCameraBuilder(modelingView1, layout1, camera32)
    
        nXObject36 = cameraBuilder36.Commit()
    
        cameraBuilder36.Destroy()
    
        sheettitle28 = objectWorkInstructionBuilder1.Work.SheetTitle
        
        cameraBuilder37 = workPart.Cameras.CreateCameraBuilder(modelingView1, layout1, NXOpen.Display.Camera.Null)
    
        nXObject37 = cameraBuilder37.Commit()
    
        cameraBuilder37.Destroy()
    
        objectWorkInstructionBuilder1.Work.CaptureCurrentView()
    
        objectWorkInstructionBuilder1.Work.CameraName = "Isometric"
    
        objectWorkInstructionBuilder1.Work.CommitItem()
        
        camera33 = nXObject36
        cameraBuilder38 = workPart.Cameras.CreateCameraBuilder(modelingView1, layout1, camera33)
        
        nXObject38 = cameraBuilder38.Commit()
    
        cameraBuilder38.Destroy()
        
        layout1.ReplaceView(modelingView1, modelingView1, False)
    
        objectWorkInstructionBuilder1.Work.ItemName = "OWI_OPER_LIST_1"
    
        sheettitle29 = objectWorkInstructionBuilder1.Work.SheetTitle
    
        objectWorkInstructionBuilder1.Work.OperListProgramGroup = op_data_list2[ix]
    
        objectWorkInstructionBuilder1.Work.OperListProgramGroup = op_data_list2[ix]
    
        objectWorkInstructionBuilder1.Work.CommitItem()

        camera34 = nXObject38
        cameraBuilder39 = workPart.Cameras.CreateCameraBuilder(modelingView1, layout1, camera34)
    
        nXObject39 = cameraBuilder39.Commit()
        
        cameraBuilder39.Destroy()
        
    ## End Edit Path Summary Loop
    
    layout1.ReplaceView(modelingView1, modelingView1, False)
    
    markId2 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Author Work Instructions")
    
    theSession.DeleteUndoMark(markId2, None)
    
    markId3 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Author Work Instructions")
    
    theSession.DeleteUndoMark(markId3, None)
    
    theSession.SetUndoMarkName(markId1, "Author Work Instructions")
    
    theSession.DeleteUndoMark(markId1, None)
    
    nXObject40 = objectWorkInstructionBuilder1.Commit()
    
    objectWorkInstructionBuilder1.Destroy()
    
    
    # PUBLISHHHHH
    
    theSession  = NXOpen.Session.GetSession() #type: NXOpen.Session
    workPart = theSession.Parts.Work
    displayPart = theSession.Parts.Display
    holeDrilling1 = workPart.CAMSetup.CAMOperationCollection.FindObject(Selected_Op)

    
    inTaskEnv1 = theSession.IsBatch
    
    theSession.CAMSession.PathDisplay.StepDisplay(True)
    
    markId1 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    workInstructionOutputBuilder1 = workPart.CAMSetup.CreateWorkInstructionOutputBuilder()
    
    workInstructionOutputBuilder1.PageSize = NXOpen.CAM.WorkInstructionOutputBuilder.PageSizeType.Letter
    
    workInstructionOutputBuilder1.ScaleFactor = 1.0
    
    workInstructionOutputBuilder1.OutputFormat = NXOpen.CAM.WorkInstructionOutputBuilder.OutputFormatType.Pdf
    
    workInstructionOutputBuilder1.OutputFile = pdfpath
    
    workInstructionOutputBuilder1.OpenFile = True
    
    workInstructionOutputBuilder1.PageSize = NXOpen.CAM.WorkInstructionOutputBuilder.PageSizeType.A4
    
    theSession.SetUndoMarkName(markId1, "Publish Work Instructions Dialog")
    
    # ----------------------------------------------
    #   Dialog Begin Publish Work Instructions
    # ----------------------------------------------
    markId2 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Publish Work Instructions")
    
    theSession.DeleteUndoMark(markId2, None)
    
    markId3 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Publish Work Instructions")
    
    layout1 = workPart.Layouts.FindObject("L1")
    camera1 = workPart.Cameras.FindObject("NXOWI_CACHE_CURRENT_VIEW")
    cameraBuilder1 = workPart.Cameras.CreateCameraBuilder(workPart.ModelingViews.WorkView, layout1, camera1)
    
    nXObject1 = cameraBuilder1.Commit()
    
    cameraBuilder1.Destroy()
    
    objects1 = [NXOpen.CAM.CAMObject.Null] * 1 
    objects1[0] = holeDrilling1

    layout1.ReplaceView(workPart.ModelingViews.WorkView, workPart.ModelingViews.WorkView, False)
    

    layout1.ReplaceView(workPart.ModelingViews.WorkView, workPart.ModelingViews.WorkView, False)
    

    layout1.ReplaceView(workPart.ModelingViews.WorkView, workPart.ModelingViews.WorkView, False)

    layout1.ReplaceView(workPart.ModelingViews.WorkView, workPart.ModelingViews.WorkView, False)
    
    workPart.ModelingViews.WorkView.Orient(NXOpen.View.Canned.Top, NXOpen.View.ScaleAdjustment.Fit)
    
    workPart.ModelingViews.WorkView.Orient(NXOpen.View.Canned.Front, NXOpen.View.ScaleAdjustment.Fit)
    
    layout1.ReplaceView(workPart.ModelingViews.WorkView, workPart.ModelingViews.WorkView, False)
    
    workInstructionOutputBuilder1.Publish(objects1, holeDrilling1, 0)
    
    camera2 = nXObject1
    camera2.ApplyToView(workPart.ModelingViews.WorkView)
    
    theSession.DeleteUndoMark(markId3, None)
    
    theSession.SetUndoMarkName(markId1, "Publish Work Instructions")
    
    workInstructionOutputBuilder1.Destroy()
    
    
    theSession.CAMSession.PathDisplay.SetToolDisplayType(NXOpen.CAM.PathDisplay.ToolDisplayType.SolidWithHolder)
    
if __name__ == '__main__':
    main()