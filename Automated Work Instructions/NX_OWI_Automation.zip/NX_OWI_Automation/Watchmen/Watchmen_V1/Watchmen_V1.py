import keyboard
import pyautogui

