﻿



string strCmdText;
strCmdText = "/k @py.exe S:\\\\CAD_Office\\\\Muhsin\\\\NXOPEN\\\\NX_OWI_Automation\\\\Error_Checker.py %*";
System.Diagnostics.Process.Start("CMD.exe", strCmdText);
