    #######################################################  
    ### TOOL PATH DISPLAY SHEET LOOP
    create_view_for_tpds()
    if TPDSheetsReq == " Tool Path Display Required":
        NX_Turn_PMIs_Off()
        no_of_ops = len(op_data_list_programs)
    
        for ix in range(len(op_data_list_programs)):    
            theSession.CAMSession.PathDisplay.DisplayToolPath = True
            cavityMilling1 = workPart.CAMSetup.CAMOperationCollection.FindObject(str(op_data_list_programs[ix]))
            theSession.CAMSession.PathDisplay.ShowToolPath(cavityMilling1)
    
            inTaskEnv1 = theSession.IsBatch
    
            theSession.CAMSession.PathDisplay.StepDisplay(True)
    
            objects1 = [NXOpen.CAM.CAMObject.Null] * 1 
            objects1[0] = cavityMilling1
            workPart.CAMSetup.DeleteWorkInstructions(objects1)
    
            objectWorkInstructionBuilder1 = workPart.CAMSetup.CreateObjectWorkInstructionBuilder(cavityMilling1)
        
            markId1 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
        
            theSession.SetUndoMarkName(markId1, "Author Work Instructions Dialog")
        
            objectWorkInstructionBuilder1.Work.SheetNumber = 1
        
            sheettitle1 = objectWorkInstructionBuilder1.Work.SheetTitle
                                                                    
            objectWorkInstructionBuilder1.Work.SheetTitle = str("RETRAC GROUP - " + Program_Folder +" - "+ op_data_list_programs[ix] + " - Tool Path Display Sheet")
        
            sheetnum1 = objectWorkInstructionBuilder1.Work.AddSheet()
        
            sheettitle2 = objectWorkInstructionBuilder1.Work.SheetTitle
        
            objectWorkInstructionBuilder1.Work.TemplateName = "Tool Path Display Sheet [Trial 1]"
        
            objectWorkInstructionBuilder1.Work.CommitMaster()
        
            itemnames1 = [None] * 7 
            itemnames1[0] = "OWI_TEXT_1"
            itemnames1[1] = "OWI_TEXT_2"
            itemnames1[2] = "OWI_PATH_VIEW_2"
            itemnames1[3] = "OWI_PATH_VIEW_1"
            itemnames1[4] = "OWI_PATH_VIEW_3"
            itemnames1[5] = "OWI_PATH_VIEW_4"
            itemnames1[6] = "OWI_TEXT_3"
            objectWorkInstructionBuilder1.Work.UpdateItemsInCurrentSheet(itemnames1)
    
            objectWorkInstructionBuilder1.Work.ItemName = "OWI_PATH_VIEW_1"
        
            layout1 = workPart.Layouts.FindObject("L1")
            camera1 = workPart.Cameras.FindObject("NXOWI_CACHE_CURRENT_VIEW")
            cameraBuilder1 = workPart.Cameras.CreateCameraBuilder(workPart.ModelingViews.WorkView, layout1, camera1)
    
            nXObject1 = cameraBuilder1.Commit()
        
            cameraBuilder1.Destroy()
        
            sheettitle3 = objectWorkInstructionBuilder1.Work.SheetTitle
        
            objectWorkInstructionBuilder1.Work.ViewTool = True
        
            objectWorkInstructionBuilder1.Work.CameraName = "Isometric"
        
            objectWorkInstructionBuilder1.Work.CommitItem()
        
            objectWorkInstructionBuilder1.Work.ItemName = "OWI_PATH_VIEW_2"
        
            camera2 = nXObject1
            cameraBuilder2 = workPart.Cameras.CreateCameraBuilder(workPart.ModelingViews.WorkView, layout1, camera2)
    
            nXObject2 = cameraBuilder2.Commit()
    
            cameraBuilder2.Destroy()
    
            sheettitle4 = objectWorkInstructionBuilder1.Work.SheetTitle
        
            objectWorkInstructionBuilder1.Work.ViewTool = True
            
            objectWorkInstructionBuilder1.Work.CameraName = "Top"
            
            objectWorkInstructionBuilder1.Work.CommitItem()
            
            objectWorkInstructionBuilder1.Work.ItemName = "OWI_PATH_VIEW_3"
            
            camera3 = nXObject2
            cameraBuilder3 = workPart.Cameras.CreateCameraBuilder(workPart.ModelingViews.WorkView, layout1, camera3)
            
            nXObject3 = cameraBuilder3.Commit()
            
            cameraBuilder3.Destroy()
            
            sheettitle4 = objectWorkInstructionBuilder1.Work.SheetTitle
        
            objectWorkInstructionBuilder1.Work.ViewTool = True
            
            objectWorkInstructionBuilder1.Work.CameraName = "Back"
            
            objectWorkInstructionBuilder1.Work.CommitItem()
            
            objectWorkInstructionBuilder1.Work.ItemName = "OWI_PATH_VIEW_4"
            
            camera3 = nXObject2
            cameraBuilder3 = workPart.Cameras.CreateCameraBuilder(workPart.ModelingViews.WorkView, layout1, camera3)
            
            nXObject3 = cameraBuilder3.Commit()
            
            cameraBuilder3.Destroy()
        
            sheettitle5 = objectWorkInstructionBuilder1.Work.SheetTitle
        
            objectWorkInstructionBuilder1.Work.ViewTool = True
        
            objectWorkInstructionBuilder1.Work.CameraName = "Front"
        
            objectWorkInstructionBuilder1.Work.CommitItem()
        
            objectWorkInstructionBuilder1.Work.ItemName = "OWI_TEXT_3"
    
            multilinetext1 = []
            objectWorkInstructionBuilder1.Work.SetRichText(multilinetext1)
    
            sheettitle6 = objectWorkInstructionBuilder1.Work.SheetTitle
    
            multilinetext2 = [None] * 1 
            multilinetext2[0] = "Notes"
            objectWorkInstructionBuilder1.Work.SetRichText(multilinetext2)
        
            objectWorkInstructionBuilder1.Work.CommitItem()
    
            objectWorkInstructionBuilder1.Work.FontSize = 10
    
            objectWorkInstructionBuilder1.Work.CommitItem()
    
            objectWorkInstructionBuilder1.Work.FontFace = "Calibri"
    
            objectWorkInstructionBuilder1.Work.CommitItem()
    
            multilinetext3 = [None] * 1 
            multilinetext3[0] = ""
            objectWorkInstructionBuilder1.Work.SetRichText(multilinetext3)
    
            objectWorkInstructionBuilder1.Work.CommitItem()
    
            objectWorkInstructionBuilder1.Work.ItemName = "OWI_TEXT_1"
    
            multilinetext4 = []
            objectWorkInstructionBuilder1.Work.SetRichText(multilinetext4)
        
            sheettitle7 = objectWorkInstructionBuilder1.Work.SheetTitle
    
            multilinetext5 = [None] * 1 
            multilinetext5[0] = Project_Name
            objectWorkInstructionBuilder1.Work.SetRichText(multilinetext5)
        
            objectWorkInstructionBuilder1.Work.CommitItem()
        
            objectWorkInstructionBuilder1.Work.FontSize = 16
        
            objectWorkInstructionBuilder1.Work.CommitItem()
    
            objectWorkInstructionBuilder1.Work.FontFace = "Calibri"
    
            objectWorkInstructionBuilder1.Work.CommitItem()
    
            objectWorkInstructionBuilder1.Work.ItemName = "OWI_TEXT_2"
    
            multilinetext6 = []
            objectWorkInstructionBuilder1.Work.SetRichText(multilinetext6)
        
            sheettitle8 = objectWorkInstructionBuilder1.Work.SheetTitle
    
            markId2 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Author Work Instructions")
    
            multilinetext7 = [None] * 1 
            multilinetext7[0] = Machine_Name
            objectWorkInstructionBuilder1.Work.SetRichText(multilinetext7)
    
            objectWorkInstructionBuilder1.Work.CommitItem()
        
            objectWorkInstructionBuilder1.Work.FontSize = 16
    
            objectWorkInstructionBuilder1.Work.CommitItem()
    
            objectWorkInstructionBuilder1.Work.FontFace = "Calibri"
        
            objectWorkInstructionBuilder1.Work.CommitItem()
    
            theSession.DeleteUndoMark(markId2, None)
        
            markId3 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Author Work Instructions")
    
            theSession.DeleteUndoMark(markId3, None)
    
            theSession.SetUndoMarkName(markId1, "Author Work Instructions")
        
            theSession.DeleteUndoMark(markId1, None)
    
            nXObject4 = objectWorkInstructionBuilder1.Commit()
    
            objectWorkInstructionBuilder1.Destroy()
    
            markId4 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
            workInstructionOutputBuilder1 = workPart.CAMSetup.CreateWorkInstructionOutputBuilder()
    
            workInstructionOutputBuilder1.PageSize = NXOpen.CAM.WorkInstructionOutputBuilder.PageSizeType.Letter
    
            workInstructionOutputBuilder1.ScaleFactor = 1.0
        
            workInstructionOutputBuilder1.OutputFormat = NXOpen.CAM.WorkInstructionOutputBuilder.OutputFormatType.Pdf
                
            workInstructionOutputBuilder1.OutputFile = str(pdfdirectory2 + str(ix + 1) +"- "+ str(op_data_list_programs[ix]) + " - Tool Path Display Sheet.pdf")
    
            theSession.SetUndoMarkName(markId4, "Publish Work Instructi29ons Dialog")
            with open("S:\\CAD_Office\\Muhsin\\NXOPEN\\NX_OWI_Automation\\WI_DATA\\WorkInstructionsData-" + username + ".txt") as file:
                lines = [line.rstrip() for line in file]
                if 'USER CANCELLED' in lines:
                    return
                else:
                    file.close()    
    # ----------------------------------------------
    #   Dialog Begin Publish Work Instructions
    # ----------------------------------------------
            markId5 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Publish Work Instructions")
                        
            workInstructionOutputBuilder1.OutputFile = str(pdfdirectory2 + str(ix + 1) +"- "+ str(op_data_list_programs[ix]) + " - Tool Path Display Sheet.pdf")
    
            theSession.DeleteUndoMark(markId5, None)
    
            markId6 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Publish Work Instructions")
        
            camera4 = nXObject3
            cameraBuilder4 = workPart.Cameras.CreateCameraBuilder(workPart.ModelingViews.WorkView, layout1, camera4)
            
            nXObject5 = cameraBuilder4.Commit()
    
            cameraBuilder4.Destroy()
    
            objects2 = [NXOpen.CAM.CAMObject.Null] * 1 
            objects2[0] = cavityMilling1
            workPart.ModelingViews.WorkView.Orient(NXOpen.View.Canned.Top, NXOpen.View.ScaleAdjustment.Fit)
        
            workPart.ModelingViews.WorkView.Orient(NXOpen.View.Canned.Isometric, NXOpen.View.ScaleAdjustment.Fit)
    
            workPart.ModelingViews.WorkView.Orient(NXOpen.View.Canned.Front, NXOpen.View.ScaleAdjustment.Fit)
        
            workInstructionOutputBuilder1.Publish(objects2, cavityMilling1, 0)
    
            camera5 = nXObject5
            camera5.ApplyToView(workPart.ModelingViews.WorkView)
    
            theSession.DeleteUndoMark(markId6, None)
        
            theSession.SetUndoMarkName(markId4, "Publish Work Instructions")
    
            workInstructionOutputBuilder1.Destroy()
            with open("S:\\CAD_Office\\Muhsin\\NXOPEN\\NX_OWI_Automation\\WI_DATA\\WorkInstructionsData-" + username + ".txt") as file:
                lines = [line.rstrip() for line in file]
                if 'USER CANCELLED' in lines:
                    return
                else:
                    file.close()             
            
        
        
        NX_Turn_PMIs_On()
    ####################################################### 