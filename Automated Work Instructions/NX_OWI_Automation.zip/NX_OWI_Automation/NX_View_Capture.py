﻿# NX 2312
# Journal created by muhsin.caglar on Mon Sep  9 10:09:48 2024 GMT Summer Time
#

import math
import NXOpen
import NXOpen.CAM

import subprocess
import sys

# Add the path to the desired Python environment
custom_python_lib_path = "C:\\Users\\muhsin.caglar\\Python\Lib\\site-packages"
sys.path.append(custom_python_lib_path)
import pyautogui
from pynput import mouse
import pyautogui

click_x = None
click_y = None
text_file = open("S:\\CAD_Office\\Muhsin\\NXOPEN\\NX_OWI_Automation\\WI_DATA\\Output.txt", "w")
# Define the callback function to capture the click position
click_positions = []

# Define the callback function to capture the click position
def on_click(x, y, button, pressed):
    if pressed:
        click_positions.append((x, y))
        text_file.write(click_positions)
        # Stop listening after the second click
        if len(click_positions) == 2:
            return False

# Start listening to mouse events
with mouse.Listener(on_click=on_click) as listener:
    listener.join()


def set_view_to_tool_axis(tool_axis_object):
    # Get the NX session
    Session = NXOpen.Session.GetSession()
    
    # Get the current work view
    work_view = Session.Views.WorkView
    
    # Get the tool axis direction (assuming tool_axis_object has direction information)
    # You may need to adapt this part depending on how you get the tool axis direction
    tool_axis_direction = tool_axis_object.GetDirection()  # Placeholder for actual direction retrieval
    
    # Create a new direction vector
    view_direction = nxopen.Vector(tool_axis_direction.X, tool_axis_direction.Y, tool_axis_direction.Z)
    
    # Set the view direction to the tool axis
    work_view.SetViewDirection(view_direction)
    
    # Update the view to apply the new direction
    work_view.Update()




def main() : 

    theSession  = NXOpen.Session.GetSession() #type: NXOpen.Session
    workPart = theSession.Parts.Work
    displayPart = theSession.Parts.Display
    
    with mouse.Listener(on_click=on_click) as listener:
        listener.join()

    with open("S:\\CAD_Office\\Muhsin\\NXOPEN\\NX_OWI_Automation\\WI_DATA\\SSBoundaries.txt", "w") as file:
        for index, (x, y) in enumerate(click_positions, start=1):
            file.write(f"X{x}X,Y{y}Y\n")
            
    
    first_coord = str(click_positions[0])
    start_index = first_coord.rindex("(")
    end_index = first_coord.rindex(",")
    first_coord_x = first_coord[start_index +1 : end_index]
    
    start_index2 = first_coord.rindex(",")
    end_index2 = first_coord.rindex(")")
    first_coord_y = first_coord[start_index2 + 2: end_index2]
    text_file.write(first_coord_x)
    text_file.write(",")
    text_file.write(first_coord_y)
    
    sec_coord = str(click_positions[1])
    start_index = sec_coord.rindex("(")
    end_index = sec_coord.rindex(",")
    sec_coord_x = sec_coord[start_index +1 : end_index]
    
    start_index2 = sec_coord.rindex(",")
    end_index2 = sec_coord.rindex(")")
    sec_coord_y = sec_coord[start_index2 + 2: end_index2]
    text_file.write(sec_coord_x)
    text_file.write(",")
    text_file.write(sec_coord_y)
    first_coord_x = int(first_coord_x)
    first_coord_y = int(first_coord_y)
    sec_coord_x = int(sec_coord_x)
    sec_coord_y = int(sec_coord_y)
    
    theSession  = NXOpen.Session.GetSession() #type: NXOpen.Session
    workPart = theSession.Parts.Work
    displayPart = theSession.Parts.Display
    # ----------------------------------------------
    #   Menu: Tools->Tool Path Display->Display Tool Path
    # ----------------------------------------------
    theSession.CAMSession.PathDisplay.DisplayToolPath = True
    
    # ----------------------------------------------
    #   Menu: Tools->Tool Path Display->Select Tool Path
    # ----------------------------------------------
    zLevelMilling1 = workPart.CAMSetup.CAMOperationCollection.FindObject("RUF_SIDE_1")
    
    set_view_to_tool_axis(zLevelMilling1)
    
    theSession.CAMSession.PathDisplay.ShowToolPath(zLevelMilling1)
    
    inTaskEnv1 = theSession.IsBatch
    
    theSession.CAMSession.PathDisplay.StepDisplay(True)
    
    # ----------------------------------------------
    #   Menu: Set View to Tool Axis
    # ----------------------------------------------
    # ----------------------------------------------
    #   Menu: Fit
    # ----------------------------------------------
    workPart.ModelingViews.WorkView.Fit()

    
    
    im = pyautogui.screenshot(region=(first_coord_x,first_coord_y, sec_coord_x - first_coord_x ,sec_coord_y - first_coord_y))
    im.save('C:\\Users\\muhsin.caglar\\OneDrive - Retrac Productions Ltd\\Desktop\\my_screenshot.png')


    
if __name__ == '__main__':
    main()
