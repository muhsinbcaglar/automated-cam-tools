import pyautogui
import keyboard
import time 
import PIL
import numpy as np
from mss import mss
from datetime import datetime
from PIL import ImageGrab
import os
import ctypes
from wakepy import keep


##### MANUAL RUN CODE    @py.exe S:\CAD_Office\Muhsin\NXOPEN\NX_OWI_Automation\Error_Checker.py %*
## @py.exe C:\Program Files\Python313\Lib\site-packages\pip\_vendor\rich\jupyter.py %*
def main() :

    with keep.presenting():
        #### IMAGE PATHS & USERNAME
        username = str(os.getlogin())
        username = username.replace(".", "")
        image_path = "S:\\CAD_Office\\Muhsin\\NXOPEN\\NX_OWI_Automation\\ErrorMessage.png"
        #### MAIN FUNCTION
        def dismiss_error(image_path):        
            ####
            while True:
                ##### USE THIS LOOP TO STOP SIMULATION
                with open("S:\\CAD_Office\\Muhsin\\NXOPEN\\NX_OWI_Automation\\WI_DATA\\WorkInstructionsData-" + username + ".txt") as file:
                    lines = [line.rstrip() for line in file]
                    if 'USER CANCELLED' in lines:
                        print("Work Instructions Completed!")
                        time.sleep(1)
                        #f = open("S:\\CAD_Office\\Muhsin\\NXOPEN\\NX_OWI_Automation\\WI_DATA\\WorkInstructionsData-" + username + ".txt", "w")
                        #f.write("")
                        break
                    else:
                        file.close()
                with open("S:\\CAD_Office\\Muhsin\\NXOPEN\\NX_OWI_Automation\\WI_DATA\\WorkInstructionsData-" + username + ".txt") as file:
                    lines = [line.rstrip() for line in file]
                    if 'Work Instructions Complete.' in lines:
                        print("Work Instructions Completed!")
                        time.sleep(1)
                        #f = open("S:\\CAD_Office\\Muhsin\\NXOPEN\\NX_OWI_Automation\\WI_DATA\\WorkInstructionsData-" + username + ".txt", "w")
                        #f.write("")
                        break
                    else:
                        file.close()

                #### WHEN WI CREATION IS FINISHED    
                if keyboard.is_pressed('q'):
                    print("User Abort. Watchmen terminated!")
                    break

                try:
                    
                    location = pyautogui.locateCenterOnScreen(image_path, region=(0,0,1920,1080), confidence=0.7)
                    locationx, locationy = pyautogui.locateCenterOnScreen(image_path, region=(0,0,1920,1080), confidence=0.7)
                    #print(str(locationy))

                    # IF ERROR MESSAGE FOUND
                    if location is not None:
                        pyautogui.click(x=locationx, y=locationy, clicks=1)
                        keyboard.press('enter')
                        keyboard.release('enter')

                        time.sleep(0.5)
                    #IF NO ERROR MESSAGE
                    else:
                        print("..")
                        time.sleep(0.5)
                #IF NO ERROR MESSAGE
                except:
                    location = None
                    print(".")

                    time.sleep(0.5)
        #RUN FUNCTION
        dismiss_error(image_path)
        #FUNCTION TO PRINT MOUSE POSITION
        #print(str(pyautogui. position()))
if __name__ == '__main__':
    main()