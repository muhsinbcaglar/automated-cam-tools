namespace NXOWI_Manual_Exit
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string username = Environment.UserName;
            username = username.Replace(".", "");
            string path = @"S:\CAD_Office\Muhsin\NXOPEN\NX_OWI_Automation\WI_DATA\WorkInstructionsData-" + username + ".txt";
            string aUserCancel = "USER CANCELLED";
            File.WriteAllLines(path, new[] { aUserCancel });


            if (MessageBox.Show("This will close down the whole application. Confirm?", "Retrac - Work Instructions", MessageBoxButtons.OKCancel) == DialogResult.OK)
            {
                System.Windows.Forms.Application.Exit();
            }
            else
            {
                this.Activate();
            }
        }
    }
}
