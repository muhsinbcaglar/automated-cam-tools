
import NXOpen
import math

import NXOpen.CAM
import NXOpen.Display
import subprocess 

import os
def export_parts_as_step():
    exe_path = "S:\\CAD_Office\\Muhsin\\NXOPEN\\NX STP FILE CREATOR1\\NX_STP_File_Creator\\bin\\Debug\\NX_STP_File_Creator.exe"
    subprocess.run([exe_path], capture_output=True, text=True, check=True)
        
        
    with open("S:\\CAD_Office\\Muhsin\\NXOPEN\\WorkInstructionsData.txt") as file:
        lines = [line.rstrip() for line in file]
        if 'USER CANCELLED' in lines:
            return
    PATH_DATA = str(lines)
    
    the_session = nxopen.Session.GetSession()    
    work_part = the_session.Parts.Work
 
    components = work_part.ComponentAssembly.RootComponent.GetChildren()
    for component in components:
        component_part = component.Prototype.OwningPart        
        if component_part:
            component_name = component_part.Name
            step_file_path = PATH_DATA 

            step_export = the_session.DexManager.NewStep214FileWriter()
            step_export.InputPart = component_part
            step_export.ExportAsSingleFile = False
            step_export.OutputFile = step_file_path
            step_export.WriteAll = True
            step_export.Commit()
            step_export.Destroy()


export_parts_as_step()
