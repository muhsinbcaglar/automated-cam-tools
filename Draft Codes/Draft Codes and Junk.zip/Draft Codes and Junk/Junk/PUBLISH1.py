﻿# NX 2312
# Journal created by muhsin.caglar on Fri Aug  2 11:04:26 2024 GMT Summer Time
#
import math
import NXOpen
import NXOpen.CAM
def main() : 

    theSession  = NXOpen.Session.GetSession() #type: NXOpen.Session
    workPart = theSession.Parts.Work
    displayPart = theSession.Parts.Display
    objects1 = [NXOpen.CAM.CAMObject.Null] * 1 
    theUI = NXOpen.UI.GetUI() #type: NXOpen.UI
    
    objects1[0] = theUI.SelectionManager.GetSelectedTaggedObject(0)
    workPart.CAMSetup.DeleteWorkInstructions(objects1)
    
    theSession.CAMSession.PathDisplay.HideToolPath(theUI.SelectionManager.GetSelectedTaggedObject(0))
    
    surfaceContour1 = workPart.CAMSetup.CAMOperationCollection.FindObject("PICK-2MM_02")
    theSession.CAMSession.PathDisplay.ShowToolPath(surfaceContour1)
    
    inTaskEnv1 = theSession.IsBatch
    
    theSession.CAMSession.PathDisplay.StepDisplay(True)
    
    objects2 = [NXOpen.CAM.CAMObject.Null] * 1 
    objects2[0] = surfaceContour1
    workPart.CAMSetup.DeleteWorkInstructions(objects2)
    
    theSession.CAMSession.PathDisplay.HideToolPath(surfaceContour1)
    
    # ----------------------------------------------
    #   Menu: Tools->Automation->Journal->Stop Recording
    # ----------------------------------------------
    
if __name__ == '__main__':
    main()