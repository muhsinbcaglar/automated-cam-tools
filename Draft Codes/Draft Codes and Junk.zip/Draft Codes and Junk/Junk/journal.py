﻿# NX 2312
# Journal created by muhsin.caglar on Thu Aug  1 10:04:55 2024 GMT Summer Time
#
import math
import NXOpen
import NXOpen.CAM
def main() : 

    theSession  = NXOpen.Session.GetSession() #type: NXOpen.Session
    workPart = theSession.Parts.Work
    displayPart = theSession.Parts.Display
    theUI = NXOpen.UI.GetUI() #type: NXOpen.UI
    

    
    nCGroup1 = workPart.CAMSetup.CAMGroupCollection.FindObject("OP-1")
    theSession.CAMSession.PathDisplay.ShowToolPath(nCGroup1)
    
    theSession.CAMSession.PathDisplay.HideToolPath(nCGroup1)
    
    markId1 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Create Program")
    
    nCGroup2 = workPart.CAMSetup.CAMGroupCollection.CreateProgram(nCGroup1, "mill_planar", "PROGRAM", NXOpen.CAM.NCGroupCollection.UseDefaultName.TrueValue, "PROGRAM")
    
    markId2 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    programOrderGroupBuilder1 = workPart.CAMSetup.CAMGroupCollection.CreateProgramOrderGroupBuilder(nCGroup2)
    
    theSession.SetUndoMarkName(markId2, "Program Dialog")
    
    taggedObject1 = programOrderGroupBuilder1.StartUdeSet.UdeList.FindItem(0)
    
    # ----------------------------------------------
    #   Dialog Begin Program
    # ----------------------------------------------
    markId3 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Program")
    
    theSession.DeleteUndoMark(markId3, None)
    
    markId4 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Program")
    
    nXObject1 = programOrderGroupBuilder1.Commit()
    
    theSession.DeleteUndoMark(markId4, None)
    
    theSession.SetUndoMarkName(markId2, "Program")
    
    programOrderGroupBuilder1.Destroy()
    
    theSession.DeleteUndoMark(markId2, None)
    
    theSession.CAMSession.Utils.SetInspectionIntent(False)
    
    # ----------------------------------------------
    #   Menu: Tools->Automation->Journal->Stop Recording
    # ----------------------------------------------
    
if __name__ == '__main__':
    main()
