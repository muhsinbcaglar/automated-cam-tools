import math
import NXOpen
import NXOpen.Features
import NXOpen.Assemblies
import NXOpen.MenuBar
import NXOpen.CAM
import json
 
def main():
    theSession = NXOpen.Session.GetSession()
    theSession.Parts.LoadOptions.UsePartialLoading = False
    

    displayPart = theSession.Parts.Display
    workPart = theSession.Parts.Work
    FilePath = str(theSession.Parts.Work.FullPath)
    camSession = theSession.CreateCamSession()
    start_point = workPart.CAMSetup.CAMOperationCollection.FindObject("NC_PROGRAM")
    objects_at_start = NXOpen.CAM.NCGroup.GetMembers(start_point)
    group_list = []
    checked_list = []
    operation_list = []
    
    def _get_op_data(obj):
        op_data = {}
        op_data['Operation name'] = obj.Name
        program_name = obj.GetParent(NXOpen.CAM.CAMSetup.View.ProgramOrder)
        op_data['Program Name'] =  program_name.Name
        obj.Print()
        return op_data
    
    op_data_list = []
    for each_object in objects_at_start:
        if workPart.CAMSetup.IsGroup(each_object) == True:
            group_list.append(each_object.Name)
        elif workPart.CAMSetup.IsOperation(each_object) == True:
            op_data = _get_op_data(each_object)
            op_data_list.append(op_data)
 
    while group_list != checked_list:
        for each_object in group_list:
            if each_object not in checked_list:
                temp_objects = get_group_objects(each_object,workPart)
                for sub_object in temp_objects:
                    if workPart.CAMSetup.IsGroup(sub_object) == True:
                        group_list.append(sub_object.Name)
                    elif workPart.CAMSetup.IsOperation(sub_object) == True:
                        op_data = _get_op_data(sub_object)
                        op_data_list.append(op_data)
                checked_list.append(each_object)
    text_file = open("S:\\CAD_Office\\Muhsin\\NXOPEN\\Output.txt", "w")
    
    s = str(op_data_list)
    s = s.replace("[","")
    s = s.replace("{","")
    s = s.replace("}","")
    s = s.replace("]","")
    s = s.replace(",","\n")
    
    s_index1 = s.rindex("'Operation name':")
    s = s[s_index1:]
    s_index2 = s.rindex("'Program Name':")
    s = s[:s_index2]
    s = s.replace("'Operation name': '","")
    s = s.replace("'","")
    
    Selected_Op = s
    
    
    with open("S:\\CAD_Office\\Muhsin\\NXOPEN\\WorkInstructionsData.txt") as file:
        lines = [line.rstrip() for line in file]
    
    WI_DATA = str(lines)
    
    WI_DATA = WI_DATA.replace("'","")
    WI_DATA = WI_DATA.replace("[","")   
    WI_DATA = WI_DATA.replace("]","")

    start_index = WI_DATA.rindex("-1- ")
    end_index = WI_DATA.rindex(" -1-")
    Project_Name = WI_DATA[start_index + 4: end_index]
    
    start_index = WI_DATA.rindex("-2- ")
    end_index = WI_DATA.rindex(" -2-")
    Program_Folder = WI_DATA[start_index + 4: end_index]
    
    start_index = WI_DATA.rindex("-3- ")
    end_index = WI_DATA.rindex(" -3-")
    Rev_No = WI_DATA[start_index + 4: end_index]
    
    start_index = WI_DATA.rindex("-4- ")
    end_index = WI_DATA.rindex(" -4-")
    Costumer_Name = WI_DATA[start_index + 4: end_index]

    start_index = WI_DATA.rindex("-5- ")
    end_index = WI_DATA.rindex(" -5-")
    Machine_Name = WI_DATA[start_index + 4: end_index]
    
    start_index = WI_DATA.rindex("-6- ")
    end_index = WI_DATA.rindex(" -6-")
    Instructions_Text = WI_DATA[start_index + 4: end_index]
    
    start_index = WI_DATA.rindex("-7- ")
    end_index = WI_DATA.rindex(" -7-")
    Datum_Info = WI_DATA[start_index + 4: end_index]
    
    start_index = WI_DATA.rindex("-8- ")
    end_index = WI_DATA.rindex(" -8-")
    WorkHold_Info    = WI_DATA[start_index + 4: end_index]
    
    start_index = WI_DATA.rindex("-9- ")
    end_index = WI_DATA.rindex(" -9-")
    AsOpp_Info = WI_DATA[start_index + 4: end_index]
    
    start_index = WI_DATA.rindex("-10- ")
    end_index = WI_DATA.rindex(" -10-")
    Notes_Text = WI_DATA[start_index + 4: end_index]
    
    
    fp_index = FilePath.rindex("\\")
    
    FilePath = FilePath[:fp_index+1]
    FilePath = FilePath.replace("\\","\\\\")
    
    text_file.write(FilePath)
    text_file.close()
 

 
def get_group_objects(group_name,workPart):
    find_it = workPart.CAMSetup.CAMOperationCollection.FindObject(group_name)
    new_objects = NXOpen.CAM.NCGroup.GetMembers(find_it)
    return new_objects



main()
