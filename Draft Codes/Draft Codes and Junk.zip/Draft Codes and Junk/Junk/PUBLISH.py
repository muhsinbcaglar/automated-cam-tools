﻿# NX 2312
# Journal created by muhsin.caglar on Fri Aug  9 12:01:53 2024 GMT Summer Time
#
import math
import NXOpen
import NXOpen.Features
def main() : 

    theSession  = NXOpen.Session.GetSession() #type: NXOpen.Session
    workPart = theSession.Parts.Work
    displayPart = theSession.Parts.Display
    markId1 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Assign Name")
    
    featureGroup1 = workPart.Features.FindObject("FEATURE_SET(99)")
    featureGroup1.SetName("Vice-1")
    
    nErrs1 = theSession.UpdateManager.DoUpdate(markId1)
    
    theSession.SetUndoMarkVisibility(markId1, "Assign Name", NXOpen.Session.MarkVisibility.Visible)
    
    # ----------------------------------------------
    #   Menu: Tools->Automation->Journal->Stop Recording
    # ----------------------------------------------
    
if __name__ == '__main__':
    main()