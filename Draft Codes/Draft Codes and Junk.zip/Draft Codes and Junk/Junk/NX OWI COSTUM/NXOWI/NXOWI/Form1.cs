using Microsoft.VisualBasic.ApplicationServices;
using System.IO;

namespace NXOWI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string aProgFolder = textBox5.Text;
            string aProject = textBox1.Text;
            string aRevision = comboBox2.Text;
            string aCostumer = comboBox5.Text;
            string aMachine = comboBox1.Text;
            string aInstructions = textBox2.Text;
            string aDatum = textBox3.Text;
            string aWorkHolding = comboBox6.Text;
            string aAsOpp = comboBox3.Text;
            string aNotes = textBox4.Text;
            string path = @"S:\CAD_Office\Muhsin\NXOPEN\WorkInstructionsData.txt";
            string path1 = @"S:\CAD_Office\Muhsin\NXOPEN\WorkInstructionsData_" + textBox5.Text + ".txt";
            File.WriteAllLines(path, new[] { "-1- " + aProject + " -1-" });
            File.AppendAllLines(path, new[] { "-2- " + aProgFolder + " -2-" });
            File.AppendAllLines(path, new[] { "-3- " + aRevision + " -3-" });
            File.AppendAllLines(path, new[] { "-4- " + aCostumer + " -4-" });
            File.AppendAllLines(path, new[] { "-5- " + aMachine + " -5-" });
            File.AppendAllLines(path, new[] { "-6- " + aInstructions + " -6-" });
            File.AppendAllLines(path, new[] { "-7- " + aDatum + " -7-" });
            File.AppendAllLines(path, new[] { "-8- " + aWorkHolding + " -8-"});
            File.AppendAllLines(path, new[] { "-9- " + aAsOpp + " -9-" });
            File.AppendAllLines(path, new[] { "-10- " + aNotes + " -10-" });

            File.WriteAllLines(path1, new[] {aProject});
            File.AppendAllLines(path1, new[] {aProgFolder});
            File.AppendAllLines(path1, new[] {aRevision});
            File.AppendAllLines(path1, new[] {aCostumer});
            File.AppendAllLines(path1, new[] {aMachine});
            File.AppendAllLines(path1, new[] {aInstructions});
            File.AppendAllLines(path1, new[] {aDatum});
            File.AppendAllLines(path1, new[] {aWorkHolding});
            File.AppendAllLines(path1, new[] {aAsOpp});
            File.AppendAllLines(path1, new[] {aNotes});






            MessageBox.Show("Required data captured.", "Retrac - Work Instructions", MessageBoxButtons.OK);
            System.Windows.Forms.Application.Exit();
        }

        private void button2_Click(object sender, EventArgs e)
        
        
        {
            string path = @"S:\CAD_Office\Muhsin\NXOPEN\WorkInstructionsData.txt";
            string aUserCancel = "USER CANCELLED";
            File.WriteAllLines(path, new[] { aUserCancel });


            if (MessageBox.Show("This will close down the whole application. Confirm?", "Retrac - Work Instructions", MessageBoxButtons.OKCancel) == DialogResult.OK)
            {
                System.Windows.Forms.Application.Exit();
            }
            else
            {
                this.Activate();
            }
        }
    }
}
