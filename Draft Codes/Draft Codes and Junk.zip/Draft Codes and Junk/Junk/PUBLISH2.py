﻿# NX 2312
# Journal created by muhsin.caglar on Fri Aug  2 11:46:33 2024 GMT Summer Time
#
import math
import NXOpen
import NXOpen.CAM
import NXOpen.Display
def main() : 

    theSession  = NXOpen.Session.GetSession() #type: NXOpen.Session
    workPart = theSession.Parts.Work
    displayPart = theSession.Parts.Display
    holeDrilling1 = workPart.CAMSetup.CAMOperationCollection.FindObject("DRILL-8.0")
    theSession.CAMSession.PathDisplay.ShowToolPath(holeDrilling1)
    
    inTaskEnv1 = theSession.IsBatch
    
    theSession.CAMSession.PathDisplay.StepDisplay(True)
    
    markId1 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    workInstructionOutputBuilder1 = workPart.CAMSetup.CreateWorkInstructionOutputBuilder()
    
    workInstructionOutputBuilder1.PageSize = NXOpen.CAM.WorkInstructionOutputBuilder.PageSizeType.Letter
    
    workInstructionOutputBuilder1.ScaleFactor = 1.0
    
    workInstructionOutputBuilder1.OutputFormat = NXOpen.CAM.WorkInstructionOutputBuilder.OutputFormatType.Pdf
    
    workInstructionOutputBuilder1.OutputFile = "C:\\Users\\muhsin.caglar\\OneDrive - Retrac Productions Ltd\\Desktop\\JUNK\\owi\\22222.pdf"
    
    workInstructionOutputBuilder1.OpenFile = True
    
    workInstructionOutputBuilder1.PageSize = NXOpen.CAM.WorkInstructionOutputBuilder.PageSizeType.A4
    
    theSession.SetUndoMarkName(markId1, "Publish Work Instructions Dialog")
    
    # ----------------------------------------------
    #   Dialog Begin Publish Work Instructions
    # ----------------------------------------------
    markId2 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Publish Work Instructions")
    
    theSession.DeleteUndoMark(markId2, None)
    
    markId3 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Publish Work Instructions")
    
    layout1 = workPart.Layouts.FindObject("L1")
    camera1 = workPart.Cameras.FindObject("NXOWI_CACHE_CURRENT_VIEW")
    cameraBuilder1 = workPart.Cameras.CreateCameraBuilder(workPart.ModelingViews.WorkView, layout1, camera1)
    
    nXObject1 = cameraBuilder1.Commit()
    
    cameraBuilder1.Destroy()
    
    objects1 = [NXOpen.CAM.CAMObject.Null] * 1 
    objects1[0] = holeDrilling1
    layout1.ReplaceView(workPart.ModelingViews.WorkView, workPart.ModelingViews.WorkView, False)
    
    layout1.ReplaceView(workPart.ModelingViews.WorkView, workPart.ModelingViews.WorkView, False)
    
    layout1.ReplaceView(workPart.ModelingViews.WorkView, workPart.ModelingViews.WorkView, False)
    
    layout1.ReplaceView(workPart.ModelingViews.WorkView, workPart.ModelingViews.WorkView, False)
    
    workPart.ModelingViews.WorkView.Orient(NXOpen.View.Canned.Top, NXOpen.View.ScaleAdjustment.Fit)
    
    workPart.ModelingViews.WorkView.Orient(NXOpen.View.Canned.Front, NXOpen.View.ScaleAdjustment.Fit)
    
    layout1.ReplaceView(workPart.ModelingViews.WorkView, workPart.ModelingViews.WorkView, False)
    
    workInstructionOutputBuilder1.Publish(objects1, holeDrilling1, 0)
    
    camera2 = nXObject1
    camera2.ApplyToView(workPart.ModelingViews.WorkView)
    
    theSession.DeleteUndoMark(markId3, None)
    
    theSession.SetUndoMarkName(markId1, "Publish Work Instructions")
    
    workInstructionOutputBuilder1.Destroy()
    
    # ----------------------------------------------
    #   Menu: Tools->Automation->Journal->Play...
    # ----------------------------------------------
    theSession.Parts.LoadOptions.UsePartialLoading = False
    
    part1 = theSession.Parts.Display
    
    part2 = theSession.Parts.Work
    
    part3 = theSession.Parts.Work
    
    fullPath1 = workPart.FullPath
    
    theSession.CreateCamSession()
    
    cAMSetup1 = workPart.CAMSetup
    
    operation1 = cAMSetup1.CAMOperationCollection.FindObject("NC_PROGRAM")
    
    nCGroup1 = operation1
    members1 = nCGroup1.GetMembers()
    
    cAMSetup2 = workPart.CAMSetup
    
    nCGroup2 = cAMSetup2.CAMGroupCollection.FindObject("NONE")
    isgroup1 = cAMSetup2.IsGroup(nCGroup2)
    
    name1 = nCGroup2.Name
    
    cAMSetup3 = workPart.CAMSetup
    
    nCGroup3 = cAMSetup3.CAMGroupCollection.FindObject("OP-1")
    isgroup2 = cAMSetup3.IsGroup(nCGroup3)
    
    name2 = nCGroup3.Name
    
    cAMSetup4 = workPart.CAMSetup
    
    operation2 = cAMSetup4.CAMOperationCollection.FindObject(name1)
    
    nCGroup4 = operation2
    members2 = nCGroup4.GetMembers()
    
    cAMSetup5 = workPart.CAMSetup
    
    surfaceContour1 = cAMSetup5.CAMOperationCollection.FindObject("CONTOUR_SURFACE_AREA")
    isgroup3 = cAMSetup5.IsGroup(surfaceContour1)
    
    cAMSetup6 = workPart.CAMSetup
    
    isoperation1 = cAMSetup6.IsOperation(surfaceContour1)
    
    name3 = surfaceContour1.Name
    
    nCGroup5 = surfaceContour1.GetParent(NXOpen.CAM.CAMSetup.View.ProgramOrder)
    
    name4 = nCGroup5.Name
    
    surfaceContour1.Print()
    
    cAMSetup7 = workPart.CAMSetup
    
    surfaceContour2 = cAMSetup7.CAMOperationCollection.FindObject("ROUGH_SURFACE-01")
    isgroup4 = cAMSetup7.IsGroup(surfaceContour2)
    
    cAMSetup8 = workPart.CAMSetup
    
    isoperation2 = cAMSetup8.IsOperation(surfaceContour2)
    
    name5 = surfaceContour2.Name
    
    nCGroup6 = surfaceContour2.GetParent(NXOpen.CAM.CAMSetup.View.ProgramOrder)
    
    name6 = nCGroup6.Name
    
    surfaceContour2.Print()
    
    cAMSetup9 = workPart.CAMSetup
    
    volumeBased25DMillingOperation1 = cAMSetup9.CAMOperationCollection.FindObject("FLOOR_FACING")
    isgroup5 = cAMSetup9.IsGroup(volumeBased25DMillingOperation1)
    
    cAMSetup10 = workPart.CAMSetup
    
    isoperation3 = cAMSetup10.IsOperation(volumeBased25DMillingOperation1)
    
    name7 = volumeBased25DMillingOperation1.Name
    
    nCGroup7 = volumeBased25DMillingOperation1.GetParent(NXOpen.CAM.CAMSetup.View.ProgramOrder)
    
    name8 = nCGroup7.Name
    
    volumeBased25DMillingOperation1.Print()
    
    cAMSetup11 = workPart.CAMSetup
    
    zLevelMilling1 = cAMSetup11.CAMOperationCollection.FindObject("FINISH_PROFILE_ZLEVEL")
    isgroup6 = cAMSetup11.IsGroup(zLevelMilling1)
    
    cAMSetup12 = workPart.CAMSetup
    
    isoperation4 = cAMSetup12.IsOperation(zLevelMilling1)
    
    name9 = zLevelMilling1.Name
    
    nCGroup8 = zLevelMilling1.GetParent(NXOpen.CAM.CAMSetup.View.ProgramOrder)
    
    name10 = nCGroup8.Name
    
    zLevelMilling1.Print()
    
    cAMSetup13 = workPart.CAMSetup
    
    planarMilling1 = cAMSetup13.CAMOperationCollection.FindObject("FINISH_PROFILE_PLANAR")
    isgroup7 = cAMSetup13.IsGroup(planarMilling1)
    
    cAMSetup14 = workPart.CAMSetup
    
    isoperation5 = cAMSetup14.IsOperation(planarMilling1)
    
    name11 = planarMilling1.Name
    
    nCGroup9 = planarMilling1.GetParent(NXOpen.CAM.CAMSetup.View.ProgramOrder)
    
    name12 = nCGroup9.Name
    
    planarMilling1.Print()
    
    cAMSetup15 = workPart.CAMSetup
    
    surfaceContour3 = cAMSetup15.CAMOperationCollection.FindObject("FINISH_SURFACE-01")
    isgroup8 = cAMSetup15.IsGroup(surfaceContour3)
    
    cAMSetup16 = workPart.CAMSetup
    
    isoperation6 = cAMSetup16.IsOperation(surfaceContour3)
    
    name13 = surfaceContour3.Name
    
    nCGroup10 = surfaceContour3.GetParent(NXOpen.CAM.CAMSetup.View.ProgramOrder)
    
    name14 = nCGroup10.Name
    
    surfaceContour3.Print()
    
    cAMSetup17 = workPart.CAMSetup
    
    nCGroup11 = cAMSetup17.CAMGroupCollection.FindObject("SCRIBES")
    isgroup9 = cAMSetup17.IsGroup(nCGroup11)
    
    name15 = nCGroup11.Name
    
    cAMSetup18 = workPart.CAMSetup
    
    operation3 = cAMSetup18.CAMOperationCollection.FindObject(name2)
    
    nCGroup12 = operation3
    members3 = nCGroup12.GetMembers()
    
    cAMSetup19 = workPart.CAMSetup
    
    nCGroup13 = cAMSetup19.CAMGroupCollection.FindObject("FOOTPRINT")
    isgroup10 = cAMSetup19.IsGroup(nCGroup13)
    
    name16 = nCGroup13.Name
    
    cAMSetup20 = workPart.CAMSetup
    
    nCGroup14 = cAMSetup20.CAMGroupCollection.FindObject("ROUGHING")
    isgroup11 = cAMSetup20.IsGroup(nCGroup14)
    
    name17 = nCGroup14.Name
    
    cAMSetup21 = workPart.CAMSetup
    
    nCGroup15 = cAMSetup21.CAMGroupCollection.FindObject("SEMI_FINISH")
    isgroup12 = cAMSetup21.IsGroup(nCGroup15)
    
    name18 = nCGroup15.Name
    
    cAMSetup22 = workPart.CAMSetup
    
    nCGroup16 = cAMSetup22.CAMGroupCollection.FindObject("FINISH")
    isgroup13 = cAMSetup22.IsGroup(nCGroup16)
    
    name19 = nCGroup16.Name
    
    cAMSetup23 = workPart.CAMSetup
    
    nCGroup17 = cAMSetup23.CAMGroupCollection.FindObject("PICKING")
    isgroup14 = cAMSetup23.IsGroup(nCGroup17)
    
    name20 = nCGroup17.Name
    
    cAMSetup24 = workPart.CAMSetup
    
    nCGroup18 = cAMSetup24.CAMGroupCollection.FindObject("DRILLING")
    isgroup15 = cAMSetup24.IsGroup(nCGroup18)
    
    name21 = nCGroup18.Name
    
    cAMSetup25 = workPart.CAMSetup
    
    operation4 = cAMSetup25.CAMOperationCollection.FindObject(name15)
    
    nCGroup19 = operation4
    members4 = nCGroup19.GetMembers()
    
    cAMSetup26 = workPart.CAMSetup
    
    surfaceContour4 = members4[0]
    isgroup16 = cAMSetup26.IsGroup(surfaceContour4)
    
    cAMSetup27 = workPart.CAMSetup
    
    isoperation7 = cAMSetup27.IsOperation(surfaceContour4)
    
    name22 = surfaceContour4.Name
    
    nCGroup20 = surfaceContour4.GetParent(NXOpen.CAM.CAMSetup.View.ProgramOrder)
    
    name23 = nCGroup20.Name
    
    surfaceContour4.Print()
    
    cAMSetup28 = workPart.CAMSetup
    
    operation5 = cAMSetup28.CAMOperationCollection.FindObject(name16)
    
    nCGroup21 = operation5
    members5 = nCGroup21.GetMembers()
    
    cAMSetup29 = workPart.CAMSetup
    
    planarMilling2 = cAMSetup29.CAMOperationCollection.FindObject("PART_FOOTPRINT")
    isgroup17 = cAMSetup29.IsGroup(planarMilling2)
    
    cAMSetup30 = workPart.CAMSetup
    
    isoperation8 = cAMSetup30.IsOperation(planarMilling2)
    
    name24 = planarMilling2.Name
    
    nCGroup22 = planarMilling2.GetParent(NXOpen.CAM.CAMSetup.View.ProgramOrder)
    
    name25 = nCGroup22.Name
    
    planarMilling2.Print()
    
    cAMSetup31 = workPart.CAMSetup
    
    planarMilling3 = cAMSetup31.CAMOperationCollection.FindObject("BLOCK_FOOTPRINT")
    isgroup18 = cAMSetup31.IsGroup(planarMilling3)
    
    cAMSetup32 = workPart.CAMSetup
    
    isoperation9 = cAMSetup32.IsOperation(planarMilling3)
    
    name26 = planarMilling3.Name
    
    nCGroup23 = planarMilling3.GetParent(NXOpen.CAM.CAMSetup.View.ProgramOrder)
    
    name27 = nCGroup23.Name
    
    planarMilling3.Print()
    
    cAMSetup33 = workPart.CAMSetup
    
    operation6 = cAMSetup33.CAMOperationCollection.FindObject(name17)
    
    nCGroup24 = operation6
    members6 = nCGroup24.GetMembers()
    
    cAMSetup34 = workPart.CAMSetup
    
    cavityMilling1 = cAMSetup34.CAMOperationCollection.FindObject("RUF_ALL")
    isgroup19 = cAMSetup34.IsGroup(cavityMilling1)
    
    cAMSetup35 = workPart.CAMSetup
    
    isoperation10 = cAMSetup35.IsOperation(cavityMilling1)
    
    name28 = cavityMilling1.Name
    
    nCGroup25 = cavityMilling1.GetParent(NXOpen.CAM.CAMSetup.View.ProgramOrder)
    
    name29 = nCGroup25.Name
    
    cavityMilling1.Print()
    
    cAMSetup36 = workPart.CAMSetup
    
    planarMilling4 = cAMSetup36.CAMOperationCollection.FindObject("FACE_TOP")
    isgroup20 = cAMSetup36.IsGroup(planarMilling4)
    
    cAMSetup37 = workPart.CAMSetup
    
    isoperation11 = cAMSetup37.IsOperation(planarMilling4)
    
    name30 = planarMilling4.Name
    
    nCGroup26 = planarMilling4.GetParent(NXOpen.CAM.CAMSetup.View.ProgramOrder)
    
    name31 = nCGroup26.Name
    
    planarMilling4.Print()
    
    cAMSetup38 = workPart.CAMSetup
    
    cavityMilling2 = cAMSetup38.CAMOperationCollection.FindObject("RUF_REMOVE_PILLARS")
    isgroup21 = cAMSetup38.IsGroup(cavityMilling2)
    
    cAMSetup39 = workPart.CAMSetup
    
    isoperation12 = cAMSetup39.IsOperation(cavityMilling2)
    
    name32 = cavityMilling2.Name
    
    nCGroup27 = cavityMilling2.GetParent(NXOpen.CAM.CAMSetup.View.ProgramOrder)
    
    name33 = nCGroup27.Name
    
    cavityMilling2.Print()
    
    cAMSetup40 = workPart.CAMSetup
    
    operation7 = cAMSetup40.CAMOperationCollection.FindObject(name18)
    
    nCGroup28 = operation7
    members7 = nCGroup28.GetMembers()
    
    cAMSetup41 = workPart.CAMSetup
    
    planarMilling5 = cAMSetup41.CAMOperationCollection.FindObject("FIN_SIDES_1")
    isgroup22 = cAMSetup41.IsGroup(planarMilling5)
    
    cAMSetup42 = workPart.CAMSetup
    
    isoperation13 = cAMSetup42.IsOperation(planarMilling5)
    
    name34 = planarMilling5.Name
    
    nCGroup29 = planarMilling5.GetParent(NXOpen.CAM.CAMSetup.View.ProgramOrder)
    
    name35 = nCGroup29.Name
    
    planarMilling5.Print()
    
    cAMSetup43 = workPart.CAMSetup
    
    planarMilling6 = cAMSetup43.CAMOperationCollection.FindObject("FIN_SIDES_2")
    isgroup23 = cAMSetup43.IsGroup(planarMilling6)
    
    cAMSetup44 = workPart.CAMSetup
    
    isoperation14 = cAMSetup44.IsOperation(planarMilling6)
    
    name36 = planarMilling6.Name
    
    nCGroup30 = planarMilling6.GetParent(NXOpen.CAM.CAMSetup.View.ProgramOrder)
    
    name37 = nCGroup30.Name
    
    planarMilling6.Print()
    
    cAMSetup45 = workPart.CAMSetup
    
    planarMilling7 = cAMSetup45.CAMOperationCollection.FindObject("FIN_SIDES_3")
    isgroup24 = cAMSetup45.IsGroup(planarMilling7)
    
    cAMSetup46 = workPart.CAMSetup
    
    isoperation15 = cAMSetup46.IsOperation(planarMilling7)
    
    name38 = planarMilling7.Name
    
    nCGroup31 = planarMilling7.GetParent(NXOpen.CAM.CAMSetup.View.ProgramOrder)
    
    name39 = nCGroup31.Name
    
    planarMilling7.Print()
    
    cAMSetup47 = workPart.CAMSetup
    
    planarMilling8 = cAMSetup47.CAMOperationCollection.FindObject("FIN_SIDES_4")
    isgroup25 = cAMSetup47.IsGroup(planarMilling8)
    
    cAMSetup48 = workPart.CAMSetup
    
    isoperation16 = cAMSetup48.IsOperation(planarMilling8)
    
    name40 = planarMilling8.Name
    
    nCGroup32 = planarMilling8.GetParent(NXOpen.CAM.CAMSetup.View.ProgramOrder)
    
    name41 = nCGroup32.Name
    
    planarMilling8.Print()
    
    cAMSetup49 = workPart.CAMSetup
    
    planarMilling9 = cAMSetup49.CAMOperationCollection.FindObject("FIN_SIDES_5")
    isgroup26 = cAMSetup49.IsGroup(planarMilling9)
    
    cAMSetup50 = workPart.CAMSetup
    
    isoperation17 = cAMSetup50.IsOperation(planarMilling9)
    
    name42 = planarMilling9.Name
    
    nCGroup33 = planarMilling9.GetParent(NXOpen.CAM.CAMSetup.View.ProgramOrder)
    
    name43 = nCGroup33.Name
    
    planarMilling9.Print()
    
    cAMSetup51 = workPart.CAMSetup
    
    planarMilling10 = cAMSetup51.CAMOperationCollection.FindObject("FIN_SIDES_6")
    isgroup27 = cAMSetup51.IsGroup(planarMilling10)
    
    cAMSetup52 = workPart.CAMSetup
    
    isoperation18 = cAMSetup52.IsOperation(planarMilling10)
    
    name44 = planarMilling10.Name
    
    nCGroup34 = planarMilling10.GetParent(NXOpen.CAM.CAMSetup.View.ProgramOrder)
    
    name45 = nCGroup34.Name
    
    planarMilling10.Print()
    
    cAMSetup53 = workPart.CAMSetup
    
    surfaceContour5 = cAMSetup53.CAMOperationCollection.FindObject("S_FIN_TOP")
    isgroup28 = cAMSetup53.IsGroup(surfaceContour5)
    
    cAMSetup54 = workPart.CAMSetup
    
    isoperation19 = cAMSetup54.IsOperation(surfaceContour5)
    
    name46 = surfaceContour5.Name
    
    nCGroup35 = surfaceContour5.GetParent(NXOpen.CAM.CAMSetup.View.ProgramOrder)
    
    name47 = nCGroup35.Name
    
    surfaceContour5.Print()
    
    cAMSetup55 = workPart.CAMSetup
    
    surfaceContour6 = cAMSetup55.CAMOperationCollection.FindObject("S_FIN_SIDE_1")
    isgroup29 = cAMSetup55.IsGroup(surfaceContour6)
    
    cAMSetup56 = workPart.CAMSetup
    
    isoperation20 = cAMSetup56.IsOperation(surfaceContour6)
    
    name48 = surfaceContour6.Name
    
    nCGroup36 = surfaceContour6.GetParent(NXOpen.CAM.CAMSetup.View.ProgramOrder)
    
    name49 = nCGroup36.Name
    
    surfaceContour6.Print()
    
    cAMSetup57 = workPart.CAMSetup
    
    surfaceContour7 = cAMSetup57.CAMOperationCollection.FindObject("S_FIN_SIDE_2")
    isgroup30 = cAMSetup57.IsGroup(surfaceContour7)
    
    cAMSetup58 = workPart.CAMSetup
    
    isoperation21 = cAMSetup58.IsOperation(surfaceContour7)
    
    name50 = surfaceContour7.Name
    
    nCGroup37 = surfaceContour7.GetParent(NXOpen.CAM.CAMSetup.View.ProgramOrder)
    
    name51 = nCGroup37.Name
    
    surfaceContour7.Print()
    
    cAMSetup59 = workPart.CAMSetup
    
    operation8 = cAMSetup59.CAMOperationCollection.FindObject(name19)
    
    nCGroup38 = operation8
    members8 = nCGroup38.GetMembers()
    
    cAMSetup60 = workPart.CAMSetup
    
    surfaceContour8 = cAMSetup60.CAMOperationCollection.FindObject("FIN_TOP")
    isgroup31 = cAMSetup60.IsGroup(surfaceContour8)
    
    cAMSetup61 = workPart.CAMSetup
    
    isoperation22 = cAMSetup61.IsOperation(surfaceContour8)
    
    name52 = surfaceContour8.Name
    
    nCGroup39 = surfaceContour8.GetParent(NXOpen.CAM.CAMSetup.View.ProgramOrder)
    
    name53 = nCGroup39.Name
    
    surfaceContour8.Print()
    
    cAMSetup62 = workPart.CAMSetup
    
    surfaceContour9 = cAMSetup62.CAMOperationCollection.FindObject("FIN_SIDE_1")
    isgroup32 = cAMSetup62.IsGroup(surfaceContour9)
    
    cAMSetup63 = workPart.CAMSetup
    
    isoperation23 = cAMSetup63.IsOperation(surfaceContour9)
    
    name54 = surfaceContour9.Name
    
    nCGroup40 = surfaceContour9.GetParent(NXOpen.CAM.CAMSetup.View.ProgramOrder)
    
    name55 = nCGroup40.Name
    
    surfaceContour9.Print()
    
    cAMSetup64 = workPart.CAMSetup
    
    surfaceContour10 = cAMSetup64.CAMOperationCollection.FindObject("FIN_SIDE_2")
    isgroup33 = cAMSetup64.IsGroup(surfaceContour10)
    
    cAMSetup65 = workPart.CAMSetup
    
    isoperation24 = cAMSetup65.IsOperation(surfaceContour10)
    
    name56 = surfaceContour10.Name
    
    nCGroup41 = surfaceContour10.GetParent(NXOpen.CAM.CAMSetup.View.ProgramOrder)
    
    name57 = nCGroup41.Name
    
    surfaceContour10.Print()
    
    cAMSetup66 = workPart.CAMSetup
    
    operation9 = cAMSetup66.CAMOperationCollection.FindObject(name20)
    
    nCGroup42 = operation9
    members9 = nCGroup42.GetMembers()
    
    cAMSetup67 = workPart.CAMSetup
    
    surfaceContour11 = cAMSetup67.CAMOperationCollection.FindObject("PICK-6MM_TOP")
    isgroup34 = cAMSetup67.IsGroup(surfaceContour11)
    
    cAMSetup68 = workPart.CAMSetup
    
    isoperation25 = cAMSetup68.IsOperation(surfaceContour11)
    
    name58 = surfaceContour11.Name
    
    nCGroup43 = surfaceContour11.GetParent(NXOpen.CAM.CAMSetup.View.ProgramOrder)
    
    name59 = nCGroup43.Name
    
    surfaceContour11.Print()
    
    cAMSetup69 = workPart.CAMSetup
    
    surfaceContour12 = cAMSetup69.CAMOperationCollection.FindObject("PICK-6MM_01")
    isgroup35 = cAMSetup69.IsGroup(surfaceContour12)
    
    cAMSetup70 = workPart.CAMSetup
    
    isoperation26 = cAMSetup70.IsOperation(surfaceContour12)
    
    name60 = surfaceContour12.Name
    
    nCGroup44 = surfaceContour12.GetParent(NXOpen.CAM.CAMSetup.View.ProgramOrder)
    
    name61 = nCGroup44.Name
    
    surfaceContour12.Print()
    
    cAMSetup71 = workPart.CAMSetup
    
    surfaceContour13 = cAMSetup71.CAMOperationCollection.FindObject("PICK-6MM_02")
    isgroup36 = cAMSetup71.IsGroup(surfaceContour13)
    
    cAMSetup72 = workPart.CAMSetup
    
    isoperation27 = cAMSetup72.IsOperation(surfaceContour13)
    
    name62 = surfaceContour13.Name
    
    nCGroup45 = surfaceContour13.GetParent(NXOpen.CAM.CAMSetup.View.ProgramOrder)
    
    name63 = nCGroup45.Name
    
    surfaceContour13.Print()
    
    cAMSetup73 = workPart.CAMSetup
    
    surfaceContour14 = cAMSetup73.CAMOperationCollection.FindObject("PICK-3MM_TOP")
    isgroup37 = cAMSetup73.IsGroup(surfaceContour14)
    
    cAMSetup74 = workPart.CAMSetup
    
    isoperation28 = cAMSetup74.IsOperation(surfaceContour14)
    
    name64 = surfaceContour14.Name
    
    nCGroup46 = surfaceContour14.GetParent(NXOpen.CAM.CAMSetup.View.ProgramOrder)
    
    name65 = nCGroup46.Name
    
    surfaceContour14.Print()
    
    cAMSetup75 = workPart.CAMSetup
    
    surfaceContour15 = cAMSetup75.CAMOperationCollection.FindObject("PICK-3MM_01")
    isgroup38 = cAMSetup75.IsGroup(surfaceContour15)
    
    cAMSetup76 = workPart.CAMSetup
    
    isoperation29 = cAMSetup76.IsOperation(surfaceContour15)
    
    name66 = surfaceContour15.Name
    
    nCGroup47 = surfaceContour15.GetParent(NXOpen.CAM.CAMSetup.View.ProgramOrder)
    
    name67 = nCGroup47.Name
    
    surfaceContour15.Print()
    
    cAMSetup77 = workPart.CAMSetup
    
    surfaceContour16 = cAMSetup77.CAMOperationCollection.FindObject("PICK-3MM_02")
    isgroup39 = cAMSetup77.IsGroup(surfaceContour16)
    
    cAMSetup78 = workPart.CAMSetup
    
    isoperation30 = cAMSetup78.IsOperation(surfaceContour16)
    
    name68 = surfaceContour16.Name
    
    nCGroup48 = surfaceContour16.GetParent(NXOpen.CAM.CAMSetup.View.ProgramOrder)
    
    name69 = nCGroup48.Name
    
    surfaceContour16.Print()
    
    cAMSetup79 = workPart.CAMSetup
    
    surfaceContour17 = cAMSetup79.CAMOperationCollection.FindObject("PICK-2MM_TOP")
    isgroup40 = cAMSetup79.IsGroup(surfaceContour17)
    
    cAMSetup80 = workPart.CAMSetup
    
    isoperation31 = cAMSetup80.IsOperation(surfaceContour17)
    
    name70 = surfaceContour17.Name
    
    nCGroup49 = surfaceContour17.GetParent(NXOpen.CAM.CAMSetup.View.ProgramOrder)
    
    name71 = nCGroup49.Name
    
    surfaceContour17.Print()
    
    cAMSetup81 = workPart.CAMSetup
    
    surfaceContour18 = cAMSetup81.CAMOperationCollection.FindObject("PICK-2MM_01")
    isgroup41 = cAMSetup81.IsGroup(surfaceContour18)
    
    cAMSetup82 = workPart.CAMSetup
    
    isoperation32 = cAMSetup82.IsOperation(surfaceContour18)
    
    name72 = surfaceContour18.Name
    
    nCGroup50 = surfaceContour18.GetParent(NXOpen.CAM.CAMSetup.View.ProgramOrder)
    
    name73 = nCGroup50.Name
    
    surfaceContour18.Print()
    
    cAMSetup83 = workPart.CAMSetup
    
    surfaceContour19 = cAMSetup83.CAMOperationCollection.FindObject("PICK-2MM_02")
    isgroup42 = cAMSetup83.IsGroup(surfaceContour19)
    
    cAMSetup84 = workPart.CAMSetup
    
    isoperation33 = cAMSetup84.IsOperation(surfaceContour19)
    
    name74 = surfaceContour19.Name
    
    nCGroup51 = surfaceContour19.GetParent(NXOpen.CAM.CAMSetup.View.ProgramOrder)
    
    name75 = nCGroup51.Name
    
    surfaceContour19.Print()
    
    cAMSetup85 = workPart.CAMSetup
    
    surfaceContour20 = cAMSetup85.CAMOperationCollection.FindObject("PICK-1MM_TOP")
    isgroup43 = cAMSetup85.IsGroup(surfaceContour20)
    
    cAMSetup86 = workPart.CAMSetup
    
    isoperation34 = cAMSetup86.IsOperation(surfaceContour20)
    
    name76 = surfaceContour20.Name
    
    nCGroup52 = surfaceContour20.GetParent(NXOpen.CAM.CAMSetup.View.ProgramOrder)
    
    name77 = nCGroup52.Name
    
    surfaceContour20.Print()
    
    cAMSetup87 = workPart.CAMSetup
    
    surfaceContour21 = cAMSetup87.CAMOperationCollection.FindObject("PICK-1MM_01")
    isgroup44 = cAMSetup87.IsGroup(surfaceContour21)
    
    cAMSetup88 = workPart.CAMSetup
    
    isoperation35 = cAMSetup88.IsOperation(surfaceContour21)
    
    name78 = surfaceContour21.Name
    
    nCGroup53 = surfaceContour21.GetParent(NXOpen.CAM.CAMSetup.View.ProgramOrder)
    
    name79 = nCGroup53.Name
    
    surfaceContour21.Print()
    
    cAMSetup89 = workPart.CAMSetup
    
    surfaceContour22 = cAMSetup89.CAMOperationCollection.FindObject("PICK-1MM_02")
    isgroup45 = cAMSetup89.IsGroup(surfaceContour22)
    
    cAMSetup90 = workPart.CAMSetup
    
    isoperation36 = cAMSetup90.IsOperation(surfaceContour22)
    
    name80 = surfaceContour22.Name
    
    nCGroup54 = surfaceContour22.GetParent(NXOpen.CAM.CAMSetup.View.ProgramOrder)
    
    name81 = nCGroup54.Name
    
    surfaceContour22.Print()
    
    cAMSetup91 = workPart.CAMSetup
    
    operation10 = cAMSetup91.CAMOperationCollection.FindObject(name21)
    
    nCGroup55 = operation10
    members10 = nCGroup55.GetMembers()
    
    cAMSetup92 = workPart.CAMSetup
    
    holeDrilling2 = cAMSetup92.CAMOperationCollection.FindObject("CENTRE_DRILLING")
    isgroup46 = cAMSetup92.IsGroup(holeDrilling2)
    
    cAMSetup93 = workPart.CAMSetup
    
    isoperation37 = cAMSetup93.IsOperation(holeDrilling2)
    
    name82 = holeDrilling2.Name
    
    nCGroup56 = holeDrilling2.GetParent(NXOpen.CAM.CAMSetup.View.ProgramOrder)
    
    name83 = nCGroup56.Name
    
    holeDrilling2.Print()
    
    cAMSetup94 = workPart.CAMSetup
    
    isgroup47 = cAMSetup94.IsGroup(holeDrilling1)
    
    cAMSetup95 = workPart.CAMSetup
    
    isoperation38 = cAMSetup95.IsOperation(holeDrilling1)
    
    name84 = holeDrilling1.Name
    
    nCGroup57 = holeDrilling1.GetParent(NXOpen.CAM.CAMSetup.View.ProgramOrder)
    
    name85 = nCGroup57.Name
    
    holeDrilling1.Print()
    
    part4 = theSession.Parts.Work
    
    part5 = theSession.Parts.Display
    
    cAMSetup96 = workPart.CAMSetup
    
    operation11 = cAMSetup96.CAMOperationCollection.FindObject(name84)
    
    cAMSetup97 = workPart.CAMSetup
    
    objects2 = [NXOpen.CAM.CAMObject.Null] * 1 
    holeDrilling3 = operation11
    objects2[0] = holeDrilling3
    cAMSetup97.DeleteWorkInstructions(objects2)
    
    cAMSetup98 = workPart.CAMSetup
    
    operation12 = cAMSetup98.CAMOperationCollection.FindObject(name84)
    
    cAMSetup99 = workPart.CAMSetup
    
    holeDrilling4 = operation12
    objectWorkInstructionBuilder1 = cAMSetup99.CreateObjectWorkInstructionBuilder(holeDrilling4)
    
    markId4 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    theSession.SetUndoMarkName(markId4, "Author Work Instructions Dialog")
    
    workInstructionBuilder1 = objectWorkInstructionBuilder1.Work
    
    workInstructionBuilder1.SheetNumber = 1
    
    workInstructionBuilder2 = objectWorkInstructionBuilder1.Work
    
    sheettitle1 = workInstructionBuilder2.SheetTitle
    
    workInstructionBuilder3 = objectWorkInstructionBuilder1.Work
    
    workInstructionBuilder3.SheetTitle = "- Sheet 1"
    
    workInstructionBuilder4 = objectWorkInstructionBuilder1.Work
    
    sheetnum1 = workInstructionBuilder4.AddSheet()
    
    workInstructionBuilder5 = objectWorkInstructionBuilder1.Work
    
    sheettitle2 = workInstructionBuilder5.SheetTitle
    
    workInstructionBuilder6 = objectWorkInstructionBuilder1.Work
    
    workInstructionBuilder6.TemplateName = "Job Information Sheet [Trial 1]"
    
    workInstructionBuilder7 = objectWorkInstructionBuilder1.Work
    
    workInstructionBuilder7.CommitMaster()
    
    workInstructionBuilder8 = objectWorkInstructionBuilder1.Work
    
    itemnames1 = [None] * 11 
    itemnames1[0] = "OWI_TEXT_1"
    itemnames1[1] = "OWI_TEXT_4"
    itemnames1[2] = "OWI_TEXT_5"
    itemnames1[3] = "OWI_TEXT_6"
    itemnames1[4] = "OWI_TEXT_3"
    itemnames1[5] = "OWI_TEXT_2"
    itemnames1[6] = "OWI_PROD_VIEW_1"
    itemnames1[7] = "OWI_TEXT_7"
    itemnames1[8] = "OWI_TEXT_8"
    itemnames1[9] = "OWI_TEXT_9"
    itemnames1[10] = "OWI_TEXT_10"
    workInstructionBuilder8.UpdateItemsInCurrentSheet(itemnames1)
    
    layout2 = workPart.Layouts.FindObject("L1")
    
    camera3 = workPart.Cameras.FindObject("NXOWI_CACHE_CURRENT_VIEW")
    
    modelingView1 = workPart.ModelingViews.WorkView
    
    cameraBuilder2 = workPart.Cameras.CreateCameraBuilder(modelingView1, layout2, camera3)
    
    nXObject2 = cameraBuilder2.Commit()
    
    cameraBuilder2.Destroy()
    
    workInstructionBuilder9 = objectWorkInstructionBuilder1.Work
    
    sheetnum2 = workInstructionBuilder9.AddSheet()
    
    workInstructionBuilder10 = objectWorkInstructionBuilder1.Work
    
    sheettitle3 = workInstructionBuilder10.SheetTitle
    
    workInstructionBuilder11 = objectWorkInstructionBuilder1.Work
    
    workInstructionBuilder11.SheetNumber = 2
    
    workInstructionBuilder12 = objectWorkInstructionBuilder1.Work
    
    sheettitle4 = workInstructionBuilder12.SheetTitle
    
    workInstructionBuilder13 = objectWorkInstructionBuilder1.Work
    
    workInstructionBuilder13.SheetTitle = "- Sheet 2"
    
    workInstructionBuilder14 = objectWorkInstructionBuilder1.Work
    
    workInstructionBuilder14.TemplateName = "Tool Sheet [Trial 1]"
    
    workInstructionBuilder15 = objectWorkInstructionBuilder1.Work
    
    workInstructionBuilder15.CommitMaster()
    
    workInstructionBuilder16 = objectWorkInstructionBuilder1.Work
    
    itemnames2 = [None] * 2 
    itemnames2[0] = "OWI_PROD_VIEW_2"
    itemnames2[1] = "OWI_TOOL_LIST_1"
    workInstructionBuilder16.UpdateItemsInCurrentSheet(itemnames2)
    
    modelingView2 = workPart.ModelingViews.WorkView
    
    camera4 = nXObject2
    cameraBuilder3 = workPart.Cameras.CreateCameraBuilder(modelingView2, layout2, camera4)
    
    nXObject3 = cameraBuilder3.Commit()
    
    cameraBuilder3.Destroy()
    
    workInstructionBuilder17 = objectWorkInstructionBuilder1.Work
    
    sheetnum3 = workInstructionBuilder17.AddSheet()
    
    workInstructionBuilder18 = objectWorkInstructionBuilder1.Work
    
    sheettitle5 = workInstructionBuilder18.SheetTitle
    
    workInstructionBuilder19 = objectWorkInstructionBuilder1.Work
    
    workInstructionBuilder19.SheetNumber = 3
    
    workInstructionBuilder20 = objectWorkInstructionBuilder1.Work
    
    sheettitle6 = workInstructionBuilder20.SheetTitle
    
    workInstructionBuilder21 = objectWorkInstructionBuilder1.Work
    
    workInstructionBuilder21.SheetTitle = "- Sheet 3"
    
    workInstructionBuilder22 = objectWorkInstructionBuilder1.Work
    
    workInstructionBuilder22.TemplateName = "Job View [Trial 1]"
    
    workInstructionBuilder23 = objectWorkInstructionBuilder1.Work
    
    workInstructionBuilder23.CommitMaster()
    
    workInstructionBuilder24 = objectWorkInstructionBuilder1.Work
    
    itemnames3 = [None] * 5 
    itemnames3[0] = "OWI_PROD_VIEW_5"
    itemnames3[1] = "OWI_PROD_VIEW_1"
    itemnames3[2] = "OWI_PROD_VIEW_2"
    itemnames3[3] = "OWI_PROD_VIEW_3"
    itemnames3[4] = "OWI_IMAGE_1"
    workInstructionBuilder24.UpdateItemsInCurrentSheet(itemnames3)
    
    modelingView3 = workPart.ModelingViews.WorkView
    
    camera5 = nXObject3
    cameraBuilder4 = workPart.Cameras.CreateCameraBuilder(modelingView3, layout2, camera5)
    
    nXObject4 = cameraBuilder4.Commit()
    
    cameraBuilder4.Destroy()
    
    workInstructionBuilder25 = objectWorkInstructionBuilder1.Work
    
    sheetnum4 = workInstructionBuilder25.AddSheet()
    
    workInstructionBuilder26 = objectWorkInstructionBuilder1.Work
    
    sheettitle7 = workInstructionBuilder26.SheetTitle
    
    workInstructionBuilder27 = objectWorkInstructionBuilder1.Work
    
    workInstructionBuilder27.SheetNumber = 4
    
    workInstructionBuilder28 = objectWorkInstructionBuilder1.Work
    
    sheettitle8 = workInstructionBuilder28.SheetTitle
    
    workInstructionBuilder29 = objectWorkInstructionBuilder1.Work
    
    workInstructionBuilder29.SheetTitle = "- Sheet 4"
    
    workInstructionBuilder30 = objectWorkInstructionBuilder1.Work
    
    workInstructionBuilder30.TemplateName = "Tool Path Summary [Trial 1]"
    
    workInstructionBuilder31 = objectWorkInstructionBuilder1.Work
    
    workInstructionBuilder31.CommitMaster()
    
    workInstructionBuilder32 = objectWorkInstructionBuilder1.Work
    
    itemnames4 = [None] * 2 
    itemnames4[0] = "OWI_PROD_VIEW_2"
    itemnames4[1] = "OWI_OPER_LIST_1"
    workInstructionBuilder32.UpdateItemsInCurrentSheet(itemnames4)
    
    modelingView4 = workPart.ModelingViews.WorkView
    
    camera6 = nXObject4
    cameraBuilder5 = workPart.Cameras.CreateCameraBuilder(modelingView4, layout2, camera6)
    
    nXObject5 = cameraBuilder5.Commit()
    
    cameraBuilder5.Destroy()
    
    workInstructionBuilder33 = objectWorkInstructionBuilder1.Work
    
    workInstructionBuilder33.SheetNumber = 1
    
    workInstructionBuilder34 = objectWorkInstructionBuilder1.Work
    
    itemnames5 = [None] * 11 
    itemnames5[0] = "OWI_TEXT_1"
    itemnames5[1] = "OWI_TEXT_4"
    itemnames5[2] = "OWI_TEXT_5"
    itemnames5[3] = "OWI_TEXT_6"
    itemnames5[4] = "OWI_TEXT_3"
    itemnames5[5] = "OWI_TEXT_2"
    itemnames5[6] = "OWI_PROD_VIEW_1"
    itemnames5[7] = "OWI_TEXT_7"
    itemnames5[8] = "OWI_TEXT_8"
    itemnames5[9] = "OWI_TEXT_9"
    itemnames5[10] = "OWI_TEXT_10"
    workInstructionBuilder34.UpdateItemsInCurrentSheet(itemnames5)
    
    modelingView5 = workPart.ModelingViews.WorkView
    
    camera7 = nXObject5
    cameraBuilder6 = workPart.Cameras.CreateCameraBuilder(modelingView5, layout2, camera7)
    
    nXObject6 = cameraBuilder6.Commit()
    
    cameraBuilder6.Destroy()
    
    workInstructionBuilder35 = objectWorkInstructionBuilder1.Work
    
    sheettitle9 = workInstructionBuilder35.SheetTitle
    
    workInstructionBuilder36 = objectWorkInstructionBuilder1.Work
    
    workInstructionBuilder36.SheetTitle = sheettitle2
    
    workInstructionBuilder37 = objectWorkInstructionBuilder1.Work
    
    workInstructionBuilder37.ItemName = "OWI_TEXT_1"
    
    workInstructionBuilder38 = objectWorkInstructionBuilder1.Work
    
    multilinetext1 = []
    workInstructionBuilder38.SetRichText(multilinetext1)
    
    workInstructionBuilder39 = objectWorkInstructionBuilder1.Work
    
    sheettitle10 = workInstructionBuilder39.SheetTitle
    
    workInstructionBuilder40 = objectWorkInstructionBuilder1.Work
    
    multilinetext2 = [None] * 1 
    multilinetext2[0] = ""
    workInstructionBuilder40.SetRichText(multilinetext2)
    
    workInstructionBuilder41 = objectWorkInstructionBuilder1.Work
    
    workInstructionBuilder41.CommitItem()
    
    workInstructionBuilder42 = objectWorkInstructionBuilder1.Work
    
    workInstructionBuilder42.ItemName = "OWI_TEXT_4"
    
    workInstructionBuilder43 = objectWorkInstructionBuilder1.Work
    
    multilinetext3 = []
    workInstructionBuilder43.SetRichText(multilinetext3)
    
    modelingView6 = workPart.ModelingViews.WorkView
    
    camera8 = nXObject6
    cameraBuilder7 = workPart.Cameras.CreateCameraBuilder(modelingView6, layout2, camera8)
    
    nXObject7 = cameraBuilder7.Commit()
    
    cameraBuilder7.Destroy()
    
    workInstructionBuilder44 = objectWorkInstructionBuilder1.Work
    
    sheettitle11 = workInstructionBuilder44.SheetTitle
    
    workInstructionBuilder45 = objectWorkInstructionBuilder1.Work
    
    multilinetext4 = [None] * 1 
    multilinetext4[0] = ""
    workInstructionBuilder45.SetRichText(multilinetext4)
    
    workInstructionBuilder46 = objectWorkInstructionBuilder1.Work
    
    workInstructionBuilder46.CommitItem()
    
    workInstructionBuilder47 = objectWorkInstructionBuilder1.Work
    
    workInstructionBuilder47.ItemName = "OWI_TEXT_5"
    
    workInstructionBuilder48 = objectWorkInstructionBuilder1.Work
    
    multilinetext5 = []
    workInstructionBuilder48.SetRichText(multilinetext5)
    
    modelingView7 = workPart.ModelingViews.WorkView
    
    camera9 = nXObject7
    cameraBuilder8 = workPart.Cameras.CreateCameraBuilder(modelingView7, layout2, camera9)
    
    nXObject8 = cameraBuilder8.Commit()
    
    cameraBuilder8.Destroy()
    
    workInstructionBuilder49 = objectWorkInstructionBuilder1.Work
    
    sheettitle12 = workInstructionBuilder49.SheetTitle
    
    workInstructionBuilder50 = objectWorkInstructionBuilder1.Work
    
    multilinetext6 = [None] * 1 
    multilinetext6[0] = ""
    workInstructionBuilder50.SetRichText(multilinetext6)
    
    workInstructionBuilder51 = objectWorkInstructionBuilder1.Work
    
    workInstructionBuilder51.CommitItem()
    
    workInstructionBuilder52 = objectWorkInstructionBuilder1.Work
    
    workInstructionBuilder52.ItemName = "OWI_TEXT_6"
    
    workInstructionBuilder53 = objectWorkInstructionBuilder1.Work
    
    multilinetext7 = []
    workInstructionBuilder53.SetRichText(multilinetext7)
    
    modelingView8 = workPart.ModelingViews.WorkView
    
    camera10 = nXObject8
    cameraBuilder9 = workPart.Cameras.CreateCameraBuilder(modelingView8, layout2, camera10)
    
    nXObject9 = cameraBuilder9.Commit()
    
    cameraBuilder9.Destroy()
    
    workInstructionBuilder54 = objectWorkInstructionBuilder1.Work
    
    sheettitle13 = workInstructionBuilder54.SheetTitle
    
    workInstructionBuilder55 = objectWorkInstructionBuilder1.Work
    
    multilinetext8 = [None] * 1 
    multilinetext8[0] = ""
    workInstructionBuilder55.SetRichText(multilinetext8)
    
    workInstructionBuilder56 = objectWorkInstructionBuilder1.Work
    
    workInstructionBuilder56.CommitItem()
    
    workInstructionBuilder57 = objectWorkInstructionBuilder1.Work
    
    workInstructionBuilder57.ItemName = "OWI_TEXT_3"
    
    workInstructionBuilder58 = objectWorkInstructionBuilder1.Work
    
    multilinetext9 = []
    workInstructionBuilder58.SetRichText(multilinetext9)
    
    modelingView9 = workPart.ModelingViews.WorkView
    
    camera11 = nXObject9
    cameraBuilder10 = workPart.Cameras.CreateCameraBuilder(modelingView9, layout2, camera11)
    
    nXObject10 = cameraBuilder10.Commit()
    
    cameraBuilder10.Destroy()
    
    workInstructionBuilder59 = objectWorkInstructionBuilder1.Work
    
    sheettitle14 = workInstructionBuilder59.SheetTitle
    
    workInstructionBuilder60 = objectWorkInstructionBuilder1.Work
    
    multilinetext10 = [None] * 1 
    multilinetext10[0] = ""
    workInstructionBuilder60.SetRichText(multilinetext10)
    
    workInstructionBuilder61 = objectWorkInstructionBuilder1.Work
    
    workInstructionBuilder61.CommitItem()
    
    workInstructionBuilder62 = objectWorkInstructionBuilder1.Work
    
    workInstructionBuilder62.ItemName = "OWI_TEXT_2"
    
    workInstructionBuilder63 = objectWorkInstructionBuilder1.Work
    
    multilinetext11 = []
    workInstructionBuilder63.SetRichText(multilinetext11)
    
    modelingView10 = workPart.ModelingViews.WorkView
    
    camera12 = nXObject10
    cameraBuilder11 = workPart.Cameras.CreateCameraBuilder(modelingView10, layout2, camera12)
    
    nXObject11 = cameraBuilder11.Commit()
    
    cameraBuilder11.Destroy()
    
    workInstructionBuilder64 = objectWorkInstructionBuilder1.Work
    
    sheettitle15 = workInstructionBuilder64.SheetTitle
    
    workInstructionBuilder65 = objectWorkInstructionBuilder1.Work
    
    multilinetext12 = [None] * 1 
    multilinetext12[0] = ""
    workInstructionBuilder65.SetRichText(multilinetext12)
    
    workInstructionBuilder66 = objectWorkInstructionBuilder1.Work
    
    workInstructionBuilder66.CommitItem()
    
    workInstructionBuilder67 = objectWorkInstructionBuilder1.Work
    
    workInstructionBuilder67.ItemName = "OWI_PROD_VIEW_1"
    
    modelingView11 = workPart.ModelingViews.WorkView
    
    camera13 = nXObject11
    cameraBuilder12 = workPart.Cameras.CreateCameraBuilder(modelingView11, layout2, camera13)
    
    nXObject12 = cameraBuilder12.Commit()
    
    cameraBuilder12.Destroy()
    
    modelingView12 = workPart.ModelingViews.WorkView
    
    camera14 = nXObject12
    cameraBuilder13 = workPart.Cameras.CreateCameraBuilder(modelingView12, layout2, camera14)
    
    nXObject13 = cameraBuilder13.Commit()
    
    cameraBuilder13.Destroy()
    
    workInstructionBuilder68 = objectWorkInstructionBuilder1.Work
    
    sheettitle16 = workInstructionBuilder68.SheetTitle
    
    part6 = theSession.Parts.Display
    
    view1 = workPart.Views.WorkView
    
    modelingView13 = view1
    modelingView13.Fit()
    
    modelingView13.Orient(NXOpen.View.Canned.Isometric, NXOpen.View.ScaleAdjustment.Fit)
    
    workInstructionBuilder69 = objectWorkInstructionBuilder1.Work
    
    multilinetext13 = [None] * 1 
    multilinetext13[0] = ""
    workInstructionBuilder69.SetRichText(multilinetext13)
    
    workInstructionBuilder70 = objectWorkInstructionBuilder1.Work
    
    workInstructionBuilder70.CommitItem()
    
    cameraBuilder14 = workPart.Cameras.CreateCameraBuilder(modelingView13, layout2, NXOpen.Display.Camera.Null)
    
    nXObject14 = cameraBuilder14.Commit()
    
    cameraBuilder14.Destroy()
    
    workInstructionBuilder71 = objectWorkInstructionBuilder1.Work
    
    # Potential journal callback detected. Pausing journal.
    # Journal callback ended. Unpausing
    workInstructionBuilder71.CaptureCurrentView()
    
    workInstructionBuilder72 = objectWorkInstructionBuilder1.Work
    
    workInstructionBuilder72.CameraName = "NXWI$1"
    
    workInstructionBuilder73 = objectWorkInstructionBuilder1.Work
    
    workInstructionBuilder73.CommitItem()
    
    camera15 = nXObject13
    cameraBuilder15 = workPart.Cameras.CreateCameraBuilder(modelingView13, layout2, camera15)
    
    nXObject15 = cameraBuilder15.Commit()
    
    cameraBuilder15.Destroy()
    
    layout2.ReplaceView(modelingView13, modelingView13, False)
    
    workInstructionBuilder74 = objectWorkInstructionBuilder1.Work
    
    workInstructionBuilder74.ItemName = "OWI_TEXT_7"
    
    workInstructionBuilder75 = objectWorkInstructionBuilder1.Work
    
    multilinetext14 = []
    workInstructionBuilder75.SetRichText(multilinetext14)
    
    workInstructionBuilder76 = objectWorkInstructionBuilder1.Work
    
    sheettitle17 = workInstructionBuilder76.SheetTitle
    
    workInstructionBuilder77 = objectWorkInstructionBuilder1.Work
    
    multilinetext15 = [None] * 1 
    multilinetext15[0] = ""
    workInstructionBuilder77.SetRichText(multilinetext15)
    
    workInstructionBuilder78 = objectWorkInstructionBuilder1.Work
    
    workInstructionBuilder78.CommitItem()
    
    workInstructionBuilder79 = objectWorkInstructionBuilder1.Work
    
    workInstructionBuilder79.ItemName = "OWI_TEXT_8"
    
    workInstructionBuilder80 = objectWorkInstructionBuilder1.Work
    
    multilinetext16 = []
    workInstructionBuilder80.SetRichText(multilinetext16)
    
    camera16 = nXObject15
    cameraBuilder16 = workPart.Cameras.CreateCameraBuilder(modelingView13, layout2, camera16)
    
    nXObject16 = cameraBuilder16.Commit()
    
    cameraBuilder16.Destroy()
    
    layout2.ReplaceView(modelingView13, modelingView13, False)
    
    workInstructionBuilder81 = objectWorkInstructionBuilder1.Work
    
    sheettitle18 = workInstructionBuilder81.SheetTitle
    
    workInstructionBuilder82 = objectWorkInstructionBuilder1.Work
    
    multilinetext17 = [None] * 1 
    multilinetext17[0] = ""
    workInstructionBuilder82.SetRichText(multilinetext17)
    
    workInstructionBuilder83 = objectWorkInstructionBuilder1.Work
    
    workInstructionBuilder83.CommitItem()
    
    workInstructionBuilder84 = objectWorkInstructionBuilder1.Work
    
    workInstructionBuilder84.ItemName = "OWI_TEXT_9"
    
    workInstructionBuilder85 = objectWorkInstructionBuilder1.Work
    
    multilinetext18 = []
    workInstructionBuilder85.SetRichText(multilinetext18)
    
    camera17 = nXObject16
    cameraBuilder17 = workPart.Cameras.CreateCameraBuilder(modelingView13, layout2, camera17)
    
    nXObject17 = cameraBuilder17.Commit()
    
    cameraBuilder17.Destroy()
    
    layout2.ReplaceView(modelingView13, modelingView13, False)
    
    workInstructionBuilder86 = objectWorkInstructionBuilder1.Work
    
    sheettitle19 = workInstructionBuilder86.SheetTitle
    
    workInstructionBuilder87 = objectWorkInstructionBuilder1.Work
    
    multilinetext19 = [None] * 1 
    multilinetext19[0] = ""
    workInstructionBuilder87.SetRichText(multilinetext19)
    
    workInstructionBuilder88 = objectWorkInstructionBuilder1.Work
    
    workInstructionBuilder88.CommitItem()
    
    workInstructionBuilder89 = objectWorkInstructionBuilder1.Work
    
    workInstructionBuilder89.ItemName = "OWI_TEXT_10"
    
    workInstructionBuilder90 = objectWorkInstructionBuilder1.Work
    
    multilinetext20 = []
    workInstructionBuilder90.SetRichText(multilinetext20)
    
    camera18 = nXObject17
    cameraBuilder18 = workPart.Cameras.CreateCameraBuilder(modelingView13, layout2, camera18)
    
    nXObject18 = cameraBuilder18.Commit()
    
    cameraBuilder18.Destroy()
    
    layout2.ReplaceView(modelingView13, modelingView13, False)
    
    workInstructionBuilder91 = objectWorkInstructionBuilder1.Work
    
    sheettitle20 = workInstructionBuilder91.SheetTitle
    
    workInstructionBuilder92 = objectWorkInstructionBuilder1.Work
    
    multilinetext21 = [None] * 1 
    multilinetext21[0] = " "
    workInstructionBuilder92.SetRichText(multilinetext21)
    
    workInstructionBuilder93 = objectWorkInstructionBuilder1.Work
    
    workInstructionBuilder93.CommitItem()
    
    workInstructionBuilder94 = objectWorkInstructionBuilder1.Work
    
    workInstructionBuilder94.SheetNumber = 2
    
    workInstructionBuilder95 = objectWorkInstructionBuilder1.Work
    
    itemnames6 = [None] * 2 
    itemnames6[0] = "OWI_PROD_VIEW_2"
    itemnames6[1] = "OWI_TOOL_LIST_1"
    workInstructionBuilder95.UpdateItemsInCurrentSheet(itemnames6)
    
    camera19 = nXObject18
    cameraBuilder19 = workPart.Cameras.CreateCameraBuilder(modelingView13, layout2, camera19)
    
    nXObject19 = cameraBuilder19.Commit()
    
    cameraBuilder19.Destroy()
    
    workInstructionBuilder96 = objectWorkInstructionBuilder1.Work
    
    workInstructionBuilder96.ItemName = "OWI_PROD_VIEW_2"
    
    camera20 = nXObject19
    cameraBuilder20 = workPart.Cameras.CreateCameraBuilder(modelingView13, layout2, camera20)
    
    nXObject20 = cameraBuilder20.Commit()
    
    cameraBuilder20.Destroy()
    
    camera21 = nXObject20
    cameraBuilder21 = workPart.Cameras.CreateCameraBuilder(modelingView13, layout2, camera21)
    
    nXObject21 = cameraBuilder21.Commit()
    
    cameraBuilder21.Destroy()
    
    workInstructionBuilder97 = objectWorkInstructionBuilder1.Work
    
    sheettitle21 = workInstructionBuilder97.SheetTitle
    
    workInstructionBuilder98 = objectWorkInstructionBuilder1.Work
    
    workInstructionBuilder98.SheetTitle = sheettitle5
    
    workInstructionBuilder99 = objectWorkInstructionBuilder1.Work
    
    multilinetext22 = [None] * 1 
    multilinetext22[0] = " "
    workInstructionBuilder99.SetRichText(multilinetext22)
    
    workInstructionBuilder100 = objectWorkInstructionBuilder1.Work
    
    workInstructionBuilder100.CommitItem()
    
    cameraBuilder22 = workPart.Cameras.CreateCameraBuilder(modelingView13, layout2, NXOpen.Display.Camera.Null)
    
    nXObject22 = cameraBuilder22.Commit()
    
    cameraBuilder22.Destroy()
    
    workInstructionBuilder101 = objectWorkInstructionBuilder1.Work
    
    # Potential journal callback detected. Pausing journal.
    # Journal callback ended. Unpausing
    workInstructionBuilder101.CaptureCurrentView()
    
    workInstructionBuilder102 = objectWorkInstructionBuilder1.Work
    
    workInstructionBuilder102.CameraName = "NXWI$2"
    
    workInstructionBuilder103 = objectWorkInstructionBuilder1.Work
    
    workInstructionBuilder103.CommitItem()
    
    camera22 = nXObject21
    cameraBuilder23 = workPart.Cameras.CreateCameraBuilder(modelingView13, layout2, camera22)
    
    nXObject23 = cameraBuilder23.Commit()
    
    cameraBuilder23.Destroy()
    
    layout2.ReplaceView(modelingView13, modelingView13, False)
    
    workInstructionBuilder104 = objectWorkInstructionBuilder1.Work
    
    workInstructionBuilder104.ItemName = "OWI_TOOL_LIST_1"
    
    workInstructionBuilder105 = objectWorkInstructionBuilder1.Work
    
    sheettitle22 = workInstructionBuilder105.SheetTitle
    
    workInstructionBuilder106 = objectWorkInstructionBuilder1.Work
    
    workInstructionBuilder106.ToolListProgramGroup = sheettitle1
    
    workInstructionBuilder107 = objectWorkInstructionBuilder1.Work
    
    workInstructionBuilder107.ToolListProgramGroup = sheettitle1
    
    workInstructionBuilder108 = objectWorkInstructionBuilder1.Work
    
    workInstructionBuilder108.CommitItem()
    
    camera23 = nXObject23
    cameraBuilder24 = workPart.Cameras.CreateCameraBuilder(modelingView13, layout2, camera23)
    
    nXObject24 = cameraBuilder24.Commit()
    
    cameraBuilder24.Destroy()
    
    layout2.ReplaceView(modelingView13, modelingView13, False)
    
    workInstructionBuilder109 = objectWorkInstructionBuilder1.Work
    
    workInstructionBuilder109.SheetNumber = 3
    
    workInstructionBuilder110 = objectWorkInstructionBuilder1.Work
    
    itemnames7 = [None] * 5 
    itemnames7[0] = "OWI_PROD_VIEW_5"
    itemnames7[1] = "OWI_PROD_VIEW_1"
    itemnames7[2] = "OWI_PROD_VIEW_2"
    itemnames7[3] = "OWI_PROD_VIEW_3"
    itemnames7[4] = "OWI_IMAGE_1"
    workInstructionBuilder110.UpdateItemsInCurrentSheet(itemnames7)
    
    camera24 = nXObject24
    cameraBuilder25 = workPart.Cameras.CreateCameraBuilder(modelingView13, layout2, camera24)
    
    nXObject25 = cameraBuilder25.Commit()
    
    cameraBuilder25.Destroy()
    
    workInstructionBuilder111 = objectWorkInstructionBuilder1.Work
    
    workInstructionBuilder111.ItemName = "OWI_PROD_VIEW_5"
    
    camera25 = nXObject25
    cameraBuilder26 = workPart.Cameras.CreateCameraBuilder(modelingView13, layout2, camera25)
    
    nXObject26 = cameraBuilder26.Commit()
    
    cameraBuilder26.Destroy()
    
    workInstructionBuilder112 = objectWorkInstructionBuilder1.Work
    
    sheettitle23 = workInstructionBuilder112.SheetTitle
    
    workInstructionBuilder113 = objectWorkInstructionBuilder1.Work
    
    workInstructionBuilder113.SheetTitle = sheettitle7
    
    cameraBuilder27 = workPart.Cameras.CreateCameraBuilder(modelingView13, layout2, NXOpen.Display.Camera.Null)
    
    nXObject27 = cameraBuilder27.Commit()
    
    cameraBuilder27.Destroy()
    
    workInstructionBuilder114 = objectWorkInstructionBuilder1.Work
    
    # Potential journal callback detected. Pausing journal.
    # Journal callback ended. Unpausing
    workInstructionBuilder114.CaptureCurrentView()
    
    workInstructionBuilder115 = objectWorkInstructionBuilder1.Work
    
    workInstructionBuilder115.CameraName = "NXWI$3"
    
    workInstructionBuilder116 = objectWorkInstructionBuilder1.Work
    
    workInstructionBuilder116.CommitItem()
    
    camera26 = nXObject26
    cameraBuilder28 = workPart.Cameras.CreateCameraBuilder(modelingView13, layout2, camera26)
    
    nXObject28 = cameraBuilder28.Commit()
    
    cameraBuilder28.Destroy()
    
    layout2.ReplaceView(modelingView13, modelingView13, False)
    
    workInstructionBuilder117 = objectWorkInstructionBuilder1.Work
    
    workInstructionBuilder117.ItemName = "OWI_PROD_VIEW_1"
    
    camera27 = nXObject28
    cameraBuilder29 = workPart.Cameras.CreateCameraBuilder(modelingView13, layout2, camera27)
    
    nXObject29 = cameraBuilder29.Commit()
    
    cameraBuilder29.Destroy()
    
    workInstructionBuilder118 = objectWorkInstructionBuilder1.Work
    
    sheettitle24 = workInstructionBuilder118.SheetTitle
    
    cameraBuilder30 = workPart.Cameras.CreateCameraBuilder(modelingView13, layout2, NXOpen.Display.Camera.Null)
    
    nXObject30 = cameraBuilder30.Commit()
    
    cameraBuilder30.Destroy()
    
    workInstructionBuilder119 = objectWorkInstructionBuilder1.Work
    
    # Potential journal callback detected. Pausing journal.
    # Journal callback ended. Unpausing
    workInstructionBuilder119.CaptureCurrentView()
    
    workInstructionBuilder120 = objectWorkInstructionBuilder1.Work
    
    workInstructionBuilder120.CameraName = "NXWI$4"
    
    workInstructionBuilder121 = objectWorkInstructionBuilder1.Work
    
    workInstructionBuilder121.CommitItem()
    
    camera28 = nXObject29
    cameraBuilder31 = workPart.Cameras.CreateCameraBuilder(modelingView13, layout2, camera28)
    
    nXObject31 = cameraBuilder31.Commit()
    
    cameraBuilder31.Destroy()
    
    layout2.ReplaceView(modelingView13, modelingView13, False)
    
    layout2.ReplaceView(modelingView13, modelingView13, False)
    
    workInstructionBuilder122 = objectWorkInstructionBuilder1.Work
    
    workInstructionBuilder122.ItemName = "OWI_PROD_VIEW_2"
    
    camera29 = nXObject31
    cameraBuilder32 = workPart.Cameras.CreateCameraBuilder(modelingView13, layout2, camera29)
    
    nXObject32 = cameraBuilder32.Commit()
    
    cameraBuilder32.Destroy()
    
    workInstructionBuilder123 = objectWorkInstructionBuilder1.Work
    
    sheettitle25 = workInstructionBuilder123.SheetTitle
    
    workInstructionBuilder124 = objectWorkInstructionBuilder1.Work
    
    workInstructionBuilder124.CameraName = "Top"
    
    workInstructionBuilder125 = objectWorkInstructionBuilder1.Work
    
    workInstructionBuilder125.CommitItem()
    
    camera30 = nXObject32
    cameraBuilder33 = workPart.Cameras.CreateCameraBuilder(modelingView13, layout2, camera30)
    
    nXObject33 = cameraBuilder33.Commit()
    
    cameraBuilder33.Destroy()
    
    layout2.ReplaceView(modelingView13, modelingView13, False)
    
    layout2.ReplaceView(modelingView13, modelingView13, False)
    
    modelingView13.Orient(NXOpen.View.Canned.Top, NXOpen.View.ScaleAdjustment.Fit)
    
    workInstructionBuilder126 = objectWorkInstructionBuilder1.Work
    
    workInstructionBuilder126.ItemName = "OWI_PROD_VIEW_3"
    
    camera31 = nXObject33
    cameraBuilder34 = workPart.Cameras.CreateCameraBuilder(modelingView13, layout2, camera31)
    
    nXObject34 = cameraBuilder34.Commit()
    
    cameraBuilder34.Destroy()
    
    workInstructionBuilder127 = objectWorkInstructionBuilder1.Work
    
    sheettitle26 = workInstructionBuilder127.SheetTitle
    
    workInstructionBuilder128 = objectWorkInstructionBuilder1.Work
    
    workInstructionBuilder128.CameraName = "Front"
    
    workInstructionBuilder129 = objectWorkInstructionBuilder1.Work
    
    workInstructionBuilder129.CommitItem()
    
    camera32 = nXObject34
    cameraBuilder35 = workPart.Cameras.CreateCameraBuilder(modelingView13, layout2, camera32)
    
    nXObject35 = cameraBuilder35.Commit()
    
    cameraBuilder35.Destroy()
    
    layout2.ReplaceView(modelingView13, modelingView13, False)
    
    layout2.ReplaceView(modelingView13, modelingView13, False)
    
    modelingView13.Orient(NXOpen.View.Canned.Top, NXOpen.View.ScaleAdjustment.Fit)
    
    modelingView13.Orient(NXOpen.View.Canned.Front, NXOpen.View.ScaleAdjustment.Fit)
    
    workInstructionBuilder130 = objectWorkInstructionBuilder1.Work
    
    workInstructionBuilder130.SheetNumber = 4
    
    workInstructionBuilder131 = objectWorkInstructionBuilder1.Work
    
    itemnames8 = [None] * 2 
    itemnames8[0] = "OWI_PROD_VIEW_2"
    itemnames8[1] = "OWI_OPER_LIST_1"
    workInstructionBuilder131.UpdateItemsInCurrentSheet(itemnames8)
    
    camera33 = nXObject35
    cameraBuilder36 = workPart.Cameras.CreateCameraBuilder(modelingView13, layout2, camera33)
    
    nXObject36 = cameraBuilder36.Commit()
    
    cameraBuilder36.Destroy()
    
    workInstructionBuilder132 = objectWorkInstructionBuilder1.Work
    
    sheettitle27 = workInstructionBuilder132.SheetTitle
    
    workInstructionBuilder133 = objectWorkInstructionBuilder1.Work
    
    workInstructionBuilder133.SheetTitle = sheettitle27
    
    workInstructionBuilder134 = objectWorkInstructionBuilder1.Work
    
    workInstructionBuilder134.ItemName = "OWI_PROD_VIEW_2"
    
    camera34 = nXObject36
    cameraBuilder37 = workPart.Cameras.CreateCameraBuilder(modelingView13, layout2, camera34)
    
    nXObject37 = cameraBuilder37.Commit()
    
    cameraBuilder37.Destroy()
    
    workInstructionBuilder135 = objectWorkInstructionBuilder1.Work
    
    sheettitle28 = workInstructionBuilder135.SheetTitle
    
    cameraBuilder38 = workPart.Cameras.CreateCameraBuilder(modelingView13, layout2, NXOpen.Display.Camera.Null)
    
    nXObject38 = cameraBuilder38.Commit()
    
    cameraBuilder38.Destroy()
    
    workInstructionBuilder136 = objectWorkInstructionBuilder1.Work
    
    # Potential journal callback detected. Pausing journal.
    # Journal callback ended. Unpausing
    workInstructionBuilder136.CaptureCurrentView()
    
    workInstructionBuilder137 = objectWorkInstructionBuilder1.Work
    
    workInstructionBuilder137.CameraName = "NXWI$5"
    
    workInstructionBuilder138 = objectWorkInstructionBuilder1.Work
    
    workInstructionBuilder138.CommitItem()
    
    camera35 = nXObject37
    cameraBuilder39 = workPart.Cameras.CreateCameraBuilder(modelingView13, layout2, camera35)
    
    nXObject39 = cameraBuilder39.Commit()
    
    cameraBuilder39.Destroy()
    
    layout2.ReplaceView(modelingView13, modelingView13, False)
    
    workInstructionBuilder139 = objectWorkInstructionBuilder1.Work
    
    workInstructionBuilder139.ItemName = "OWI_OPER_LIST_1"
    
    workInstructionBuilder140 = objectWorkInstructionBuilder1.Work
    
    sheettitle29 = workInstructionBuilder140.SheetTitle
    
    workInstructionBuilder141 = objectWorkInstructionBuilder1.Work
    
    workInstructionBuilder141.OperListProgramGroup = sheettitle1
    
    workInstructionBuilder142 = objectWorkInstructionBuilder1.Work
    
    workInstructionBuilder142.OperListProgramGroup = sheettitle1
    
    workInstructionBuilder143 = objectWorkInstructionBuilder1.Work
    
    workInstructionBuilder143.CommitItem()
    
    camera36 = nXObject39
    cameraBuilder40 = workPart.Cameras.CreateCameraBuilder(modelingView13, layout2, camera36)
    
    nXObject40 = cameraBuilder40.Commit()
    
    cameraBuilder40.Destroy()
    
    layout2.ReplaceView(modelingView13, modelingView13, False)
    
    markId5 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Author Work Instructions")
    
    theSession.DeleteUndoMark(markId5, None)
    
    markId6 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Author Work Instructions")
    
    theSession.DeleteUndoMark(markId6, None)
    
    theSession.SetUndoMarkName(markId4, "Author Work Instructions")
    
    theSession.DeleteUndoMark(markId4, None)
    
    nXObject41 = objectWorkInstructionBuilder1.Commit()
    
    objectWorkInstructionBuilder1.Destroy()
    
    part7 = theSession.Parts.Work
    
    part8 = theSession.Parts.Display
    
    cAMSetup100 = workPart.CAMSetup
    
    operation13 = cAMSetup100.CAMOperationCollection.FindObject(name84)
    
    holeDrilling5 = operation13
    theSession.CAMSession.PathDisplay.ShowToolPath(holeDrilling5)
    
    inTaskEnv2 = theSession.IsBatch
    
    # Potential journal callback detected. Pausing journal.
    # Journal callback ended. Unpausing
    theSession.CAMSession.PathDisplay.StepDisplay(True)
    
    markId7 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    cAMSetup101 = workPart.CAMSetup
    
    workInstructionOutputBuilder2 = cAMSetup101.CreateWorkInstructionOutputBuilder()
    
    workInstructionOutputBuilder2.PageSize = NXOpen.CAM.WorkInstructionOutputBuilder.PageSizeType.Letter
    
    workInstructionOutputBuilder2.ScaleFactor = 1.0
    
    workInstructionOutputBuilder2.OutputFormat = NXOpen.CAM.WorkInstructionOutputBuilder.OutputFormatType.Pdf
    
    workInstructionOutputBuilder2.OutputFile = "C:\\Users\\muhsin.caglar\\OneDrive - Retrac Productions Ltd\\Desktop\\JUNK\\owi\\22222.pdf"
    
    workInstructionOutputBuilder2.OpenFile = True
    
    workInstructionOutputBuilder2.PageSize = NXOpen.CAM.WorkInstructionOutputBuilder.PageSizeType.A4
    
    theSession.SetUndoMarkName(markId7, "Publish Work Instructions Dialog")
    
    markId8 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Publish Work Instructions")
    
    theSession.DeleteUndoMark(markId8, None)
    
    markId9 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Publish Work Instructions")
    
    layout3 = workPart.Layouts.FindObject("L1")
    
    camera37 = workPart.Cameras.FindObject("NXOWI_CACHE_CURRENT_VIEW")
    
    modelingView14 = workPart.ModelingViews.WorkView
    
    cameraBuilder41 = workPart.Cameras.CreateCameraBuilder(modelingView14, layout3, camera37)
    
    nXObject42 = cameraBuilder41.Commit()
    
    cameraBuilder41.Destroy()
    
    modelingView15 = workPart.ModelingViews.WorkView
    
    modelingView16 = workPart.ModelingViews.WorkView
    
    layout3.ReplaceView(modelingView16, modelingView16, False)
    
    modelingView17 = workPart.ModelingViews.WorkView
    
    modelingView18 = workPart.ModelingViews.WorkView
    
    layout3.ReplaceView(modelingView18, modelingView18, False)
    
    modelingView19 = workPart.ModelingViews.WorkView
    
    modelingView20 = workPart.ModelingViews.WorkView
    
    layout3.ReplaceView(modelingView20, modelingView20, False)
    
    modelingView21 = workPart.ModelingViews.WorkView
    
    modelingView22 = workPart.ModelingViews.WorkView
    
    layout3.ReplaceView(modelingView22, modelingView22, False)
    
    modelingView23 = workPart.ModelingViews.WorkView
    
    modelingView23.Orient(NXOpen.View.Canned.Top, NXOpen.View.ScaleAdjustment.Fit)
    
    modelingView24 = workPart.ModelingViews.WorkView
    
    modelingView24.Orient(NXOpen.View.Canned.Front, NXOpen.View.ScaleAdjustment.Fit)
    
    modelingView25 = workPart.ModelingViews.WorkView
    
    modelingView26 = workPart.ModelingViews.WorkView
    
    layout3.ReplaceView(modelingView26, modelingView26, False)
    
    objects3 = [NXOpen.CAM.CAMObject.Null] * 1 
    objects3[0] = holeDrilling5
    # Potential journal callback detected. Pausing journal.
    # Journal callback ended. Unpausing
    workInstructionOutputBuilder2.Publish(objects3, holeDrilling5, 0)
    
    modelingView27 = workPart.ModelingViews.WorkView
    
    camera38 = nXObject42
    camera38.ApplyToView(modelingView27)
    
    theSession.DeleteUndoMark(markId9, None)
    
    theSession.SetUndoMarkName(markId7, "Publish Work Instructions")
    
    workInstructionOutputBuilder2.Destroy()
    
    # ----------------------------------------------
    #   Menu: Tools->Automation->Journal->Stop Recording
    # ----------------------------------------------
    
if __name__ == '__main__':
    main()