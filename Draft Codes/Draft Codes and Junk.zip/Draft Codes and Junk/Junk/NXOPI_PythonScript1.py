import math
import NXOpen
import NXOpen.CAM

def get_group_objects(group_name):
    theSession = NXOpen.Session.GetSession()
    workPart = theSession.Parts.Work
    displayPart = theSession.Parts.Display

    find_it = workPart.CAMSetup.CAMOperationCollection.FindObject(group_name)

    new_objects = NXOpen.CAM.NCGroup.GetMembers(find_it)

    return new_objects

def output_message(dialog_name ,message_list):
    theSession = NXOpen.Session.GetSession()
    workPart = theSession.Parts.Work
    displayPart = theSession.Parts.Display

    get_ui = NXOpen.UI.GetUI()
    message_box = get_ui.NXMessageBox
    message_box.Show(dialog_name, NXOpen.NXMessageBox.DialogType.Information, message_list)

def main():
    theSession = NXOpen.Session.GetSession()
    workPart = theSession.Parts.Work
    displayPart = theSession.Parts.Display

    start_point = workPart.CAMSetup.CAMOperationCollection.FindObject("GEOMETRY")
    objects_at_start = NXOpen.CAM.NCGroup.GetMembers(start_point)

    group_list = []
    checked_list = []
    operation_list = []
    feed_rate_list = []
    spindle_rpm_list = []
    stock_value_list = []
    path_time_list = []
    cutting_tool_list = []

    for each_object in objects_at_start:
        if workPart.CAMSetup.IsGroup(each_object) == True:
            group_list.append(each_object.Name)
        elif workPart.CAMSetup.IsOperation(each_object) == True:
            operation_list.append(each_object.Name)
            cutting_tool = each_object.GetParent(NXOpen.CAM.CAMSetupView.MachineTool)
            cutting_tool_list.append(cutting_tool.Name)
            stock_value_list.append(str(each_object.GetRealValue("Stock Part")))
            spindle_rpm_list.append(str(each_object.GetRealValue("Spindle RPM")))
            feed_rate_tuple = each_object.GetFeedRate("Feed Cut")
            if feed_rate_tuple[0] == NXOpen.CAM.CAMObjectFeedRateUnit.PerMinute:
                feed_rate_units = "mm per Minute"
            elif feed_rate_tuple[0] == NXOpen.CAM.CAMObjectFeedRateUnit.PerRevolution:
                feed_rate_units = "mm per revolution"
            else:
                feed_rate_units = "None"
            feed_rate_list.append(str(feed_rate_tuple[1]) + feed_rate_units)
            path_time_list.append(str(sub_object.GetToolpathTime()))

    while group_list != checked_list:
        for each_object in group_list:
            if each_object not in checked_list:
                temp_objects = get_group_objects(each_object)
                for sub_object in temp_objects:
                    if workPart.CAMSetup.IsGroup(sub_object) == True:
                        group_list.append(sub_object.Name)
                    elif workPart.CAMSetup.IsOperation(sub_object) == True:
                        operation_list.append(sub_object.Name)
                        cutting_tool = sub_object.GetParent(NXOpen.CAM.CAMSetupView.MachineTool)
                        cutting_tool_list.append(cutting_tool.Name)
                        stock_value_list.append(str(sub_object.GetRealValue("Stock Part")))
                        spindle_rpm_list.append(str(sub_object.GetRealValue("Spindle RPM")))
                        feed_rate_tuple = sub_object.GetFeedRate("Feed Cut")
                        if feed_rate_tuple[0] == NXOpen.CAM.CAMObjectFeedRateUnit.PerMinute:
                            feed_rate_units = "mm per minute"
                        elif feed_rate_tuple[0] == NXOpen.CAM.CAMObjectFeedRateUnit.PerRevolution:
                            feed_rate_units = "mm per revolution"
                        else:
                            feed_rate_units = "None"
                        feed_rate_list.append(str(feed_rate_tuple[1]) + feed_rate_units)
                        path_time_list.append(str(sub_object.GetToolpathTime()))
                checked_list.append(each_object)

    temp_list = []

    if operation_list == []:
        output_message("No Path", "There are no operations to report.")
    else:
        for i in range(len(operation_list)):
            temp_list.append("Path: " + operation_list[i] + " Tool: " + group_list[i])
        output_message("Cutting Tools", temp_list)
        temp_list = []


main() 