import math
import NXOpen

import os





def main() : 
    
    text_file = open("S:\\CAD_Office\\Muhsin\\NXOPEN\\NX_OWI_Automation\\WI_DATA\\Output.txt", "w")
    # Add the path to the desired Python environment
    custom_python_lib_path = "C:\\Users\\muhsin.caglar\\Python\Lib\\site-packages"
    sys.path.append(custom_python_lib_path)
    
    # Test if you can import a custom library from that environment
    try:
        import pyautogui
        text_file.write("Custom library imported successfully!")
    except ImportError:
        text_file.write("Failed to import the custom library")    



if __name__ == '__main__':
    main()	